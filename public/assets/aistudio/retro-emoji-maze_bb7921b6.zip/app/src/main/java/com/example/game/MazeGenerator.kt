package com.example.game

import kotlin.random.Random

enum class TileType {
    WALL, PATH, STAR, START, EXIT
}

data class Position(val r: Int, val c: Int) {
    fun move(dr: Int, dc: Int): Position = Position(r + dr, c + dc)
}

class Maze(
    val rows: Int,
    val cols: Int,
    val grid: Array<Array<TileType>>
) {
    fun isWalkable(r: Int, c: Int): Boolean {
        if (r !in 0 until rows || c !in 0 until cols) return false
        return grid[r][c] != TileType.WALL
    }
}

object MazeGenerator {
    fun generate(rows: Int, cols: Int, starCount: Int = 5): Maze {
        // Ensure odd rows and cols for the grid-carving algorithm
        val rCount = if (rows % 2 == 0) rows + 1 else rows
        val cCount = if (cols % 2 == 0) cols + 1 else cols

        val grid = Array(rCount) { Array(cCount) { TileType.WALL } }
        val visited = Array(rCount) { BooleanArray(cCount) { false } }

        fun isInBounds(r: Int, c: Int): Boolean {
            return r in 1 until rCount - 1 && c in 1 until cCount - 1
        }

        // DFS carving
        fun dfs(r: Int, c: Int) {
            visited[r][c] = true
            grid[r][c] = TileType.PATH

            val directions = listOf(
                Pair(-2, 0), Pair(2, 0),
                Pair(0, -2), Pair(0, 2)
            ).shuffled()

            for ((dr, dc) in directions) {
                val nr = r + dr
                val nc = c + dc
                if (isInBounds(nr, nc) && !visited[nr][nc]) {
                    // Carve path representing between cells
                    val wallR = r + dr / 2
                    val wallC = c + dc / 2
                    grid[wallR][wallC] = TileType.PATH
                    grid[nr][nc] = TileType.PATH
                    dfs(nr, nc)
                }
            }
        }

        // Carve the maze
        dfs(1, 1)

        // Establish Start and Exit points
        grid[1][1] = TileType.START
        grid[rCount - 2][cCount - 2] = TileType.EXIT

        // Scatter Star collectibles along the generated paths
        val potentialStarPositions = mutableListOf<Position>()
        for (r in 1 until rCount - 1) {
            for (c in 1 until cCount - 1) {
                if (grid[r][c] == TileType.PATH && !(r == 1 && c == 1) && !(r == rCount - 2 && c == cCount - 2)) {
                    potentialStarPositions.add(Position(r, c))
                }
            }
        }

        potentialStarPositions.shuffle()
        val actualStarCount = minOf(starCount, potentialStarPositions.size)
        for (i in 0 until actualStarCount) {
            val (pr, pc) = potentialStarPositions[i]
            grid[pr][pc] = TileType.STAR
        }

        return Maze(rCount, cCount, grid)
    }
}
