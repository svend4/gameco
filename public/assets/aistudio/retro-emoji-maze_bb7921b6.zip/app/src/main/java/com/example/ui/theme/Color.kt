package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Default template colors preserved
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Retro Neon Color Palette for Emoji Maze (Preserved fallback/mixed compatibility)
val RetroCosmicBlack = Color(0xFF090616)
val RetroSpaceIndigo = Color(0xFF130E2D)
val RetroSurfaceCard = Color(0xFF1D163F)
val RetroNeonPink = Color(0xFFFF107F)
val RetroNeonCyan = Color(0xFF00FAFF)
val RetroNeonGreen = Color(0xFF10FF5E)
val RetroNeonYellow = Color(0xFFFFD800)
val RetroNeonOrange = Color(0xFFFF6600)
val RetroMutedWall = Color(0xFF2E2259)
val RetroGhostRed = Color(0xFFFF3333)

// Artistic Flair Theme Color Palette
val ArtisticBgRaw = Color(0xFFFEF7FF)
val ArtisticTextRaw = Color(0xFF1D1B20)
val ArtisticPrimaryRaw = Color(0xFF6750A4)
val ArtisticSecondaryRaw = Color(0xFF625B71)
val ArtisticLightPurpleRaw = Color(0xFFD0BCFF)
val ArtisticPurplePillRaw = Color(0xFFE8DEF8)
val ArtisticPinkPillRaw = Color(0xFFFFD8E4)
val ArtisticDarkTextRaw = Color(0xFF1D192B)
val ArtisticFooterBgRaw = Color(0xFFF3EDF7)
val ArtisticGrayBorderRaw = Color(0xFFCAC4D0)
val ArtisticDarkBgRaw = Color(0xFF1D1B20)
val ArtisticWallColorRaw = Color(0xFF49454F)

