package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = false, dynamicColor = false) {
                val gameViewModel: GameViewModel = viewModel()
                val uiState by gameViewModel.uiState.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ArtisticBgRaw)
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(ArtisticBgRaw)
                            // A gorgeous visual CRT cathode screen scanline simulation drawn directly on top of layout
                            .drawWithContent {
                                drawContent()
                                if (uiState.scanlinesEnabled) {
                                    val step = 4.dp.toPx()
                                    var y = 0f
                                    while (y < size.height) {
                                        drawLine(
                                            color = Color.Black.copy(alpha = 0.08f),
                                            start = Offset(0f, y),
                                            end = Offset(size.width, y),
                                            strokeWidth = 1.5.dp.toPx()
                                        )
                                        y += step
                                    }
                                }
                            }
                    ) {
                        when (uiState.gameState) {
                            GameState.MENU -> MainMenuScreen(gameViewModel, uiState)
                            GameState.PLAYING -> GameScreen(gameViewModel, uiState)
                            GameState.LEVEL_COMPLETE -> LevelCompleteScreen(gameViewModel, uiState)
                            GameState.GAME_OVER -> GameOverScreen(gameViewModel, uiState)
                            GameState.SHOP -> AvatarShopScreen(gameViewModel, uiState)
                            GameState.INSTRUCTIONS -> InstructionsScreen(gameViewModel, uiState)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 1. MAIN MENU SCREEN WITH FLOATING PARTICLES
// ==========================================
@Composable
fun MainMenuScreen(viewModel: GameViewModel, state: GameUIState) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtisticBgRaw)
    ) {
        // Floating Background Particles (Emojis drifting up)
        FloatingParticlesBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Title
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 28.dp)
            ) {
                Text(
                    text = "🕹️ EMOJI QUEST",
                    color = ArtisticSecondaryRaw,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                
                Text(
                    text = "EMOJI MAZE",
                    color = ArtisticPrimaryRaw,
                    fontSize = 42.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.displayMedium.copy(
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Artistic Flair Style",
                        color = ArtisticPrimaryRaw.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "🎨", fontSize = 16.sp)
                }
            }

            // High Score & Stats Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Trophy",
                            tint = ArtisticPrimaryRaw,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SCORE: ${state.totalCoins}",
                            color = ArtisticPrimaryRaw,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "MAX LEVEL REACHED: ${state.highLevel}",
                        color = ArtisticSecondaryRaw,
                        fontFamily = FontFamily.Default,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(ArtisticPurplePillRaw, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Current Avatar: ",
                            color = ArtisticDarkTextRaw.copy(alpha = 0.7f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = state.selectedAvatar,
                            fontSize = 20.sp,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        Button(
                            onClick = { viewModel.openShop() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = ArtisticPrimaryRaw),
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier
                                .height(24.dp)
                                .testTag("change_avatar_shortcut")
                        ) {
                            Text(
                                text = "[CHANGE]",
                                color = ArtisticPrimaryRaw,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Default,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Configuration Options
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    text = "SELECT DIFFICULTY:",
                    color = ArtisticSecondaryRaw,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
                )

                // Difficulties Selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Difficulty.values().forEach { diff ->
                        val isSelected = state.difficulty == diff
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) ArtisticPrimaryRaw else Color.White)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) ArtisticPrimaryRaw else ArtisticGrayBorderRaw,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.selectDifficulty(diff) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = diff.name,
                                    color = if (isSelected) Color.White else ArtisticDarkTextRaw,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Default
                                )
                                Text(
                                    text = "${diff.rows}x${diff.cols}",
                                    color = if (isSelected) Color.White.copy(alpha = 0.8f) else ArtisticSecondaryRaw,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Default
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Toggle settings
                SettingsToggleRow(
                    title = "Wandering Ghosts (Enemies)",
                    subtitle = "Avoid ghosts: lose lives upon impact!",
                    checked = state.enemiesEnabled,
                    activeColor = ArtisticPrimaryRaw,
                    onCheckedChange = { viewModel.toggleEnemies() }
                )

                Spacer(modifier = Modifier.height(8.dp))

                SettingsToggleRow(
                    title = "CRT Scanlines Effect",
                    subtitle = "Toggle vintage cathode ray monitor rows",
                    checked = state.scanlinesEnabled,
                    activeColor = ArtisticPrimaryRaw,
                    onCheckedChange = { viewModel.toggleScanlines() }
                )
            }

            // Action Buttons
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Main Pulse Animation for button
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseScale by infiniteTransition.animateFloat(
                    initialValue = 0.98f,
                    targetValue = 1.02f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "scale"
                )

                Button(
                    onClick = { viewModel.startNewGame() },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtisticPrimaryRaw),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .graphicsLayer(scaleX = pulseScale, scaleY = pulseScale)
                        .testTag("start_game_button")
                ) {
                    Text(
                        text = "START QUEST 🕹️",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.openShop() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ArtisticPrimaryRaw),
                        border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("open_shop_button")
                    ) {
                        Text(
                            text = "🛍️ AVATARS",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = { viewModel.openInstructions() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ArtisticSecondaryRaw),
                        border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("open_instructions_button")
                    ) {
                        Text(
                            text = "📖 HOW TO PLAY",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Composable helper for floating background particles inside Menu Screen
@Composable
fun FloatingParticlesBackground() {
    val particles = remember {
        List(12) {
            Triple(
                Random.nextFloat(), // X ratio
                Random.nextFloat() * 1000f, // Initial delay
                listOf("😀", "😎", "👾", "❤️", "⭐", "🔮", "🍕", "💖").random()
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        particles.forEach { (xRatio, delayMs, emoji) ->
            val infiniteTransition = rememberInfiniteTransition(label = "particle")
            val yOffset by infiniteTransition.animateFloat(
                initialValue = 1.1f, // Bottom
                targetValue = -0.1f, // Top
                animationSpec = infiniteRepeatable(
                    animation = tween(6000 + delayMs.toInt(), easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "offsetY"
            )

            val rotation by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(4000 + delayMs.toInt(), easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "rotation"
            )

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val xPos = maxWidth * xRatio
                val yPos = maxHeight * yOffset

                Text(
                    text = emoji,
                    fontSize = 24.sp,
                    modifier = Modifier
                        .offset(x = xPos, y = yPos)
                        .graphicsLayer(
                            alpha = 0.15f,
                            rotationZ = rotation
                        )
                )
            }
        }
    }
}

// Composable helper for options toggle bar
@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    activeColor: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(RetroSurfaceCard)
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = subtitle,
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = activeColor,
                uncheckedThumbColor = Color.White.copy(alpha = 0.4f),
                uncheckedTrackColor = Color.Black.copy(alpha = 0.3f)
            ),
            modifier = Modifier.graphicsLayer(scaleX = 0.85f, scaleY = 0.85f)
        )
    }
}


// ==========================================
// 2. MAIN RETRO GAME SCREEN
// ==========================================
@Composable
fun GameScreen(viewModel: GameViewModel, state: GameUIState) {
    val maze = state.currentMaze ?: return
    
    // Core keyboard focus handlers
    val focusRequester = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    // Drag-swipe handler calculations
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    var hasMovedByDrag by remember { mutableStateOf(false) }
    val swipeThreshold = 60f // pixel threshold

    // Spring animations for Game Card shake feedback
    val shakeAnimX = remember { Animatable(0f) }
    val shakeAnimY = remember { Animatable(0f) }

    LaunchedEffect(state.screenShakeTrigger) {
        if (state.screenShakeTrigger > 0) {
            launch {
                shakeAnimX.animateTo(10f, spring(dampingRatio = Spring.DampingRatioHighBouncy))
                shakeAnimX.animateTo(-10f, spring(dampingRatio = Spring.DampingRatioHighBouncy))
                shakeAnimX.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy))
            }
            launch {
                shakeAnimY.animateTo(-6f, spring(dampingRatio = Spring.DampingRatioHighBouncy))
                shakeAnimY.animateTo(6f, spring(dampingRatio = Spring.DampingRatioHighBouncy))
                shakeAnimY.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy))
            }
        }
    }

    // Auto-request focus upon launch to accept physical system arrow key inputs
    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionUp -> { viewModel.movePlayer(-1, 0); true }
                        Key.DirectionDown -> { viewModel.movePlayer(1, 0); true }
                        Key.DirectionLeft -> { viewModel.movePlayer(0, -1); true }
                        Key.DirectionRight -> { viewModel.movePlayer(0, 1); true }
                        else -> false
                    }
                } else false
            }
            .background(ArtisticBgRaw)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP ARTISTIC HEADER STATUS PANEL
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Level badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(ArtisticPurplePillRaw, RoundedCornerShape(12.dp))
                        .border(1.dp, ArtisticPrimaryRaw, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "LVL ${state.level.toString().padStart(2, '0')}",
                        color = ArtisticPrimaryRaw,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                
                Spacer(modifier = Modifier.width(6.dp))
                
                // Difficulty tag
                Text(
                    text = state.difficulty.name,
                    color = ArtisticSecondaryRaw,
                    fontFamily = FontFamily.Default,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Hearts monitoring pill (Matches HTML bg-[#FFD8E4])
            Box(
                modifier = Modifier
                    .background(ArtisticPinkPillRaw, RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "❤️",
                        fontSize = 14.sp
                    )
                    Text(
                        text = "x${state.hearts}",
                        color = Color(0xFF31111D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Default
                    )
                }
            }

            // Score Wallet Coins Panel (Matches HTML bg-[#E8DEF8])
            Box(
                modifier = Modifier
                    .background(ArtisticPurplePillRaw, RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "SCORE",
                        color = Color(0xFF1D192B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default
                    )
                    Text(
                        text = state.totalCoins.toString().padStart(4, '0'),
                        color = ArtisticPrimaryRaw,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // LEVEL CLEARANCE STARS INDICATOR ROW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Stars Collected: ",
                color = ArtisticSecondaryRaw,
                fontFamily = FontFamily.Default,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "${state.starsCollectedThisRun}/${state.totalStarsThisRun}",
                color = ArtisticPrimaryRaw,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "⭐", fontSize = 14.sp)
        }

        // MAZE GAME DISPLAY AREA (BOX WITH SHAKE AND SWIPING)
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .aspectRatio(1f)
                .graphicsLayer(
                    translationX = shakeAnimX.value,
                    translationY = shakeAnimY.value
                )
                .clip(RoundedCornerShape(32.dp))
                .background(ArtisticDarkBgRaw)
                .border(4.dp, ArtisticPrimaryRaw, RoundedCornerShape(32.dp))
                .drawBehind {
                    // Draw a beautiful custom subtle radial grid dot pattern on the dark board
                    val dotRadius = 1.5.dp.toPx()
                    val spacing = 20.dp.toPx()
                    var x = 10.dp.toPx()
                    while (x < size.width) {
                        var y = 10.dp.toPx()
                        while (y < size.height) {
                            drawCircle(
                                color = ArtisticPrimaryRaw.copy(alpha = 0.2f),
                                radius = dotRadius,
                                center = Offset(x, y)
                            )
                            y += spacing
                        }
                        x += spacing
                    }
                }
                .pointerInput(Unit) {
                    // Modern 4-way swipe interpretation logic
                    detectDragGestures(
                        onDragStart = { offset ->
                            dragStart = offset
                            hasMovedByDrag = false
                        },
                        onDragEnd = { hasMovedByDrag = false },
                        onDragCancel = { hasMovedByDrag = false },
                        onDrag = { change, _ ->
                            change.consume()
                            if (!hasMovedByDrag) {
                                val dx = change.position.x - dragStart.x
                                val dy = change.position.y - dragStart.y
                                if (Math.abs(dx) > swipeThreshold || Math.abs(dy) > swipeThreshold) {
                                    if (Math.abs(dx) > Math.abs(dy)) {
                                        if (dx > 0) viewModel.movePlayer(0, 1) else viewModel.movePlayer(0, -1)
                                    } else {
                                        if (dy > 0) viewModel.movePlayer(1, 0) else viewModel.movePlayer(-1, 0)
                                    }
                                    hasMovedByDrag = true
                                }
                            }
                        }
                    )
                }
                .testTag("game_maze_viewport")
        ) {
            val rCount = maze.rows
            val cCount = maze.cols
            val cellSize = maxWidth / cCount

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                for (r in 0 until rCount) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in 0 until cCount) {
                            val tile = maze.grid[r][c]
                            val playerHere = (state.playerPosition.r == r && state.playerPosition.c == c)
                            val starHere = state.starPositions.contains(Position(r, c))
                            val enemyHere = state.enemyPositions.find { it.r == r && it.c == c }

                            Box(
                                modifier = Modifier
                                    .size(cellSize)
                                    .background(Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                // Draw walls style from design HTML: solid block background `#49454F` with rounded corner
                                if (tile == TileType.WALL) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(1.5.dp) // Gap spacing equivalent to slot borders
                                            .background(
                                                ArtisticWallColorRaw,
                                                RoundedCornerShape(3.dp)
                                            )
                                    )
                                }

                                // Exit checkered port portal (if player hasn't reached it)
                                if (tile == TileType.EXIT && !playerHere) {
                                    Text(
                                        text = "🏁",
                                        fontSize = (cellSize.value * 0.52f).sp,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                // Start entrance
                                if (tile == TileType.START && !playerHere) {
                                    Text(
                                        text = "🚪",
                                        fontSize = (cellSize.value * 0.45f).sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.graphicsLayer(alpha = 0.4f)
                                    )
                                }

                                // Collectibles Star (⭐)
                                if (starHere) {
                                    PulsingStar(sizeDp = cellSize.value * 0.6f)
                                }

                                // Interactive Ghosts / Enemies (👾 or 👻)
                                if (enemyHere != null && !playerHere) {
                                    val enemyEmoji = if (r % 2 == 0) "👾" else "👻"
                                    FloatingEnemy(emoji = enemyEmoji, sizeDp = cellSize.value * 0.68f)
                                }

                                // Floating Main Player Emoji Avatar
                                if (playerHere) {
                                    FloatingPlayer(
                                        emoji = state.selectedAvatar,
                                        sizeDp = cellSize.value * 0.72f,
                                        isInvincible = state.isInvincible
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ACTION AND STATS MESSAGE SUBTITLE TRAY
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(ArtisticPurplePillRaw)
                .border(1.dp, ArtisticPrimaryRaw.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "> ${state.lastActionMessage.uppercase()}",
                color = if (state.lastActionMessage.lowercase().contains("oops") || state.lastActionMessage.lowercase().contains("hit") || state.lastActionMessage.lowercase().contains("lost")) Color(0xFFB3261E) else ArtisticPrimaryRaw,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // CONSOLE INTEGRATION D-PAD CONTROLS
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            // Arrow indicators guide
            Text(
                text = "[SWIPE / TAP D-PAD / ARROW KEYS TO WALK]",
                color = ArtisticSecondaryRaw,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Dynamic D-Pad arrangement (tactile circle dial)
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .background(ArtisticFooterBgRaw, CircleShape)
                    .border(2.dp, ArtisticGrayBorderRaw, CircleShape)
            ) {
                // Central controller hub/crosshair ornament
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(ArtisticPurplePillRaw, CircleShape)
                        .border(1.dp, ArtisticPrimaryRaw.copy(alpha = 0.4f), CircleShape)
                        .align(Alignment.Center)
                )

                // Dpad buttons
                DpadDirectionButton(
                    icon = Icons.Default.KeyboardArrowUp,
                    tag = "dpad_up",
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 4.dp),
                    onClick = { viewModel.movePlayer(-1, 0) }
                )

                DpadDirectionButton(
                    icon = Icons.Default.KeyboardArrowDown,
                    tag = "dpad_down",
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 4.dp),
                    onClick = { viewModel.movePlayer(1, 0) }
                )

                DpadDirectionButton(
                    icon = Icons.Default.KeyboardArrowLeft,
                    tag = "dpad_left",
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 4.dp),
                    onClick = { viewModel.movePlayer(0, -1) }
                )

                DpadDirectionButton(
                    icon = Icons.Default.KeyboardArrowRight,
                    tag = "dpad_right",
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 4.dp),
                    onClick = { viewModel.movePlayer(0, 1) }
                )
            }
        }

        // LOWER DISMISS ACTION DRAWER FOOTER PANEL
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.returnToMenu() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ArtisticPrimaryRaw),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("exit_to_menu_button")
            ) {
                Text(
                    text = "🏠 EXIT",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { viewModel.restartCurrentLevel() },
                colors = ButtonDefaults.buttonColors(containerColor = ArtisticPinkPillRaw),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("restart_level_button")
            ) {
                Text(
                    text = "🔄 RESTART",
                    color = Color(0xFF31111D),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// Helper composable D-Pad directional button
@Composable
fun DpadDirectionButton(
    icon: ImageVector,
    tag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(46.dp)
            .background(Color.White, CircleShape)
            .border(1.5.dp, ArtisticGrayBorderRaw, CircleShape)
            .testTag(tag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "D-pad move",
            tint = ArtisticPrimaryRaw,
            modifier = Modifier.size(28.dp)
        )
    }
}


// ==========================================
// 3. AVATARS SHOP SCREEN (AVATAR CABINET)
// ==========================================
@Composable
fun AvatarShopScreen(viewModel: GameViewModel, state: GameUIState) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Smiley", "Retro", "Animals", "Love/Items")

    val filteredAvatars = remember(selectedCategory) {
        if (selectedCategory == "All") {
            viewModel.avatarsCatalog
        } else {
            viewModel.avatarsCatalog.filter { it.category == selectedCategory }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtisticBgRaw)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Cabinet Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            Text(
                text = "🛍️ AVATARS CABINET",
                color = ArtisticPrimaryRaw,
                fontSize = 20.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Text(
                text = "Spend coins to unlock new emojis, flags & smileys",
                color = ArtisticSecondaryRaw,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Default,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Current Coins Monitor
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                modifier = Modifier.padding(top = 12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "⭐ ", fontSize = 16.sp)
                    Text(
                        text = "BALANCE: ${state.totalCoins} COINS",
                        color = ArtisticPrimaryRaw,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Category Filter Tab Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) ArtisticPrimaryRaw else Color.White)
                        .border(
                            1.dp,
                            if (isSelected) ArtisticPrimaryRaw else ArtisticGrayBorderRaw,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) Color.White else ArtisticDarkTextRaw,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Default
                    )
                }
            }
        }

        // Cabinet Grid items
        Box(modifier = Modifier.weight(1f)) {
            if (filteredAvatars.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "No Avatars Found", color = ArtisticSecondaryRaw)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredAvatars) { avatar ->
                        val isUnlocked = state.unlockedAvatars.contains(avatar.emoji)
                        val isSelected = state.selectedAvatar == avatar.emoji

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isSelected -> ArtisticPurplePillRaw
                                    else -> Color.White
                                }
                            ),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(
                                width = 1.3.dp,
                                color = when {
                                    isSelected -> ArtisticPrimaryRaw
                                    else -> ArtisticGrayBorderRaw
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp)
                                .clickable {
                                    if (isUnlocked) {
                                        viewModel.selectAvatar(avatar.emoji)
                                    } else {
                                        viewModel.purchaseAvatar(avatar)
                                    }
                                }
                                .testTag("shop_item_${avatar.emoji}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                // Avatar emoji characters
                                Text(
                                    text = avatar.emoji,
                                    fontSize = 28.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )

                                Text(
                                    text = avatar.name,
                                    fontSize = 10.sp,
                                    color = ArtisticDarkTextRaw,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )

                                // Price or Equipment Status pill
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .background(ArtisticPrimaryRaw, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "EQUIPPED",
                                            color = Color.White,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontFamily = FontFamily.Default
                                        )
                                    }
                                } else if (isUnlocked) {
                                    Box(
                                        modifier = Modifier
                                            .background(ArtisticPurplePillRaw, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "EQUIP",
                                            color = ArtisticPrimaryRaw,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Default
                                        )
                                    }
                                } else {
                                    val canAfford = state.totalCoins >= avatar.cost
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (canAfford) ArtisticPinkPillRaw else ArtisticFooterBgRaw,
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "🪙 ${avatar.cost}",
                                            color = if (canAfford) Color(0xFF31111D) else ArtisticSecondaryRaw,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Default
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Action dismiss button
        Button(
            onClick = { viewModel.returnToMenu() },
            colors = ButtonDefaults.buttonColors(containerColor = ArtisticPrimaryRaw),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .padding(top = 8.dp)
                .testTag("shop_back_button")
        ) {
            Text(
                text = "BACK TO MAIN MENU",
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


// ==========================================
// 4. LEVEL COMPLETE SUCCESS SCREEN
// ==========================================
@Composable
fun LevelCompleteScreen(viewModel: GameViewModel, state: GameUIState) {
    CardOverlayBox {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = "🏁 LEVEL CLEAR!",
                color = ArtisticPrimaryRaw,
                fontSize = 24.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Large check emblem
            Text(
                text = "🏆",
                fontSize = 52.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Star Coins award report
            Card(
                colors = CardDefaults.cardColors(containerColor = ArtisticPurplePillRaw),
                border = BorderStroke(1.dp, ArtisticPrimaryRaw.copy(alpha = 0.3f)),
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val didCollectAll = state.starsCollectedThisRun == state.totalStarsThisRun
                    Text(
                        text = if (didCollectAll) "ALL STARS COLLECTED BONUS!" else "STAGE MAZE COMPLETED!",
                        color = if (didCollectAll) Color(0xFF31111D) else ArtisticSecondaryRaw,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    
                    Text(
                        text = if (didCollectAll) "+30 COINS 🪙" else "+15 COINS 🪙",
                        color = ArtisticPrimaryRaw,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    HorizontalDivider(
                        color = ArtisticPrimaryRaw.copy(alpha = 0.15f),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Text(
                        text = "NEW COINS BALANCE: ${state.totalCoins}",
                        color = ArtisticDarkTextRaw,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { viewModel.startNewGame() },
                colors = ButtonDefaults.buttonColors(containerColor = ArtisticPrimaryRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("next_level_button")
            ) {
                Text(
                    text = "NEXT LEVEL MAZE 🏃",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = { viewModel.returnToMenu() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ArtisticSecondaryRaw),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("complete_menu_button")
            ) {
                Text(
                    text = "RETURN TO MAIN MENU",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}


// ==========================================
// 5. GAME OVER DIALOG OVERLAY SCREEN
// ==========================================
@Composable
fun GameOverScreen(viewModel: GameViewModel, state: GameUIState) {
    CardOverlayBox {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = "💀 GAME OVER",
                color = Color(0xFFB3261E),
                fontSize = 26.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "👾",
                fontSize = 54.sp,
                modifier = Modifier.padding(vertical = 10.dp)
            )

            Text(
                text = "You were caught by wandering ghosts after running out of life hearts!",
                color = ArtisticSecondaryRaw,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Default,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { viewModel.startNewGame() },
                colors = ButtonDefaults.buttonColors(containerColor = ArtisticPinkPillRaw),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("gameover_retry_button")
            ) {
                Text(
                    text = "RETRY THIS LEVEL 🔄",
                    color = Color(0xFF31111D),
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = { viewModel.returnToMenu() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ArtisticPrimaryRaw),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("gameover_menu_button")
            ) {
                Text(
                    text = "RETURN TO MAIN MENU",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}


// ==========================================
// 6. HOW TO PLAY / INSTRUCTIONS SCREEN
// ==========================================
@Composable
fun InstructionsScreen(viewModel: GameViewModel, state: GameUIState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtisticBgRaw)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Text(
                text = "🕹️ SYSTEM INSTRUCTIONS",
                color = ArtisticPrimaryRaw,
                fontSize = 18.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 12.dp, bottom = 16.dp)
            )

            // Vintage tape/CRT terminal explanation card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, ArtisticGrayBorderRaw),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MAZE SMILEY GAME ROOTS",
                        color = ArtisticPrimaryRaw,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Text(
                        text = "In the 90s & early 2000s, video games were loaded from magnetic cassettes onto cathode tube box televisions. A popular primitive genre centered on simple smileys finding paths through pixelated mazes.",
                        color = ArtisticDarkTextRaw,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        fontFamily = FontFamily.Default
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Game mechanics list
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                InstructionRow(
                    badge = "😀",
                    color = ArtisticPrimaryRaw,
                    text = "Pick your favorite unicode style emoji characters in the AVATARS SHOP as your custom player sprite."
                )

                InstructionRow(
                     badge = "⭐",
                     color = ArtisticPrimaryRaw,
                     text = "Collect golden stars scattered inside the maze walls to earn Coins (+5 Coins each). Complete level captures to claim completion bonuses!"
                )

                InstructionRow(
                    badge = "🎮",
                    color = ArtisticPrimaryRaw,
                    text = "Navigate using on-screen tactile Console D-pad keys, physical Keyboard Arrows, or simply Swipe across the colorful maze viewport."
                )

                InstructionRow(
                    badge = "👾",
                    color = ArtisticPrimaryRaw,
                    text = "Avoid wandering ghosts! Getting touched by them subtracts a life heart. You start with 3 Lives total."
                )

                InstructionRow(
                    badge = "🏁",
                    color = ArtisticPrimaryRaw,
                    text = "Reach the checkered destination flag at the bottom right of the labyrinth to clear the room and unlock more challenges!"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Erase Data Danger Area
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEECEB)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFF5B7B1)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "⚠️ MEMORY CARD RESET",
                        color = Color(0xFFB3261E),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Resets unlocked characters, tokens and highscores completely.",
                        color = ArtisticSecondaryRaw,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Default,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Button(
                        onClick = { viewModel.resetWholeGame() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E)),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("reset_game_button")
                    ) {
                        Text(
                            text = "ERASE STORED ARCHIVE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Return button
        Button(
            onClick = { viewModel.returnToMenu() },
            colors = ButtonDefaults.buttonColors(containerColor = ArtisticPrimaryRaw),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("instructions_back_button")
        ) {
            Text(
                text = "RETURN TO MAIN MENU",
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// Instruction list row helper
@Composable
fun InstructionRow(badge: String, color: Color, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, ArtisticGrayBorderRaw, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(ArtisticPurplePillRaw, CircleShape)
                .border(1.dp, ArtisticPrimaryRaw, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = badge, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            color = ArtisticDarkTextRaw,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
    }
}


// ==========================================
// 7. UTILITY COMMON DIALOG OVERLAY CARD
// ==========================================
@Composable
fun CardOverlayBox(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(2.dp, ArtisticPrimaryRaw),
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            content()
        }
    }
}


// ==========================================
// 8. ANIMATED GAMEPLAY DECORATIVE ENHANCEMENTS
// ==========================================
@Composable
fun PulsingStar(sizeDp: Float) {
    val infiniteTransition = rememberInfiniteTransition(label = "star_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.graphicsLayer(scaleX = scale, scaleY = scale)
    ) {
        Text(
            text = "⭐",
            fontSize = sizeDp.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun FloatingEnemy(emoji: String, sizeDp: Float) {
    val infiniteTransition = rememberInfiniteTransition(label = "enemy_float")
    val offsetY by infiniteTransition.animateFloat(
        initialValue = -1.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offsetY"
    )
    Box(
        modifier = Modifier.offset(y = offsetY.dp),
        contentAlignment = Alignment.Center
    ) {
        // Red neon glow card layout as custom backdrop
        Box(
            modifier = Modifier
                .size((sizeDp * 1.0f).dp)
                .background(RetroGhostRed.copy(alpha = 0.08f), CircleShape)
        )
        Text(
            text = emoji,
            fontSize = sizeDp.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun FloatingPlayer(emoji: String, sizeDp: Float, isInvincible: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "player_float")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(280, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    val alpha by if (isInvincible) {
        infiniteTransition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(120, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )
    } else {
        remember { mutableStateOf(1.0f) }
    }

    Box(
        modifier = Modifier
            .graphicsLayer(scaleX = scale, scaleY = scale, alpha = alpha),
        contentAlignment = Alignment.Center
    ) {
        // Blue neon shield backdrop to show active entity depth
        Box(
            modifier = Modifier
                .size((sizeDp * 1.0f).dp)
                .background(RetroNeonCyan.copy(alpha = 0.12f), CircleShape)
        )
        Text(
            text = emoji,
            fontSize = sizeDp.sp,
            textAlign = TextAlign.Center
        )
    }
}
