package com.example.game

import android.app.Application
import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class GameState {
    MENU, PLAYING, LEVEL_COMPLETE, GAME_OVER, SHOP, INSTRUCTIONS
}

enum class Difficulty(val label: String, val rows: Int, val cols: Int, val starCount: Int, val enemyCount: Int) {
    EASY("Classic 9x9", 9, 9, 4, 1),
    MEDIUM("Medium 13x13", 13, 13, 6, 2),
    HARD("Retro 17x17", 17, 17, 9, 3)
}

data class Avatar(
    val emoji: String,
    val name: String,
    val cost: Int,
    val category: String,
    val isDefault: Boolean = false
)

data class GameUIState(
    val gameState: GameState = GameState.MENU,
    val difficulty: Difficulty = Difficulty.EASY,
    val level: Int = 1,
    val currentMaze: Maze? = null,
    val playerPosition: Position = Position(1, 1),
    val starPositions: Set<Position> = emptySet(),
    val enemyPositions: List<Position> = emptyList(),
    val hearts: Int = 3,
    val maxHearts: Int = 3,
    val isInvincible: Boolean = false,
    val starsCollectedThisRun: Int = 0,
    val totalStarsThisRun: Int = 0,
    val totalCoins: Int = 0,
    val highLevel: Int = 1,
    val selectedAvatar: String = "😀",
    val unlockedAvatars: Set<String> = setOf("😀"),
    val enemiesEnabled: Boolean = true,
    val scanlinesEnabled: Boolean = true,
    val screenShakeTrigger: Int = 0, // Incremented on damage/collection to trigger visual feedback
    val lastActionMessage: String = ""
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("retro_emoji_maze_prefs", Context.MODE_PRIVATE)
    private val _uiState = MutableStateFlow(GameUIState())
    val uiState: StateFlow<GameUIState> = _uiState.asStateFlow()

    private var enemyTimerJob: Job? = null
    private var invincibilityJob: Job? = null

    // Avatars Catalog
    val avatarsCatalog = listOf(
        Avatar("😀", "Happy Smiley", 0, "Smiley", true),
        Avatar("😎", "Cool Neon", 15, "Smiley"),
        Avatar("🤠", "Retro Cowboy", 30, "Smiley"),
        Avatar("🤡", "Arcade Clown", 50, "Smiley"),
        Avatar("👾", "Space Invader", 40, "Retro"),
        Avatar("🤖", "Robo Pixel", 60, "Retro"),
        Avatar("👽", "Cosmic Alien", 120, "Retro"),
        Avatar("🔮", "Magic Orb", 180, "Retro"),
        Avatar("🐱", "Neko Kitty", 25, "Animals"),
        Avatar("🐸", "Crono Frog", 45, "Animals"),
        Avatar("🐙", "Oishi Octopus", 75, "Animals"),
        Avatar("🦄", "Dream Corn", 100, "Animals"),
        Avatar("🐉", "Dragon Quest", 150, "Animals"),
        Avatar("❤️", "Retro Heart", 20, "Love/Items"),
        Avatar("💖", "Vibrant Heart", 55, "Love/Items"),
        Avatar("🍕", "Pixel Pizza", 70, "Love/Items"),
        Avatar("💎", "Classic Gem", 110, "Love/Items"),
        Avatar("🏁", "Checker Finish", 200, "Love/Items")
    )

    init {
        loadPersistedState()
    }

    private fun loadPersistedState() {
        val coins = prefs.getInt("total_coins", 0)
        val highLevel = prefs.getInt("high_level", 1)
        val selectedAvatar = prefs.getString("selected_avatar", "😀") ?: "😀"
        val unlockedSet = prefs.getStringSet("unlocked_avatars", setOf("😀")) ?: setOf("😀")
        val enemiesOn = prefs.getBoolean("enemies_enabled", true)
        val scanOn = prefs.getBoolean("scanlines_enabled", true)

        _uiState.update {
            it.copy(
                totalCoins = coins,
                highLevel = highLevel,
                selectedAvatar = selectedAvatar,
                unlockedAvatars = unlockedSet,
                enemiesEnabled = enemiesOn,
                scanlinesEnabled = scanOn
            )
        }
    }

    fun toggleEnemies() {
        _uiState.update {
            val nextVal = !it.enemiesEnabled
            prefs.edit().putBoolean("enemies_enabled", nextVal).apply()
            it.copy(enemiesEnabled = nextVal)
        }
    }

    fun toggleScanlines() {
        _uiState.update {
            val nextVal = !it.scanlinesEnabled
            prefs.edit().putBoolean("scanlines_enabled", nextVal).apply()
            it.copy(scanlinesEnabled = nextVal)
        }
    }

    fun selectDifficulty(difficulty: Difficulty) {
        _uiState.update { it.copy(difficulty = difficulty) }
    }

    fun startNewGame() {
        stopGameTimer()
        val currentDiff = _uiState.value.difficulty
        val maze = MazeGenerator.generate(currentDiff.rows, currentDiff.cols, currentDiff.starCount)

        // Find positions of stars on the board
        val starPos = mutableSetOf<Position>()
        for (r in 0 until maze.rows) {
            for (c in 0 until maze.cols) {
                if (maze.grid[r][c] == TileType.STAR) {
                    starPos.add(Position(r, c))
                }
            }
        }

        // Place enemies away from start (e.g. at least distance of 4)
        val enemyPos = mutableListOf<Position>()
        if (_uiState.value.enemiesEnabled) {
            val potentialEnemySpots = mutableListOf<Position>()
            for (r in 2 until maze.rows - 1) {
                for (c in 2 until maze.cols - 1) {
                    if (maze.grid[r][c] == TileType.PATH || maze.grid[r][c] == TileType.STAR) {
                        if (r + c > 5) { // Farther from starting (1, 1) cell
                            potentialEnemySpots.add(Position(r, c))
                        }
                    }
                }
            }
            potentialEnemySpots.shuffle()
            val enemiesCount = minOf(currentDiff.enemyCount, potentialEnemySpots.size)
            for (i in 0 until enemiesCount) {
                enemyPos.add(potentialEnemySpots[i])
            }
        }

        _uiState.update {
            it.copy(
                gameState = GameState.PLAYING,
                currentMaze = maze,
                playerPosition = Position(1, 1),
                starPositions = starPos,
                enemyPositions = enemyPos,
                hearts = 3,
                isInvincible = false,
                starsCollectedThisRun = 0,
                totalStarsThisRun = starPos.size,
                lastActionMessage = "Navigate to the finish 🏁!"
            )
        }

        startGameTimer()
    }

    fun movePlayer(dr: Int, dc: Int) {
        if (_uiState.value.gameState != GameState.PLAYING) return
        val currentState = _uiState.value
        val maze = currentState.currentMaze ?: return

        val nextPos = currentState.playerPosition.move(dr, dc)
        if (!maze.isWalkable(nextPos.r, nextPos.c)) {
            // Can't walk
            return
        }

        // Walkable! Move player
        _uiState.update { it.copy(playerPosition = nextPos) }

        // Core Collision actions
        checkCollisions()
    }

    private fun checkCollisions() {
        val state = _uiState.value
        val player = state.playerPosition
        val maze = state.currentMaze ?: return

        // 1. Check Ghost collision
        if (state.enemyPositions.contains(player) && !state.isInvincible) {
            handleDamage()
            return
        }

        // 2. Check Star collection
        if (state.starPositions.contains(player)) {
            val nextStars = state.starPositions.toMutableSet().apply { remove(player) }
            val rewardCoins = 5
            val updatedCoins = state.totalCoins + rewardCoins
            prefs.edit().putInt("total_coins", updatedCoins).apply()

            _uiState.update {
                it.copy(
                    starPositions = nextStars,
                    starsCollectedThisRun = state.starsCollectedThisRun + 1,
                    totalCoins = updatedCoins,
                    screenShakeTrigger = state.screenShakeTrigger + 1,
                    lastActionMessage = "Collected star (+5 Stars)!"
                )
            }
            triggerVibration(50)
        }

        // 3. Check Exit portal
        val cellType = maze.grid[player.r][player.c]
        if (cellType == TileType.EXIT) {
            handleLevelDone()
        }
    }

    private fun handleDamage() {
        val state = _uiState.value
        val nextHearts = state.hearts - 1
        triggerVibration(300)

        if (nextHearts <= 0) {
            stopGameTimer()
            _uiState.update {
                it.copy(
                    gameState = GameState.GAME_OVER,
                    hearts = 0,
                    lastActionMessage = "Game Over! Hit by a ghost."
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    hearts = nextHearts,
                    isInvincible = true,
                    screenShakeTrigger = state.screenShakeTrigger + 1,
                    lastActionMessage = "Oops! Hit a ghost 👻"
                )
            }
            // Invincibility flashing timer
            invincibilityJob?.cancel()
            invincibilityJob = viewModelScope.launch {
                delay(1500)
                _uiState.update { it.copy(isInvincible = false) }
            }
        }
    }

    private fun handleLevelDone() {
        stopGameTimer()
        val state = _uiState.value
        val didCollectAll = state.starsCollectedThisRun == state.totalStarsThisRun
        val completionBonus = if (didCollectAll) 30 else 15
        
        // Save stats
        val nextLevel = state.level + 1
        val updatedCoins = state.totalCoins + completionBonus
        val nextHighLevel = maxOf(state.highLevel, nextLevel)

        prefs.edit()
            .putInt("total_coins", updatedCoins)
            .putInt("high_level", nextHighLevel)
            .apply()

        _uiState.update {
            it.copy(
                gameState = GameState.LEVEL_COMPLETE,
                level = nextLevel,
                totalCoins = updatedCoins,
                highLevel = nextHighLevel,
                lastActionMessage = if (didCollectAll) "Perfect Level Clear! (+30 Stars Bonus)" else "Level Completed! (+15 Stars Bonus)"
            )
        }
        triggerVibration(150)
    }

    fun restartCurrentLevel() {
        startNewGame()
    }

    fun resetWholeGame() {
        prefs.edit().clear().apply()
        loadPersistedState()
        _uiState.update {
            it.copy(
                gameState = GameState.MENU,
                level = 1
            )
        }
    }

    // Purchase / Unlock Avatar
    fun purchaseAvatar(avatar: Avatar): Boolean {
        val state = _uiState.value
        if (state.unlockedAvatars.contains(avatar.emoji)) {
            // Already unlocked, select it directly
            selectAvatar(avatar.emoji)
            return true
        }

        if (state.totalCoins >= avatar.cost) {
            val updatedCoins = state.totalCoins - avatar.cost
            val updatedUnlocked = state.unlockedAvatars.toMutableSet().apply { add(avatar.emoji) }

            prefs.edit()
                .putInt("total_coins", updatedCoins)
                .putStringSet("unlocked_avatars", updatedUnlocked)
                .putString("selected_avatar", avatar.emoji)
                .apply()

            _uiState.update {
                it.copy(
                    totalCoins = updatedCoins,
                    unlockedAvatars = updatedUnlocked,
                    selectedAvatar = avatar.emoji,
                    lastActionMessage = "${avatar.name} Avatar Unlocked!"
                )
            }
            triggerVibration(100)
            return true
        }
        return false // Not enough coins
    }

    fun selectAvatar(emoji: String) {
        val state = _uiState.value
        if (state.unlockedAvatars.contains(emoji)) {
            prefs.edit().putString("selected_avatar", emoji).apply()
            _uiState.update {
                it.copy(
                    selectedAvatar = emoji,
                    lastActionMessage = "Avatar set to $emoji"
                )
            }
            triggerVibration(50)
        }
    }

    // Ghost/Enemy chasing AI loop
    private fun startGameTimer() {
        if (!_uiState.value.enemiesEnabled) return
        enemyTimerJob?.cancel()
        enemyTimerJob = viewModelScope.launch {
            while (true) {
                delay(550 - minOf(200, _uiState.value.level * 15).toLong()) // Speeds up slightly as level gets higher!
                if (_uiState.value.gameState == GameState.PLAYING) {
                    moveEnemies()
                }
            }
        }
    }

    private fun stopGameTimer() {
        enemyTimerJob?.cancel()
        enemyTimerJob = null
    }

    private fun moveEnemies() {
        val state = _uiState.value
        val maze = state.currentMaze ?: return
        val player = state.playerPosition
        val currentEnemies = state.enemyPositions

        val nextGhostPositions = currentEnemies.map { ghostPos ->
            // Look for valid pathways around ghost
            val validNeighbors = listOf(
                Position(ghostPos.r - 1, ghostPos.c),
                Position(ghostPos.r + 1, ghostPos.c),
                Position(ghostPos.r, ghostPos.c - 1),
                Position(ghostPos.r, ghostPos.c + 1)
            ).filter { maze.isWalkable(it.r, it.c) }

            if (validNeighbors.isEmpty()) {
                ghostPos
            } else {
                // Retro AI logic: 20% chase player bias, 80% random walk to prevent instant wall trapping
                val chaseChance = Random.nextFloat()
                if (chaseChance < 0.25f) {
                    // Try to pick neighbor who reduces taxicab distance to the player
                    validNeighbors.minByOrNull { neighbor ->
                        val dr = Math.abs(neighbor.r - player.r)
                        val dc = Math.abs(neighbor.c - player.c)
                        dr + dc
                    } ?: validNeighbors.random()
                } else {
                    validNeighbors.random()
                }
            }
        }

        _uiState.update {
            it.copy(enemyPositions = nextGhostPositions)
        }

        // Perform final damage checking post-ghost movement
        checkCollisions()
    }

    fun returnToMenu() {
        stopGameTimer()
        _uiState.update { it.copy(gameState = GameState.MENU) }
    }

    fun openShop() {
        stopGameTimer()
        _uiState.update { it.copy(gameState = GameState.SHOP) }
    }

    fun openInstructions() {
        stopGameTimer()
        _uiState.update { it.copy(gameState = GameState.INSTRUCTIONS) }
    }

    private fun triggerVibration(durationMs: Long) {
        try {
            val context = getApplication<Application>().applicationContext
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {
            // Ignore vibration exceptions if hardware or permission is unavailable
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopGameTimer()
        invincibilityJob?.cancel()
    }
}
