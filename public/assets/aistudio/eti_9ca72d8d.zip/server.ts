import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const PORT = 3000;

function buildFallbackCBTAnalysis(
  mood: string,
  originalThought: string,
  distortions: string[],
  rationalThought: string
): string {
  const distText =
    distortions.length > 0
      ? distortions.join(", ")
      : "автоматические негативные обобщения";

  return [
    `1. Эмпатия и принятие чувств`,
    `Совершенно естественно испытывать состояние «${mood}», когда в голове звучит мысль: «${originalThought}». Ваши переживания важны и понятны — психика пытается предупредить вас о возможной угрозе, даже если сгущает краски.`,
    ``,
    `2. Разбор когнитивных искажений`,
    `В этой записи заметно влияние механизма «${distText}». Когда мы опираемся на это искажение, мозг фокусируется только на самом тревожном сценарии и игнорирует нейтральные или поддерживающие факты.`,
    ``,
    `3. Поддержка рационального ответа`,
    `Ваш переформулированный взгляд — «${rationalThought || "Я справлюсь с ситуацией шаг за шагом, опираясь на реальные факты"}» — звучит гораздо более взвешенно и реалистично. Он возвращает вам точку опоры и снижает эмоциональное давление.`,
    ``,
    `4. Практический шаг осознанности`,
    `Сделайте 3 цикла квадратного дыхания (4-4-4-4), мягко опустите плечи и назовите про себя три конкретных факта, которые уже сейчас находятся под вашим контролем. Помните: я ваш ИИ-компаньон по самопомощи, а не врач.`
  ].join("\n");
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "2mb" }));

  app.post("/api/cbt/analyze", async (req, res) => {
    const {
      mood = "Тревога",
      originalThought = "",
      distortions = [],
      rationalThought = "",
    } = req.body || {};

    if (!originalThought || typeof originalThought !== "string" || !originalThought.trim()) {
      res.status(400).json({ error: "Пожалуйста, опишите тревожную мысль для анализа." });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
      res.json({
        feedback: buildFallbackCBTAnalysis(
          mood,
          originalThought.trim(),
          Array.isArray(distortions) ? distortions : [],
          rationalThought
        ),
        source: "companion-fallback",
      });
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const systemInstruction = `You are an expert mental wellness companion and compassionate CBT (Cognitive Behavioral Therapy) guide.
The user is logging a CBT thought record in the MindSync app.
Your role is to:
1. Validate their feelings with empathy and deep understanding, utilizing a warm, gentle, therapeutic tone.
2. Analyze the original distressed thought they logged, explaining how the selected cognitive distortions interact with their distress.
3. Review and support their rational, reframed balanced thought. Offer some extra light reframing suggestions if helpful.
4. Suggest a simple, constructive mindfulness exercise or proactive cognitive step related to their issue.
Keep your response structured, friendly, concise, and divided into clear numbered sections (without markdown code blocks). Remind them gently that you are an AI wellness companion, not a doctor. Write in Russian.`;

      const userPrompt = `Mood currently feeling: ${mood}
Distressed Thought: "${originalThought}"
Selected Cognitive Distortions: ${Array.isArray(distortions) ? distortions.join(", ") : ""}
Re-framed Balanced Thought: "${rationalThought}"`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: userPrompt,
        config: {
          systemInstruction,
        },
      });

      const feedbackText =
        response.text ||
        buildFallbackCBTAnalysis(
          mood,
          originalThought.trim(),
          Array.isArray(distortions) ? distortions : [],
          rationalThought
        );

      res.json({
        feedback: feedbackText,
        source: "gemini-3.8-flash",
      });
    } catch (error: unknown) {
      console.warn("Gemini API fallback triggered:", error instanceof Error ? error.message : error);
      res.json({
        feedback: buildFallbackCBTAnalysis(
          mood,
          originalThought.trim(),
          Array.isArray(distortions) ? distortions : [],
          rationalThought
        ),
        source: "companion-fallback",
      });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
