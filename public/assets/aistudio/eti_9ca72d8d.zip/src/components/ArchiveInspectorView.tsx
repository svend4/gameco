import React, { useState } from "react";
import { Download, FileCode, FolderArchive, CheckCircle2 } from "lucide-react";
import { ATTACHED_ARCHIVES, type ProjectArchiveInfo } from "../data/archivesData";

export const ArchiveInspectorView: React.FC = () => {
  const [selectedArchive, setSelectedArchive] = useState<ProjectArchiveInfo>(ATTACHED_ARCHIVES[0]);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);

  const activeFile =
    selectedArchive.files[selectedFileIndex] || selectedArchive.files[0];

  return (
    <div
      className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8"
      data-testid="archive-inspector-root"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-extrabold text-white">
            Архивы исходного кода Android (Kotlin &amp; Jetpack Compose)
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Полный обзор и прямое скачивание обоих прикрепленных архивов: Surreal Circus и MindSync
          </p>
        </div>

        <div className="flex items-center gap-2">
          {ATTACHED_ARCHIVES.map((arch) => {
            const isSelected = arch.id === selectedArchive.id;
            return (
              <button
                key={arch.id}
                type="button"
                onClick={() => {
                  setSelectedArchive(arch);
                  setSelectedFileIndex(0);
                }}
                data-testid={`select-archive-${arch.id}`}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                  isSelected
                    ? "bg-indigo-500 text-white"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                {arch.name} (.zip)
              </button>
            );
          })}
        </div>
      </div>

      {/* Archive Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
        {ATTACHED_ARCHIVES.map((arch) => (
          <div
            key={arch.id}
            className={`rounded-2xl border p-5 flex flex-col justify-between ${
              arch.id === selectedArchive.id
                ? "border-indigo-500/50 bg-indigo-950/20"
                : "border-slate-800 bg-slate-950/50"
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 min-w-0">
                  <FolderArchive className="w-5 h-5 text-indigo-400 shrink-0" />
                  <h2 className="text-lg font-bold text-white truncate">{arch.ruTitle}</h2>
                </div>
                <span className="text-xs font-mono text-slate-400 whitespace-nowrap shrink-0">
                  {arch.zipFilename}
                </span>
              </div>

              <div className="text-xs font-mono text-indigo-300 mb-3">
                applicationId: {arch.packageId} · {arch.sdkInfo}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed mb-4">{arch.description}</p>

              <ul className="space-y-1.5 mb-5">
                {arch.highlights.map((item) => (
                  <li key={item} className="text-xs text-slate-300 flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between gap-3 pt-4 border-t border-slate-800/80">
              <button
                type="button"
                onClick={() => {
                  setSelectedArchive(arch);
                  setSelectedFileIndex(0);
                }}
                className="text-xs font-semibold text-indigo-300 hover:text-indigo-200 cursor-pointer"
              >
                Просмотреть исходники ({arch.files.length} ключевых модуля)
              </button>

              <a
                href={arch.zipUrl}
                download={arch.zipFilename}
                data-testid={`download-zip-${arch.id}`}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Скачать {arch.name}.zip</span>
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Ключевые файлы ({selectedArchive.name})
          </div>
          {selectedArchive.files.map((file, idx) => {
            const active = idx === selectedFileIndex;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedFileIndex(idx)}
                className={`w-full text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
                  active
                    ? "border-indigo-400 bg-indigo-500/15"
                    : "border-slate-800 bg-slate-950/60 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-white truncate">
                  <FileCode className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span className="truncate">{file.path}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{file.summary}</p>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-8 rounded-2xl border border-slate-800 bg-slate-950 p-5 overflow-x-auto">
          <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
            <span className="text-xs font-mono text-indigo-300">{activeFile.path}</span>
            <span className="text-xs font-mono text-slate-400">{activeFile.language}</span>
          </div>
          <pre className="text-xs font-mono text-slate-200 leading-relaxed overflow-x-auto">
            <code>{activeFile.code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
