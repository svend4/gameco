import React, { useEffect, useRef, useState } from "react";
import {
  Sparkles,
  Volume2,
  VolumeX,
  Palette,
  Compass,
  Orbit,
  CircleDot,
  Trash2,
  ArrowLeft,
  RotateCcw,
  Play,
  Network,
  Zap,
  Flame,
} from "lucide-react";
import {
  PENTATONIC_NOTES,
  SURREAL_THEMES,
  ThemePreset,
  DreamRecordItem,
  calculateFunnelHit,
  calculateCarouselFusionScore,
  project3DPoint,
  rotate3DPoint,
  mergeBubbleRadii,
  getBestScoreForAttraction,
} from "../utils/appLogic";
import { soundEngine } from "../utils/soundEngine";

export type CircusSubScreen = "dashboard" | "funnel" | "carousel" | "bubbles";

interface SurrealCircusViewProps {
  activeScreen: CircusSubScreen;
  onSelectScreen: (screen: CircusSubScreen) => void;
  theme: ThemePreset;
  onCycleTheme: () => void;
  onSelectTheme?: (index: number) => void;
  records: DreamRecordItem[];
  onSaveRecord: (attractionName: string, score: number, noteChainLength: number) => void;
  onClearRecords: () => void;
  onOpenCodex?: () => void;
}

interface Star3D {
  x: number;
  y: number;
  z: number;
  speed: number;
  colorIndex: number;
}

interface DreamSphere {
  id: number;
  x: number;
  y: number;
  z: number;
  radius: number;
  color: string;
  noteIndex: number;
  speed: number;
  rotationAngle: number;
  isCaught: boolean;
  isMissed: boolean;
  fadeAlpha: number;
  trail: Array<{ x: number; y: number; z: number }>;
}

interface FunnelBurstParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
}

interface FloatingScorePopup {
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
}

interface CarouselStar {
  id: number;
  baseX: number;
  baseY: number;
  baseZ: number;
  rotatedX: number;
  rotatedY: number;
  rotatedZ: number;
  color: string;
  colorIndex: number;
  isSelected: boolean;
  pulse: number;
}

interface EtherealBubble {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  noteIndex: number;
  z: number;
  wobble: number;
  isPopped: boolean;
  popProgress: number;
  sigilIndex: number;
}

const NOTE_LABELS = ["C4", "D4", "E4", "G4", "A4", "C5", "D5", "E5", "G5", "A5"];
const ALCHEMICAL_SIGILS = ["☉", "☽", "△", "▽", "✧", "⬡", "◈", "∞"];

// 16 vertices of a 4D Tesseract (Hypercube) with coordinates in {-1, +1}^4
const TESSERACT_VERTICES: Array<[number, number, number, number]> = [];
for (let i = 0; i < 16; i++) {
  TESSERACT_VERTICES.push([
    i & 1 ? 1 : -1,
    i & 2 ? 1 : -1,
    i & 4 ? 1 : -1,
    i & 8 ? 1 : -1,
  ]);
}
const TESSERACT_EDGES: Array<[number, number]> = [];
for (let i = 0; i < 16; i++) {
  for (let j = i + 1; j < 16; j++) {
    const diff = i ^ j;
    if (diff && (diff & (diff - 1)) === 0) {
      TESSERACT_EDGES.push([i, j]);
    }
  }
}

export const SurrealCircusView: React.FC<SurrealCircusViewProps> = ({
  activeScreen,
  onSelectScreen,
  theme,
  onCycleTheme,
  onSelectTheme,
  records,
  onSaveRecord,
  onClearRecords,
  onOpenCodex,
}) => {
  const [soundEnabled, setSoundEnabled] = useState<boolean>(soundEngine.isEnabled());
  const [activeNoteIdx, setActiveNoteIdx] = useState<number | null>(null);
  const [vfxOverdrive, setVfxOverdrive] = useState<boolean>(true);
  const heroPortalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pulseWaveRef = useRef<number>(0);

  const toggleAudio = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.setEnabled(next);
    if (next) {
      soundEngine.playGateWelcome();
    }
  };

  const triggerSynthNote = (idx: number) => {
    setActiveNoteIdx(idx);
    pulseWaveRef.current = 1.0;
    soundEngine.playNoteIndex(idx, 360);
    setTimeout(() => {
      setActiveNoteIdx((prev) => (prev === idx ? null : prev));
    }, 280);
  };

  // Ambient 60fps Obsidian-Stargate Holo-Visualizer in Dashboard Hero
  useEffect(() => {
    if (activeScreen !== "dashboard") return;
    let animId = 0;
    let t = 0;

    const renderHeroPortal = () => {
      t += vfxOverdrive ? 0.028 : 0.014;
      pulseWaveRef.current = Math.max(0, pulseWaveRef.current * 0.93);
      const canvas = heroPortalCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          const cx = w / 2;
          const cy = h / 2;

          ctx.clearRect(0, 0, w, h);

          // 1. Deep Obsidian Void & Radial Nebula Glow
          const bgGrad = ctx.createRadialGradient(cx, cy, 4, cx, cy, w * 0.52);
          bgGrad.addColorStop(0, `${theme.secondaryAccent}44`);
          bgGrad.addColorStop(0.45, `${theme.primaryAccent}22`);
          bgGrad.addColorStop(1, "rgba(5, 7, 15, 0)");
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, w, h);

          // 2. Rotating 4D Tesseract Wireframe inside the Stargate
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          const projectedVerts: Array<{ x: number; y: number }> = [];
          const scale4D = 32 + pulseWaveRef.current * 14;
          for (const [vx, vy, vz, vw] of TESSERACT_VERTICES) {
            // Rotate in XW and ZW 4D planes
            const cos1 = Math.cos(t * 0.9);
            const sin1 = Math.sin(t * 0.9);
            const x1 = vx * cos1 - vw * sin1;
            const w1 = vx * sin1 + vw * cos1;

            const cos2 = Math.cos(t * 0.65);
            const sin2 = Math.sin(t * 0.65);
            const z2 = vz * cos2 - w1 * sin2;
            const w2 = vz * sin2 + w1 * cos2;

            const d4 = 2.6 / (2.6 - w2 * 0.45);
            const rx = x1 * d4;
            const ry = vy * d4;
            const rz = z2 * d4;

            const rot3 = rotate3DPoint(rx * scale4D, ry * scale4D, rz * scale4D, 0.35, t * 0.5);
            const p2 = project3DPoint(rot3.rx, rot3.ry, rot3.rz, cx, cy, 220, 220);
            projectedVerts.push({ x: p2.px, y: p2.py });
          }

          ctx.strokeStyle = `${theme.secondaryAccent}88`;
          ctx.lineWidth = 1.3;
          for (const [a, b] of TESSERACT_EDGES) {
            ctx.beginPath();
            ctx.moveTo(projectedVerts[a].x, projectedVerts[a].y);
            ctx.lineTo(projectedVerts[b].x, projectedVerts[b].y);
            ctx.stroke();
          }

          // 3. Outer Stargate Ring & 9 Glowing Chevrons
          const gateR = 64 + Math.sin(t * 2) * 2 + pulseWaveRef.current * 8;
          ctx.strokeStyle = theme.primaryAccent;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(cx, cy, gateR, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = `${theme.secondaryAccent}66`;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(cx, cy, gateR - 8, 0, Math.PI * 2);
          ctx.stroke();

          for (let c = 0; c < 9; c++) {
            const ang = (c / 9) * Math.PI * 2 + t * 0.35;
            const chX = cx + Math.cos(ang) * gateR;
            const chY = cy + Math.sin(ang) * gateR;
            ctx.fillStyle = c % 2 === 0 ? theme.starColor : theme.secondaryAccent;
            ctx.beginPath();
            ctx.arc(chX, chY, 3.8 + pulseWaveRef.current * 2, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
      }
      animId = requestAnimationFrame(renderHeroPortal);
    };

    animId = requestAnimationFrame(renderHeroPortal);
    return () => cancelAnimationFrame(animId);
  }, [activeScreen, theme, vfxOverdrive]);

  const funnelBest = getBestScoreForAttraction(records, "Ловец Сфер", 0);
  const carouselBest = getBestScoreForAttraction(records, "Карусель Звезд", 0);
  const bubblesBest = getBestScoreForAttraction(records, "Сферы Эфира", 0);

  if (activeScreen === "funnel") {
    return (
      <AttractionGravityFunnelCanvas
        theme={theme}
        highScore={funnelBest}
        vfxOverdrive={vfxOverdrive}
        onToggleVfx={() => setVfxOverdrive((v) => !v)}
        onBack={(score, maxStreak) => {
          if (score > 0) onSaveRecord("Ловец Сфер", score, maxStreak);
          onSelectScreen("dashboard");
        }}
        onSaveScore={(score, maxStreak) => {
          if (score > 0) onSaveRecord("Ловец Сфер", score, maxStreak);
        }}
      />
    );
  }

  if (activeScreen === "carousel") {
    return (
      <AttractionCelestialCarouselCanvas
        theme={theme}
        highScore={carouselBest}
        vfxOverdrive={vfxOverdrive}
        onToggleVfx={() => setVfxOverdrive((v) => !v)}
        onBack={(score, scaleCount) => {
          if (score > 0) onSaveRecord("Карусель Звезд", score, scaleCount);
          onSelectScreen("dashboard");
        }}
        onSaveScore={(score, scaleCount) => {
          if (score > 0) onSaveRecord("Карусель Звезд", score, scaleCount);
        }}
      />
    );
  }

  if (activeScreen === "bubbles") {
    return (
      <AttractionEtherealBubblesCanvas
        theme={theme}
        highScore={bubblesBest}
        vfxOverdrive={vfxOverdrive}
        onToggleVfx={() => setVfxOverdrive((v) => !v)}
        onBack={(score, splitCount) => {
          if (score > 0) onSaveRecord("Сферы Эфира", score, splitCount);
          onSelectScreen("dashboard");
        }}
        onSaveScore={(score, splitCount) => {
          if (score > 0) onSaveRecord("Сферы Эфира", score, splitCount);
        }}
      />
    );
  }

  return (
    <div
      className="rounded-3xl border border-white/15 p-6 md:p-8 transition-colors duration-300 relative overflow-hidden"
      style={{
        background: `radial-gradient(circle at 18% 15%, ${theme.primaryAccent}22 0%, transparent 45%), radial-gradient(circle at 85% 25%, ${theme.secondaryAccent}20 0%, transparent 48%), linear-gradient(180deg, ${theme.bgGradient[0]} 0%, ${theme.bgGradient[1]} 52%, ${theme.bgGradient[2]} 100%)`,
      }}
      data-testid="circus-dashboard-root"
    >
      {/* Top Hero & Theme Switcher Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 flex flex-col justify-between rounded-2xl border border-white/15 bg-black/40 p-6 md:p-8 backdrop-blur-md">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
            <div className="flex-1">
              <p
                className="text-xs font-semibold tracking-wider uppercase mb-2"
                style={{ color: theme.primaryAccent }}
              >
                Часть 1 · Внешний Астрал Космонавта · Псевдо-Обсидиан × Stargate 4D
              </p>
              <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-white mb-3">
                Сюрреалистический Цирк Снов: Звёздный Мост 4D
              </h1>
              <p className="text-sm text-slate-300 leading-relaxed">
                Внешнее пространство вокруг медитирующего Аватара-Навигатора: зеркальная
                псевдо-обсидиановая трасса сквозь 4-е осевое измерение, квантовый горизонт событий
                Stargate (9 шевронов), вращающийся гиперкуб-тессеракт и алхимические сосуды эфира.
              </p>

              <div className="mt-4 flex flex-wrap items-center gap-2.5">
                {onOpenCodex && (
                  <button
                    type="button"
                    onClick={onOpenCodex}
                    data-testid="open-cosmology-codex-button"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-white/20 bg-white/10 hover:bg-white/15 text-xs font-bold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Network className="w-3.5 h-3.5" style={{ color: theme.secondaryAccent }} />
                    <span>Кодекс Междумирья и Граф 4D →</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setVfxOverdrive((prev) => !prev);
                    pulseWaveRef.current = 1.4;
                    soundEngine.playArpeggio(2);
                  }}
                  data-testid="toggle-vfx-overdrive-button"
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    vfxOverdrive
                      ? "border-cyan-400/50 bg-cyan-500/20 text-cyan-200 shadow-lg shadow-cyan-500/15"
                      : "border-white/15 bg-white/5 text-slate-300"
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Спецэффекты Ultra VFX: {vfxOverdrive ? "МАКС" : "СТАНДАРТ"}</span>
                </button>
              </div>
            </div>

            {/* Live 4D Tesseract + Stargate Holo-Portal Preview */}
            <div className="shrink-0 mx-auto md:mx-0 flex flex-col items-center">
              <div className="rounded-2xl border border-white/15 bg-[#050711]/90 p-1.5 shadow-inner">
                <canvas
                  ref={heroPortalCanvasRef}
                  width={168}
                  height={168}
                  onClick={() => {
                    pulseWaveRef.current = 1.6;
                    soundEngine.playArpeggio(0);
                  }}
                  title="Нажмите для квантового импульса Тессеракта"
                  className="w-[148px] h-[148px] block cursor-pointer"
                />
              </div>
              <span className="text-[10px] font-mono text-slate-400 mt-1.5">
                4D-Тессеракт × Врата (Живой шейдер)
              </span>
            </div>
          </div>

          {/* Interactive 10-Note Pentatonic Soundboard */}
          <div className="mt-6 pt-5 border-t border-white/10">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" style={{ color: theme.secondaryAccent }} />
                Пентатонический резонатор Звёздных Врат (10 частот гармонии)
              </span>
              <button
                type="button"
                onClick={toggleAudio}
                data-testid="toggle-audio-button"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/15 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {soundEnabled ? (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Звук вкл.</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                    <span>Звук выкл.</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
              {PENTATONIC_NOTES.map((freq, idx) => {
                const isPlaying = activeNoteIdx === idx;
                const noteColor = theme.bubbleColors[idx % theme.bubbleColors.length];
                return (
                  <button
                    key={NOTE_LABELS[idx]}
                    type="button"
                    onClick={() => triggerSynthNote(idx)}
                    className="py-2 px-1 rounded-lg border text-center transition-all active:scale-95 cursor-pointer"
                    style={{
                      borderColor: isPlaying ? noteColor : "rgba(255,255,255,0.12)",
                      backgroundColor: isPlaying
                        ? `${noteColor}33`
                        : "rgba(15, 23, 42, 0.65)",
                      boxShadow: isPlaying ? `0 0 18px ${noteColor}66` : "none",
                    }}
                    aria-label={`Нота ${NOTE_LABELS[idx]}`}
                  >
                    <div className="text-xs font-bold text-white">{NOTE_LABELS[idx]}</div>
                    <div className="text-[10px] font-mono tabular-nums text-slate-400">
                      {Math.round(freq)}Гц
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Active Dimension Theme Card */}
        <div
          className="lg:col-span-5 flex flex-col justify-between rounded-2xl border p-6 md:p-8 backdrop-blur-md"
          style={{
            backgroundColor: theme.surfaceColor,
            borderColor: `${theme.secondaryAccent}55`,
            boxShadow: `inset 0 0 36px ${theme.primaryAccent}14`,
          }}
          data-testid="theme-switcher-card"
        >
          <div>
            <div
              className="text-xs font-semibold tracking-wider uppercase mb-1"
              style={{ color: theme.secondaryAccent }}
            >
              {theme.stargateTitle} ({theme.index + 1} из 4)
            </div>
            <h2 className="text-2xl font-bold text-white mb-1.5">{theme.name}</h2>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">{theme.description}</p>

            {/* 4 Dimension Quick-Select Grid */}
            <div className="grid grid-cols-2 gap-2 my-3">
              {SURREAL_THEMES.map((preset) => {
                const isCurrent = preset.index === theme.index;
                return (
                  <button
                    key={preset.index}
                    type="button"
                    onClick={() => (onSelectTheme ? onSelectTheme(preset.index) : onCycleTheme())}
                    className={`p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      isCurrent
                        ? "bg-white/15 border-white/45"
                        : "bg-black/30 border-white/10 hover:border-white/25"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <span
                        className="w-2 h-2 rounded-sm shrink-0"
                        style={{ backgroundColor: preset.primaryAccent }}
                      />
                      <span
                        className="w-2 h-2 rounded-sm shrink-0"
                        style={{ backgroundColor: preset.secondaryAccent }}
                      />
                      <span className="text-[10.5px] font-bold text-white whitespace-nowrap">
                        {preset.name}
                      </span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-300 whitespace-nowrap">
                      {preset.enName}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/10">
            <div className="text-xs text-slate-300">
              Пройдено переходов:{" "}
              <span className="font-mono font-bold text-white tabular-nums">{records.length}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                onCycleTheme();
                soundEngine.playArpeggio(0);
              }}
              data-testid="theme-cycle-button"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white transition-transform active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
              style={{
                backgroundColor: theme.primaryAccent,
                boxShadow: `0 6px 20px ${theme.primaryAccent}44`,
              }}
            >
              <Palette className="w-4 h-4" />
              <span>Сменить измерение</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3 Attraction Gates Section */}
      <div className="mt-8">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">
              Межлабиринтные Переходы (Шлюзы между Ёмкостями со спецэффектами 4D)
            </h2>
            <p className="text-xs text-slate-300">
              Три интерактивных коридора с объёмным свечением, зеркальным псевдо-обсидианом,
              горизонтом событий Stargate и 4D-гиперкубом
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Gate 1: Gravity Funnel */}
        <article
          className="rounded-2xl border border-white/15 bg-black/45 p-6 flex flex-col justify-between hover:border-white/35 transition-all"
          style={{
            boxShadow: `inset 0 1px 0 0 rgba(255,255,255,0.12), 0 12px 30px -10px ${theme.primaryAccent}22`,
          }}
        >
          <div>
            <div className="flex items-center justify-between gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center border"
                style={{
                  backgroundColor: `${theme.primaryAccent}22`,
                  borderColor: `${theme.primaryAccent}66`,
                  color: theme.primaryAccent,
                }}
              >
                <Compass className="w-6 h-6" />
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-300">
                Рекорд: <strong className="text-white">{funnelBest}</strong> очков
              </span>
            </div>
            <div className="text-[11px] font-mono text-pink-300 mb-1">
              ШЛЮЗ I · STARGATE KAWOOSH + ЗЕРКАЛЬНЫЙ ОБСИДИАН
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Ловцы Блуждающих Сфер</h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Псевдо-обсидиановая трасса с зеркальным отражением, 9 вращающимися шевронами Stargate,
              световыми хвостами комет и параллельными потоками времени (-t, t₀, +t).
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGateWelcome();
              onSelectScreen("funnel");
            }}
            data-testid="gate-funnel"
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-white transition-opacity hover:opacity-90 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: theme.primaryAccent,
              boxShadow: `0 6px 20px ${theme.primaryAccent}40`,
            }}
          >
            <Play className="w-4 h-4" />
            <span>Войти в Звёздный Мост</span>
          </button>
        </article>

        {/* Gate 2: Celestial Carousel */}
        <article
          className="rounded-2xl border border-white/15 bg-black/45 p-6 flex flex-col justify-between hover:border-white/35 transition-all"
          style={{
            boxShadow: `inset 0 1px 0 0 rgba(255,255,255,0.12), 0 12px 30px -10px ${theme.secondaryAccent}22`,
          }}
        >
          <div>
            <div className="flex items-center justify-between gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center border"
                style={{
                  backgroundColor: `${theme.secondaryAccent}22`,
                  borderColor: `${theme.secondaryAccent}66`,
                  color: theme.secondaryAccent,
                }}
              >
                <Orbit className="w-6 h-6" />
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-300">
                Рекорд: <strong className="text-white">{carouselBest}</strong> очков
              </span>
            </div>
            <div className="text-[11px] font-mono text-cyan-300 mb-1">
              ШЛЮЗ II · 4D-ТЕССЕРАКТ + СИНАПТИЧЕСКИЙ ГРАФ OBSIDIAN
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Карусель Созвездий</h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Вращающийся 4-мерный гиперкуб-тессеракт внутри армиллярных колец. Электрические
              разряды и синаптические импульсы соединяют узлы-комнаты в живой граф.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGateWelcome();
              onSelectScreen("carousel");
            }}
            data-testid="gate-carousel"
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-950 transition-opacity hover:opacity-90 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: theme.secondaryAccent,
              boxShadow: `0 6px 20px ${theme.secondaryAccent}40`,
            }}
          >
            <Play className="w-4 h-4" />
            <span>Открыть Осевой Граф</span>
          </button>
        </article>

        {/* Gate 3: Ethereal Bubbles */}
        <article
          className="rounded-2xl border border-white/15 bg-black/45 p-6 flex flex-col justify-between hover:border-white/35 transition-all"
          style={{
            boxShadow: `inset 0 1px 0 0 rgba(255,255,255,0.12), 0 12px 30px -10px ${theme.starColor}22`,
          }}
        >
          <div>
            <div className="flex items-center justify-between gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center border"
                style={{
                  backgroundColor: `${theme.starColor}22`,
                  borderColor: `${theme.starColor}66`,
                  color: theme.starColor,
                }}
              >
                <CircleDot className="w-6 h-6" />
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-300">
                Рекорд: <strong className="text-white">{bubblesBest}</strong> очков
              </span>
            </div>
            <div className="text-[11px] font-mono text-amber-300 mb-1">
              ШЛЮЗ III · ИРИДИСЦЕНТНЫЕ СОСУДЫ + АЛХИМИЧЕСКИЕ СИГИЛЫ
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Эфирные Пузыри</h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Переливающиеся эфирные ёмкости с герметическими символами внутри, плазменными мостами
              слияния и восходящими золотыми искрами декомпрессии.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGateWelcome();
              onSelectScreen("bubbles");
            }}
            data-testid="gate-bubbles"
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-950 transition-opacity hover:opacity-90 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: theme.starColor,
              boxShadow: `0 6px 20px ${theme.starColor}40`,
            }}
          >
            <Play className="w-4 h-4" />
            <span>Войти в Шлюз Ёмкостей</span>
          </button>
        </article>
      </div>

      {/* Dream Journal Records Section */}
      <div className="mt-10 pt-8 border-t border-white/10">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Журнал Сновидений и Переходов</h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Бортовой лог Навигатора: зафиксированные проходы между ёмкостями и резонансные цепи
            </p>
          </div>
          {records.length > 0 && (
            <button
              type="button"
              onClick={onClearRecords}
              data-testid="clear-records-button"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-300 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-400/30 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Очистить журнал</span>
            </button>
          )}
        </div>

        {records.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-black/25 p-8 text-center">
            <Sparkles className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-white">Журнал сновидений пока пуст</p>
            <p className="text-xs text-slate-400 mt-1">
              Пройдите через любой из трех шлюзов выше, чтобы записать первую навигационную сессию.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="dream-records-list">
            {records.map((rec) => (
              <div
                key={rec.id}
                className="rounded-xl border border-white/10 bg-black/25 px-4 py-3.5 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="text-sm font-bold text-white">{rec.attractionName}</div>
                  <div className="flex items-center gap-2 text-xs text-slate-300 mt-1">
                    <span>{rec.themePalette}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{rec.dateString}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">цепь: x{rec.noteChainLength}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div
                    className="text-xl font-extrabold font-mono tabular-nums"
                    style={{ color: theme.secondaryAccent }}
                  >
                    {rec.score}
                  </div>
                  <div className="text-[11px] text-slate-400">очков гармонии</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// ATTRACTION 1: GRAVITY FUNNEL (Ловцы Блуждающих Сфер · Stargate 4D Road + Ultra VFX)
// ============================================================================
interface FunnelProps {
  theme: ThemePreset;
  highScore: number;
  vfxOverdrive: boolean;
  onToggleVfx: () => void;
  onBack: (score: number, maxStreak: number) => void;
  onSaveScore: (score: number, maxStreak: number) => void;
}

const AttractionGravityFunnelCanvas: React.FC<FunnelProps> = ({
  theme,
  highScore,
  vfxOverdrive,
  onToggleVfx,
  onBack,
  onSaveScore,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);

  const stateRef = useRef({
    funnelX: 0,
    score: 0,
    streak: 0,
    maxStreak: 0,
    spheres: [] as DreamSphere[],
    stars: [] as Star3D[],
    bursts: [] as FunnelBurstParticle[],
    popups: [] as FloatingScorePopup[],
    nextId: 1,
    stargateAngle: 0,
    kawooshPulse: 0.8,
    gridOffset: 0,
  });

  const spawnCatchExplosion = (px: number, py: number, color: string, gainedPoints: number) => {
    const st = stateRef.current;
    st.kawooshPulse = 1.0;
    for (let i = 0; i < 22; i++) {
      const ang = (i / 22) * Math.PI * 2 + Math.random() * 0.3;
      const spd = 2.2 + Math.random() * 6.5;
      st.bursts.push({
        x: px,
        y: py,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd - 1.5,
        color: i % 3 === 0 ? "#FFFFFF" : color,
        alpha: 1,
        size: 2.5 + Math.random() * 3.5,
      });
    }
    st.popups.push({
      x: px,
      y: py - 18,
      text: `+${gainedPoints} ГАРМОНИЯ`,
      color: "#FFFFFF",
      alpha: 1,
    });
  };

  const triggerMagneticPulse = () => {
    const st = stateRef.current;
    const active = st.spheres.filter((s) => !s.isCaught && !s.isMissed);
    if (active.length === 0) {
      const noteIdx = Math.floor(Math.random() * theme.bubbleColors.length);
      const prevScore = st.score;
      const res = calculateFunnelHit(st.score, st.streak, st.maxStreak, true);
      st.score = res.score;
      st.streak = res.streak;
      st.maxStreak = res.maxStreak;
      setScore(st.score);
      setStreak(st.streak);
      setMaxStreak(st.maxStreak);
      spawnCatchExplosion(460 + st.funnelX, 370, theme.primaryAccent, res.score - prevScore);
      soundEngine.playNoteIndex(noteIdx, 400);
      return;
    }
    active.sort((a, b) => a.z - b.z);
    const target = active[0];
    st.funnelX = target.x;
    target.isCaught = true;
    const prevScore = st.score;
    const res = calculateFunnelHit(st.score, st.streak, st.maxStreak, true);
    st.score = res.score;
    st.streak = res.streak;
    st.maxStreak = res.maxStreak;
    setScore(st.score);
    setStreak(st.streak);
    setMaxStreak(st.maxStreak);
    spawnCatchExplosion(460 + target.x, 365, target.color, res.score - prevScore);
    soundEngine.playNoteIndex(target.noteIndex, 400);
  };

  const triggerKawooshWave = () => {
    const st = stateRef.current;
    st.kawooshPulse = 1.6;
    soundEngine.playArpeggio(0);
    // Spawn a celebratory wave of 3 parallel temporal spheres (-t, t0, +t)
    const lanes = [-145, 0, 145];
    lanes.forEach((laneX, idx) => {
      const noteIdx = (idx * 3) % theme.bubbleColors.length;
      st.spheres.push({
        id: st.nextId++,
        x: laneX,
        y: 0,
        z: 960,
        radius: 28,
        color: theme.bubbleColors[noteIdx],
        noteIndex: noteIdx,
        speed: 7.2,
        rotationAngle: 0,
        isCaught: false,
        isMissed: false,
        fadeAlpha: 1,
        trail: [],
      });
    });
  };

  const handleRestart = () => {
    const st = stateRef.current;
    if (st.score > 0) {
      onSaveScore(st.score, st.maxStreak);
    }
    st.score = 0;
    st.streak = 0;
    st.maxStreak = 0;
    st.spheres = [];
    st.bursts = [];
    st.popups = [];
    st.kawooshPulse = 1.2;
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    soundEngine.playTone(392, 150);
  };

  useEffect(() => {
    const st = stateRef.current;
    st.stars = Array.from({ length: 110 }, (_, idx) => ({
      x: Math.random() * 1500 - 750,
      y: Math.random() * 1000 - 500,
      z: Math.random() * 1000,
      speed: 5 + Math.random() * 9,
      colorIndex: idx % theme.bubbleColors.length,
    }));
    st.spheres = [0, 1, 2].map((i) => ({
      id: st.nextId++,
      x: (i - 1) * 135,
      y: 0,
      z: 340 + i * 240,
      radius: 27,
      color: theme.bubbleColors[i % theme.bubbleColors.length],
      noteIndex: i % theme.bubbleColors.length,
      speed: 6.5,
      rotationAngle: 0,
      isCaught: false,
      isMissed: false,
      fadeAlpha: 1,
      trail: [],
    }));

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
        st.funnelX = Math.max(-240, st.funnelX - 36);
      } else if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
        st.funnelX = Math.min(240, st.funnelX + 36);
      } else if (e.key === " " || e.key === "Enter") {
        triggerMagneticPulse();
      }
    };
    window.addEventListener("keydown", onKeyDown);

    let animId = 0;
    const render = () => {
      const canvas = canvasRef.current;
      st.stargateAngle += vfxOverdrive ? 0.018 : 0.01;
      st.kawooshPulse = Math.max(0, st.kawooshPulse * 0.95);
      st.gridOffset = (st.gridOffset + (vfxOverdrive ? 12 : 7)) % 120;

      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;
          const centerX = width / 2;
          const horizonY = height * 0.32;
          const focalLength = 350;

          ctx.clearRect(0, 0, width, height);

          // 0. Volumetric Cosmic Nebula Background
          const spaceBg = ctx.createRadialGradient(
            centerX,
            horizonY,
            12,
            centerX,
            horizonY,
            width * 0.65
          );
          spaceBg.addColorStop(0, `${theme.secondaryAccent}38`);
          spaceBg.addColorStop(0.35, `${theme.primaryAccent}22`);
          spaceBg.addColorStop(0.75, "#060814");
          spaceBg.addColorStop(1, "#03040A");
          ctx.fillStyle = spaceBg;
          ctx.fillRect(0, 0, width, height);

          // 1. Update & Draw 3D Warp-Streak Starfield
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          for (const star of st.stars) {
            const spd = vfxOverdrive ? star.speed * 1.35 : star.speed;
            const prevZ = star.z + spd * 3.2;
            star.z -= spd;
            if (star.z < 12) {
              star.z = 1000;
              star.x = Math.random() * 1500 - 750;
              star.y = Math.random() * 1000 - 500;
            }
            const proj = project3DPoint(star.x, star.y, star.z, centerX, horizonY, focalLength, 0);
            const prevProj = project3DPoint(star.x, star.y, prevZ, centerX, horizonY, focalLength, 0);

            if (proj.px >= 0 && proj.px <= width && proj.py >= 0 && proj.py <= height) {
              const starCol = theme.bubbleColors[star.colorIndex];
              const alpha = Math.min(1, Math.max(0.18, proj.scale * 1.2));

              // Warp light streak tail
              ctx.strokeStyle = `${starCol}${Math.round(alpha * 160)
                .toString(16)
                .padStart(2, "0")}`;
              ctx.lineWidth = Math.max(1, 2.2 * proj.scale);
              ctx.beginPath();
              ctx.moveTo(prevProj.px, prevProj.py);
              ctx.lineTo(proj.px, proj.py);
              ctx.stroke();

              ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
              ctx.beginPath();
              ctx.arc(proj.px, proj.py, 2.1 * proj.scale + 0.8, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          ctx.restore();

          // 2. STARGATE EVENT HORIZON PORTAL AT THE HORIZON (centerX, horizonY)
          const gateRadius = 74 + st.kawooshPulse * 14;

          ctx.save();
          ctx.globalCompositeOperation = "lighter";

          // Volumetric God-Rays radiating from the Stargate
          for (let ray = 0; ray < 12; ray++) {
            const rayAng = (ray / 12) * Math.PI * 2 - st.stargateAngle * 0.6;
            const rLen = gateRadius * (1.55 + 0.25 * Math.sin(st.stargateAngle * 4 + ray));
            const rayGrad = ctx.createLinearGradient(
              centerX,
              horizonY,
              centerX + Math.cos(rayAng) * rLen,
              horizonY + Math.sin(rayAng) * rLen
            );
            rayGrad.addColorStop(0, `${theme.secondaryAccent}44`);
            rayGrad.addColorStop(1, "rgba(0,0,0,0)");
            ctx.strokeStyle = rayGrad;
            ctx.lineWidth = 8;
            ctx.beginPath();
            ctx.moveTo(centerX, horizonY);
            ctx.lineTo(centerX + Math.cos(rayAng) * rLen, horizonY + Math.sin(rayAng) * rLen);
            ctx.stroke();
          }

          // Liquid Event Horizon Caustic Ripples ("Kawoosh" puddle)
          const eventGrad = ctx.createRadialGradient(
            centerX,
            horizonY,
            4,
            centerX,
            horizonY,
            gateRadius
          );
          eventGrad.addColorStop(0, "#FFFFFF");
          eventGrad.addColorStop(0.28, `${theme.secondaryAccent}CC`);
          eventGrad.addColorStop(0.68, `${theme.primaryAccent}66`);
          eventGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
          ctx.fillStyle = eventGrad;
          ctx.beginPath();
          ctx.arc(centerX, horizonY, gateRadius, 0, Math.PI * 2);
          ctx.fill();

          // Concentric liquid ripple rings inside the Stargate
          for (let rip = 1; rip <= 4; rip++) {
            const ripRad =
              ((st.stargateAngle * 28 + rip * 18) % (gateRadius - 8)) + 4;
            ctx.strokeStyle = `rgba(255, 255, 255, ${Math.max(0.08, 0.55 - ripRad / gateRadius)})`;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(centerX, horizonY, ripRad, 0, Math.PI * 2);
            ctx.stroke();
          }

          // Outer Obsidian-Metallic Stargate Ring + 36 Glyph ticks + 9 Locking Chevrons
          ctx.strokeStyle = theme.secondaryAccent;
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(centerX, horizonY, gateRadius, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = `${theme.primaryAccent}99`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(centerX, horizonY, gateRadius + 7, 0, Math.PI * 2);
          ctx.stroke();

          // 36 rotating Stargate glyph ticks
          for (let g = 0; g < 36; g++) {
            const gAng = (g / 36) * Math.PI * 2 - st.stargateAngle * 1.4;
            ctx.strokeStyle = "rgba(255,255,255,0.45)";
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(
              centerX + Math.cos(gAng) * (gateRadius - 3),
              horizonY + Math.sin(gAng) * (gateRadius - 3)
            );
            ctx.lineTo(
              centerX + Math.cos(gAng) * (gateRadius + 3),
              horizonY + Math.sin(gAng) * (gateRadius + 3)
            );
            ctx.stroke();
          }

          // 9 V-Shaped Glowing Stargate Chevrons
          for (let c = 0; c < 9; c++) {
            const cAng = (c / 9) * Math.PI * 2 + st.stargateAngle;
            const cx = centerX + Math.cos(cAng) * (gateRadius + 2);
            const cy = horizonY + Math.sin(cAng) * (gateRadius + 2);
            const chevColor = c % 2 === 0 ? theme.starColor : theme.primaryAccent;

            ctx.fillStyle = chevColor;
            ctx.beginPath();
            ctx.arc(cx, cy, 5.5 + st.kawooshPulse * 2, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = "#FFFFFF";
            ctx.beginPath();
            ctx.arc(cx, cy, 2.2, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();

          // 3. Draw Pseudo-Obsidian Mirror 3D Perspective Ramp
          const horizonW = 46;
          const bottomW = Math.min(445, width * 0.47);
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(centerX - horizonW, horizonY);
          ctx.lineTo(centerX + horizonW, horizonY);
          ctx.lineTo(centerX + bottomW, height);
          ctx.lineTo(centerX - bottomW, height);
          ctx.closePath();

          const rampGrad = ctx.createLinearGradient(0, horizonY, 0, height);
          rampGrad.addColorStop(0, "rgba(5, 7, 16, 0.96)");
          rampGrad.addColorStop(0.45, "rgba(12, 14, 30, 0.92)");
          rampGrad.addColorStop(0.85, `${theme.primaryAccent}24`);
          rampGrad.addColorStop(1, `${theme.secondaryAccent}3B`);
          ctx.fillStyle = rampGrad;
          ctx.fill();

          // Clip to road to draw Pseudo-Obsidian Specular Reflections!
          ctx.clip();

          // Inverted Specular Reflection of the Stargate Horizon on the Obsidian glass road
          const reflGrad = ctx.createRadialGradient(
            centerX,
            horizonY + 38,
            4,
            centerX,
            horizonY + 55,
            gateRadius * 1.4
          );
          reflGrad.addColorStop(0, `${theme.secondaryAccent}44`);
          reflGrad.addColorStop(0.5, `${theme.primaryAccent}22`);
          reflGrad.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = reflGrad;
          ctx.fillRect(centerX - bottomW, horizonY, bottomW * 2, 160);

          // Flowing Horizontal Laser Grid Stripes along the Obsidian Road
          for (let g = 0; g < 9; g++) {
            const zVal = ((g * 120 - st.gridOffset + 1080) % 1000) + 20;
            const s = focalLength / (focalLength + zVal);
            const y = horizonY + (height - horizonY) * s;
            const w = bottomW * s;
            const alphaHex = Math.min(220, Math.round(s * 195))
              .toString(16)
              .padStart(2, "0");
            ctx.strokeStyle = `${theme.primaryAccent}${alphaHex}`;
            ctx.lineWidth = 1.6 * s + 0.6;
            ctx.beginPath();
            ctx.moveTo(centerX - w, y);
            ctx.lineTo(centerX + w, y);
            ctx.stroke();
          }

          // Parallel Space-Time Lanes (-t Past, t0 Axial Present, +t Future)
          const roadLanes = [-145, -48, 48, 145];
          const topScale = focalLength / (focalLength + 1000);
          for (const xl of roadLanes) {
            ctx.strokeStyle = `${theme.secondaryAccent}55`;
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.moveTo(centerX + xl * topScale, horizonY);
            ctx.lineTo(centerX + xl, height);
            ctx.stroke();
          }
          ctx.restore();

          // Neon Obsidian Road Outer Rails
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          ctx.strokeStyle = theme.secondaryAccent;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(centerX - horizonW, horizonY);
          ctx.lineTo(centerX - bottomW, height);
          ctx.moveTo(centerX + horizonW, horizonY);
          ctx.lineTo(centerX + bottomW, height);
          ctx.stroke();
          ctx.restore();

          // Labels for Parallel Space-Time Streams at bottom
          ctx.font = "600 11px 'JetBrains Mono', monospace";
          ctx.fillStyle = "rgba(226, 232, 240, 0.78)";
          ctx.textAlign = "center";
          ctx.fillText("ПОТОК ПРОШЛОГО (-t)", centerX - 195, height - 12);
          ctx.fillText("ОСЕВОЙ АСТРАЛ (t₀)", centerX, height - 12);
          ctx.fillText("ВЕРОЯТНОЕ БУДУЩЕЕ (+t)", centerX + 195, height - 12);

          // 4. Update & Draw Spheres + Comet Trails + Obsidian Floor Reflections
          const remaining: DreamSphere[] = [];
          for (const sp of st.spheres) {
            if (sp.isCaught) {
              sp.y -= 7;
              sp.radius += 2.2;
              sp.fadeAlpha -= 0.08;
              if (sp.fadeAlpha > 0.02) remaining.push(sp);
            } else if (sp.isMissed) {
              sp.y += 9;
              sp.radius *= 0.92;
              sp.fadeAlpha -= 0.08;
              if (sp.fadeAlpha > 0.02) remaining.push(sp);
            } else {
              sp.trail.unshift({ x: sp.x, y: sp.y, z: sp.z });
              if (sp.trail.length > 8) sp.trail.pop();

              sp.z -= sp.speed;
              sp.rotationAngle += 0.09;
              sp.y = -Math.sin(sp.z * 0.022) * 15;

              if (sp.z <= 14) {
                const dist = Math.abs(sp.x - st.funnelX);
                if (dist < 72) {
                  sp.isCaught = true;
                  const prevScore = st.score;
                  const next = calculateFunnelHit(st.score, st.streak, st.maxStreak, true);
                  st.score = next.score;
                  st.streak = next.streak;
                  st.maxStreak = next.maxStreak;
                  setScore(st.score);
                  setStreak(st.streak);
                  setMaxStreak(st.maxStreak);
                  const catchPx = centerX + sp.x;
                  const catchPy = height - 60;
                  spawnCatchExplosion(catchPx, catchPy, sp.color, next.score - prevScore);
                  soundEngine.playNoteIndex(sp.noteIndex, 380);
                } else {
                  sp.isMissed = true;
                  const next = calculateFunnelHit(st.score, st.streak, st.maxStreak, false);
                  st.streak = next.streak;
                  setStreak(0);
                }
              }
              remaining.push(sp);
            }
          }
          st.spheres = remaining;

          if (st.spheres.filter((s) => !s.isCaught && !s.isMissed).length < 4) {
            if (Math.random() < 0.06) {
              const noteIdx = Math.floor(Math.random() * theme.bubbleColors.length);
              st.spheres.push({
                id: st.nextId++,
                x: Math.random() * 360 - 180,
                y: 0,
                z: 1000,
                radius: 27,
                color: theme.bubbleColors[noteIdx],
                noteIndex: noteIdx,
                speed: 5.8 + Math.random() * 4.5,
                rotationAngle: 0,
                isCaught: false,
                isMissed: false,
                fadeAlpha: 1,
                trail: [],
              });
            }
          }

          for (const sp of st.spheres) {
            const s = focalLength / Math.max(10, focalLength + sp.z);
            const px = centerX + sp.x * s;
            const roadSurfaceY = horizonY + (height - horizonY - 55) * s;
            const py = roadSurfaceY + sp.y * s;
            const r = Math.max(4, sp.radius * s + 5);

            ctx.save();
            ctx.globalAlpha = Math.max(0, Math.min(1, sp.fadeAlpha));

            // 4a. Specular Mirror Reflection on the Obsidian Floor below the sphere
            if (!sp.isCaught && !sp.isMissed) {
              ctx.fillStyle = `${sp.color}33`;
              ctx.beginPath();
              ctx.ellipse(px, roadSurfaceY + r * 0.55, r * 0.95, r * 0.32, 0, 0, Math.PI * 2);
              ctx.fill();
            }

            // 4b. Comet Trail behind the sphere
            if (vfxOverdrive && sp.trail.length > 1) {
              for (let ti = 0; ti < sp.trail.length; ti++) {
                const tp = sp.trail[ti];
                const ts = focalLength / Math.max(10, focalLength + tp.z);
                const tpx = centerX + tp.x * ts;
                const tpy = horizonY + (height - horizonY - 55) * ts + tp.y * ts;
                const tr = Math.max(2, r * (1 - ti / (sp.trail.length + 1)) * 0.65);
                ctx.fillStyle = `${sp.color}${Math.round((1 - ti / sp.trail.length) * 90)
                  .toString(16)
                  .padStart(2, "0")}`;
                ctx.beginPath();
                ctx.arc(tpx, tpy, tr, 0, Math.PI * 2);
                ctx.fill();
              }
            }

            // 4c. Outer Volumetric Aura + 3D Shaded Sphere Core
            const orbGrad = ctx.createRadialGradient(
              px - r * 0.32,
              py - r * 0.32,
              r * 0.1,
              px,
              py,
              r
            );
            orbGrad.addColorStop(0, "#FFFFFF");
            orbGrad.addColorStop(0.35, sp.color);
            orbGrad.addColorStop(1, "#090D1E");
            ctx.fillStyle = orbGrad;
            ctx.beginPath();
            ctx.arc(px, py, r, 0, Math.PI * 2);
            ctx.fill();

            // Rotating Equatorial Ring around the sphere
            ctx.strokeStyle = "rgba(255,255,255,0.75)";
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.ellipse(px, py, r * 1.18, r * 0.35, sp.rotationAngle, 0, Math.PI * 2);
            ctx.stroke();

            ctx.restore();
          }

          // 5. Render Catch Explosion Particles & Floating Score Popups
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          const nextBursts: FunnelBurstParticle[] = [];
          for (const b of st.bursts) {
            b.x += b.vx;
            b.y += b.vy;
            b.vy += 0.12;
            b.alpha -= 0.032;
            if (b.alpha > 0.02) {
              ctx.fillStyle = b.color;
              ctx.globalAlpha = b.alpha;
              ctx.beginPath();
              ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
              ctx.fill();
              nextBursts.push(b);
            }
          }
          st.bursts = nextBursts;

          const nextPopups: FloatingScorePopup[] = [];
          for (const pop of st.popups) {
            pop.y -= 1.4;
            pop.alpha -= 0.025;
            if (pop.alpha > 0.02) {
              ctx.globalAlpha = pop.alpha;
              ctx.font = "bold 13px 'JetBrains Mono', monospace";
              ctx.fillStyle = pop.color;
              ctx.textAlign = "center";
              ctx.fillText(pop.text, pop.x, pop.y);
              nextPopups.push(pop);
            }
          }
          st.popups = nextPopups;
          ctx.restore();

          // 6. Draw Stargate Receiver Portal at Front (z = 0)
          const fnX = centerX + st.funnelX;
          const fnY = height - 55;
          const fnW = 144;
          const fnH = 50;

          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          ctx.strokeStyle = theme.primaryAccent;
          ctx.lineWidth = 3.5;
          ctx.beginPath();
          ctx.roundRect(fnX - fnW / 2, fnY - fnH / 2, fnW, fnH, 18);
          ctx.stroke();

          for (let i = 1; i <= 3; i++) {
            const shrink = i * 13;
            ctx.strokeStyle = i % 2 === 0 ? theme.starColor : theme.secondaryAccent;
            ctx.globalAlpha = 1 - i * 0.22;
            ctx.lineWidth = 2.2;
            ctx.beginPath();
            ctx.ellipse(
              fnX,
              fnY,
              Math.max(10, fnW / 2 - shrink),
              Math.max(6, fnH / 2 - shrink * 0.3),
              0,
              0,
              Math.PI * 2
            );
            ctx.stroke();
          }
          ctx.restore();
        }
      }
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [theme, vfxOverdrive]);

  return (
    <div
      className="rounded-3xl border border-white/15 p-6 md:p-8"
      style={{
        background: `linear-gradient(180deg, ${theme.bgGradient[0]} 0%, ${theme.bgGradient[1]} 55%, ${theme.bgGradient[2]} 100%)`,
      }}
    >
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={() => onBack(score, maxStreak)}
          data-testid="funnel-back-button"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Сохранить и выйти</span>
        </button>

        <div className="text-center">
          <h2 className="text-xl font-bold text-white">
            Ловцы Сфер · Обсидиановый Мост Stargate (4D)
          </h2>
          <p className="text-xs text-slate-300">
            Зеркальная обсидиановая трасса, 9 шевронов горизонта событий и параллельные потоки времён
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleVfx}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>VFX: {vfxOverdrive ? "МАКС" : "БАЗОВЫЙ"}</span>
          </button>
          <button
            type="button"
            onClick={handleRestart}
            data-testid="funnel-restart-button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Сбросить</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Гармония</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.primaryAccent }}
            data-testid="funnel-score"
          >
            {score}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Цепь созвучий</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.secondaryAccent }}
          >
            x{streak} <span className="text-xs font-normal text-slate-400">(макс. x{maxStreak})</span>
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-right">
          <div className="text-xs text-slate-400">Рекорд зала</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.starColor }}
          >
            {Math.max(highScore, score)}
          </div>
        </div>
      </div>

      {/* 3D Viewport Canvas */}
      <div className="relative rounded-2xl overflow-hidden border border-white/20 bg-[#04060E] shadow-2xl">
        <canvas
          ref={canvasRef}
          width={920}
          height={440}
          data-testid="funnel-canvas"
          onPointerMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = ((e.clientX - rect.left) / rect.width - 0.5) * 480;
            stateRef.current.funnelX = Math.max(-240, Math.min(240, relX));
          }}
          onClick={() => triggerMagneticPulse()}
          className="w-full h-[360px] md:h-[420px] block cursor-ew-resize touch-none"
        />
      </div>

      {/* Interactive Controls Bar */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              stateRef.current.funnelX = -150;
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            ← Поток Прошлого (-t)
          </button>
          <button
            type="button"
            onClick={() => {
              stateRef.current.funnelX = 0;
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            Осевой Астрал (t₀)
          </button>
          <button
            type="button"
            onClick={() => {
              stateRef.current.funnelX = 150;
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            Поток Будущего (+t) →
          </button>
          <button
            type="button"
            onClick={triggerKawooshWave}
            data-testid="funnel-kawoosh-button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-500/25 hover:bg-indigo-500/35 border border-indigo-400/40 text-xs font-bold text-indigo-200 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Всплеск Врат (Kawoosh)</span>
          </button>
        </div>

        <button
          type="button"
          onClick={triggerMagneticPulse}
          data-testid="funnel-catch-pulse-button"
          className="px-4 py-2 rounded-xl text-xs font-bold text-white transition-transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
          style={{ backgroundColor: theme.primaryAccent }}
        >
          Поймать ближайшую сферу (+Гармония)
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// ATTRACTION 2: CELESTIAL CAROUSEL (Карусель Созвездий · 4D Tesseract + Obsidian Graph)
// ============================================================================
interface CarouselProps {
  theme: ThemePreset;
  highScore: number;
  vfxOverdrive: boolean;
  onToggleVfx: () => void;
  onBack: (score: number, scaleCount: number) => void;
  onSaveScore: (score: number, scaleCount: number) => void;
}

const AttractionCelestialCarouselCanvas: React.FC<CarouselProps> = ({
  theme,
  highScore,
  vfxOverdrive,
  onToggleVfx,
  onBack,
  onSaveScore,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState(0);
  const [scaleCount, setScaleCount] = useState(0);
  const [selectedCount, setSelectedCount] = useState(0);

  const stateRef = useRef({
    angleY: 0,
    angleX: 0.18,
    angle4D: 0,
    fusionFlash: 0,
    stars: [] as CarouselStar[],
    selectedIds: [] as number[],
    score: 0,
    scaleCount: 0,
  });

  const initStars = () => {
    const colors = theme.bubbleColors;
    const list: CarouselStar[] = [];
    let id = 1;
    for (let tier = -1; tier <= 1; tier++) {
      const tierY = tier * 112;
      const countInTier = 6;
      for (let i = 0; i < countInTier; i++) {
        const circleAngle = (i / countInTier) * Math.PI * 2;
        const radius = 175;
        const colorIdx = (i + tier + 3) % colors.length;
        list.push({
          id: id++,
          baseX: Math.cos(circleAngle) * radius,
          baseY: tierY,
          baseZ: Math.sin(circleAngle) * radius,
          rotatedX: 0,
          rotatedY: 0,
          rotatedZ: 0,
          color: colors[colorIdx],
          colorIndex: colorIdx,
          isSelected: false,
          pulse: 0,
        });
      }
    }
    stateRef.current.stars = list;
    stateRef.current.selectedIds = [];
    setSelectedCount(0);
  };

  const triggerConstellationFusion = () => {
    const st = stateRef.current;
    const targetColorIdx = Math.floor(Math.random() * theme.bubbleColors.length);
    const matching = st.stars.filter((s) => s.colorIndex === targetColorIdx).slice(0, 3);
    const count = Math.max(3, matching.length);
    const next = calculateCarouselFusionScore(st.score, st.scaleCount, count);
    st.score = next.score;
    st.scaleCount = next.scaleCount;
    st.fusionFlash = 1.0;
    setScore(st.score);
    setScaleCount(st.scaleCount);
    soundEngine.playArpeggio(targetColorIdx);

    st.angleY += 0.45;
    matching.forEach((star) => {
      const newIdx = (star.colorIndex + 1) % theme.bubbleColors.length;
      star.colorIndex = newIdx;
      star.color = theme.bubbleColors[newIdx];
      star.isSelected = false;
    });
    st.selectedIds = [];
    setSelectedCount(0);
  };

  useEffect(() => {
    initStars();
    let animId = 0;

    const render = () => {
      const canvas = canvasRef.current;
      const st = stateRef.current;
      st.angleY += vfxOverdrive ? 0.0065 : 0.004;
      st.angle4D += vfxOverdrive ? 0.022 : 0.012;
      st.fusionFlash = Math.max(0, st.fusionFlash * 0.92);

      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;
          const centerX = width / 2;
          const centerY = height / 2;
          const focalLength = 400;
          const camD = 420;

          ctx.clearRect(0, 0, width, height);

          // 0. Deep Obsidian Background + Fusion Shockwave Glow
          const bgGrad = ctx.createRadialGradient(
            centerX,
            centerY,
            10,
            centerX,
            centerY,
            width * 0.55
          );
          bgGrad.addColorStop(0, `${theme.secondaryAccent}${st.fusionFlash > 0.1 ? "55" : "24"}`);
          bgGrad.addColorStop(0.5, `${theme.primaryAccent}18`);
          bgGrad.addColorStop(1, "#04060F");
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, width, height);

          // 1. Medieval Armillary Sphere Gimbal Rings
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          for (let ringIdx = 0; ringIdx < 3; ringIdx++) {
            ctx.strokeStyle =
              ringIdx === 0
                ? `${theme.secondaryAccent}38`
                : ringIdx === 1
                ? `${theme.primaryAccent}30`
                : "rgba(255,255,255,0.12)";
            ctx.lineWidth = 1.6;
            ctx.beginPath();
            ctx.ellipse(
              centerX,
              centerY,
              220 - ringIdx * 28,
              85 + ringIdx * 42,
              st.angleY * (ringIdx === 1 ? -0.6 : 0.4) + ringIdx,
              0,
              Math.PI * 2
            );
            ctx.stroke();
          }

          // 2. Central 4D Rotating Hypercube (Tesseract) around Axis Mundi
          const tesseractPts: Array<{ x: number; y: number }> = [];
          const hyperScale = 58 + st.fusionFlash * 22;
          for (const [vx, vy, vz, vw] of TESSERACT_VERTICES) {
            const c1 = Math.cos(st.angle4D);
            const s1 = Math.sin(st.angle4D);
            const x1 = vx * c1 - vw * s1;
            const w1 = vx * s1 + vw * c1;

            const c2 = Math.cos(st.angle4D * 0.7);
            const s2 = Math.sin(st.angle4D * 0.7);
            const z2 = vz * c2 - w1 * s2;
            const w2 = vz * s2 + w1 * c2;

            const wProj = 2.5 / (2.5 - w2 * 0.48);
            const rot = rotate3DPoint(
              x1 * wProj * hyperScale,
              vy * wProj * hyperScale,
              z2 * wProj * hyperScale,
              st.angleX,
              st.angleY * 1.4
            );
            const proj = project3DPoint(rot.rx, rot.ry, rot.rz, centerX, centerY, focalLength, camD);
            tesseractPts.push({ x: proj.px, y: proj.py });
          }

          ctx.strokeStyle = `${theme.secondaryAccent}66`;
          ctx.lineWidth = 1.3;
          for (const [iA, iB] of TESSERACT_EDGES) {
            ctx.beginPath();
            ctx.moveTo(tesseractPts[iA].x, tesseractPts[iA].y);
            ctx.lineTo(tesseractPts[iB].x, tesseractPts[iB].y);
            ctx.stroke();
          }
          ctx.restore();

          // Update 3D rotations for Constellation Nodes
          for (const star of st.stars) {
            const rot = rotate3DPoint(star.baseX, star.baseY, star.baseZ, st.angleX, st.angleY);
            star.rotatedX = rot.rx;
            star.rotatedY = rot.ry;
            star.rotatedZ = rot.rz;
            star.pulse = star.isSelected ? star.pulse + 0.16 : star.pulse + 0.04;
          }

          // Central glowing Axis Mundi Laser Spindle
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          const axisGrad = ctx.createLinearGradient(centerX, centerY - 190, centerX, centerY + 190);
          axisGrad.addColorStop(0, "rgba(0,0,0,0)");
          axisGrad.addColorStop(0.5, `${theme.secondaryAccent}AA`);
          axisGrad.addColorStop(1, "rgba(0,0,0,0)");
          ctx.strokeStyle = axisGrad;
          ctx.lineWidth = 6;
          ctx.beginPath();
          ctx.moveTo(centerX, centerY - 190);
          ctx.lineTo(centerX, centerY + 190);
          ctx.stroke();

          // 3. Pseudo-Obsidian Knowledge Graph Edges + Traveling Synaptic Pulses
          for (let i = 0; i < st.stars.length; i++) {
            for (let j = i + 1; j < st.stars.length; j++) {
              const s1 = st.stars[i];
              const s2 = st.stars[j];
              if (s1.colorIndex === s2.colorIndex) {
                const p1 = project3DPoint(
                  s1.rotatedX,
                  s1.rotatedY,
                  s1.rotatedZ,
                  centerX,
                  centerY,
                  focalLength,
                  camD
                );
                const p2 = project3DPoint(
                  s2.rotatedX,
                  s2.rotatedY,
                  s2.rotatedZ,
                  centerX,
                  centerY,
                  focalLength,
                  camD
                );
                ctx.strokeStyle = `${s1.color}36`;
                ctx.lineWidth = 1.3;
                ctx.beginPath();
                ctx.moveTo(p1.px, p1.py);
                ctx.lineTo(p2.px, p2.py);
                ctx.stroke();

                // Synaptic pulse packet traveling along Obsidian graph edge
                if (vfxOverdrive && (i + j) % 2 === 0) {
                  const prog = ((st.angle4D * 0.45 + i * 0.17) % 1 + 1) % 1;
                  const sx = p1.px + (p2.px - p1.px) * prog;
                  const sy = p1.py + (p2.py - p1.py) * prog;
                  ctx.fillStyle = s1.color;
                  ctx.beginPath();
                  ctx.arc(sx, sy, 2.4, 0, Math.PI * 2);
                  ctx.fill();
                }
              }
            }
          }

          // Active Plasma Lightning Lines between Selected Stars
          if (st.selectedIds.length > 1) {
            for (let i = 0; i < st.selectedIds.length - 1; i++) {
              const sA = st.stars.find((s) => s.id === st.selectedIds[i]);
              const sB = st.stars.find((s) => s.id === st.selectedIds[i + 1]);
              if (sA && sB) {
                const pA = project3DPoint(
                  sA.rotatedX,
                  sA.rotatedY,
                  sA.rotatedZ,
                  centerX,
                  centerY,
                  focalLength,
                  camD
                );
                const pB = project3DPoint(
                  sB.rotatedX,
                  sB.rotatedY,
                  sB.rotatedZ,
                  centerX,
                  centerY,
                  focalLength,
                  camD
                );
                ctx.strokeStyle = theme.primaryAccent;
                ctx.lineWidth = 4.5;
                ctx.beginPath();
                ctx.moveTo(pA.px, pA.py);
                ctx.lineTo(pB.px, pB.py);
                ctx.stroke();
              }
            }
          }
          ctx.restore();

          // Painter's algorithm sort by Z
          const sorted = [...st.stars].sort((a, b) => b.rotatedZ - a.rotatedZ);
          for (const star of sorted) {
            const proj = project3DPoint(
              star.rotatedX,
              star.rotatedY,
              star.rotatedZ,
              centerX,
              centerY,
              focalLength,
              camD
            );
            const r = 15 * proj.scale * (1 + (star.isSelected ? 0.28 : 0.08) * Math.sin(star.pulse));

            // Volumetric Halo
            const haloGrad = ctx.createRadialGradient(
              proj.px,
              proj.py,
              1,
              proj.px,
              proj.py,
              r * 2.2
            );
            haloGrad.addColorStop(0, `${star.color}88`);
            haloGrad.addColorStop(1, "rgba(0,0,0,0)");
            ctx.fillStyle = haloGrad;
            ctx.beginPath();
            ctx.arc(proj.px, proj.py, r * 2.2, 0, Math.PI * 2);
            ctx.fill();

            // Obsidian Faceted Diamond Node
            ctx.fillStyle = "#080B18";
            ctx.strokeStyle = star.isSelected ? "#FFFFFF" : star.color;
            ctx.lineWidth = star.isSelected ? 3.5 : 2.5;
            ctx.beginPath();
            ctx.moveTo(proj.px, proj.py - r * 1.4);
            ctx.lineTo(proj.px + r * 1.15, proj.py);
            ctx.lineTo(proj.px, proj.py + r * 1.4);
            ctx.lineTo(proj.px - r * 1.15, proj.py);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = star.isSelected ? theme.primaryAccent : "#FFFFFF";
            ctx.beginPath();
            ctx.arc(proj.px, proj.py, r * 0.42, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [theme, vfxOverdrive]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const scaleX = e.currentTarget.width / rect.width;
    const scaleY = e.currentTarget.height / rect.height;
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    const st = stateRef.current;
    const centerX = e.currentTarget.width / 2;
    const centerY = e.currentTarget.height / 2;

    let hit: CarouselStar | null = null;
    let minDist = 9999;
    for (const star of st.stars) {
      const proj = project3DPoint(
        star.rotatedX,
        star.rotatedY,
        star.rotatedZ,
        centerX,
        centerY,
        400,
        420
      );
      const d = Math.hypot(clickX - proj.px, clickY - proj.py);
      if (d < 46 && d < minDist) {
        minDist = d;
        hit = star;
      }
    }

    if (!hit) return;
    soundEngine.playNoteIndex(hit.colorIndex, 260);

    if (st.selectedIds.includes(hit.id)) {
      hit.isSelected = false;
      st.selectedIds = st.selectedIds.filter((id) => id !== hit!.id);
      setSelectedCount(st.selectedIds.length);
      return;
    }

    const firstSelected = st.stars.find((s) => s.id === st.selectedIds[0]);
    if (!firstSelected || firstSelected.colorIndex === hit.colorIndex) {
      hit.isSelected = true;
      st.selectedIds.push(hit.id);
      setSelectedCount(st.selectedIds.length);

      if (st.selectedIds.length >= 3) {
        const res = calculateCarouselFusionScore(st.score, st.scaleCount, st.selectedIds.length);
        st.score = res.score;
        st.scaleCount = res.scaleCount;
        st.fusionFlash = 1.0;
        setScore(st.score);
        setScaleCount(st.scaleCount);
        soundEngine.playArpeggio(hit.colorIndex);

        st.selectedIds.forEach((mId) => {
          const s = st.stars.find((item) => item.id === mId);
          if (s) {
            s.isSelected = false;
            const nextColor = (s.colorIndex + 1) % theme.bubbleColors.length;
            s.colorIndex = nextColor;
            s.color = theme.bubbleColors[nextColor];
          }
        });
        st.selectedIds = [];
        setSelectedCount(0);
      }
    } else {
      st.stars.forEach((s) => {
        s.isSelected = false;
      });
      hit.isSelected = true;
      st.selectedIds = [hit.id];
      setSelectedCount(1);
    }
  };

  return (
    <div
      className="rounded-3xl border border-white/15 p-6 md:p-8"
      style={{
        background: `linear-gradient(180deg, ${theme.bgGradient[0]} 0%, ${theme.bgGradient[1]} 55%, ${theme.bgGradient[2]} 100%)`,
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={() => onBack(score, scaleCount)}
          data-testid="carousel-back-button"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-sm font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Сохранить и выйти</span>
        </button>

        <div className="text-center">
          <h2 className="text-xl font-bold text-white">
            Карусель Созвездий · 4D-Тессеракт и Граф Obsidian
          </h2>
          <p className="text-xs text-slate-300">
            Вращайте армиллярную сферу вокруг 4D-гиперкуба и соединяйте по 3 узла одного цвета
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleVfx}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>VFX: {vfxOverdrive ? "МАКС" : "БАЗОВЫЙ"}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (score > 0) onSaveScore(score, scaleCount);
              stateRef.current.score = 0;
              stateRef.current.scaleCount = 0;
              setScore(0);
              setScaleCount(0);
              initStars();
              soundEngine.playTone(523.25, 160);
            }}
            data-testid="carousel-restart-button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Сбросить</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Гармония</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.primaryAccent }}
            data-testid="carousel-score"
          >
            {score}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Собрано гамм</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.secondaryAccent }}
          >
            {scaleCount} <span className="text-xs font-normal text-slate-400">(выбрано {selectedCount}/3)</span>
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-right">
          <div className="text-xs text-slate-400">Рекорд зала</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.starColor }}
          >
            {Math.max(highScore, score)}
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-white/20 bg-[#04060F] shadow-2xl">
        <canvas
          ref={canvasRef}
          width={920}
          height={440}
          data-testid="carousel-viewport"
          onClick={handleCanvasClick}
          onPointerMove={(e) => {
            if (e.buttons === 1) {
              stateRef.current.angleY += e.movementX * 0.008;
              stateRef.current.angleX = Math.max(
                -0.6,
                Math.min(0.6, stateRef.current.angleX - e.movementY * 0.006)
              );
            }
          }}
          className="w-full h-[360px] md:h-[420px] block cursor-pointer touch-none"
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              stateRef.current.angleY -= 0.4;
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            ↺ Повернуть влево
          </button>
          <button
            type="button"
            onClick={() => {
              stateRef.current.angleY += 0.4;
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            Повернуть вправо ↻
          </button>
        </div>

        <button
          type="button"
          onClick={triggerConstellationFusion}
          data-testid="carousel-fusion-button"
          className="px-4 py-2 rounded-xl text-xs font-bold text-slate-950 transition-transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
          style={{ backgroundColor: theme.secondaryAccent }}
        >
          Собрать созвездие (+75 Гармонии)
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// ATTRACTION 3: ETHEREAL BUBBLES (Эфирные Пузыри · Vas Hermeticum Iridescent Vessels)
// ============================================================================
interface BubblesProps {
  theme: ThemePreset;
  highScore: number;
  vfxOverdrive: boolean;
  onToggleVfx: () => void;
  onBack: (score: number, splitCount: number) => void;
  onSaveScore: (score: number, splitCount: number) => void;
}

const AttractionEtherealBubblesCanvas: React.FC<BubblesProps> = ({
  theme,
  highScore,
  vfxOverdrive,
  onToggleVfx,
  onBack,
  onSaveScore,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState(0);
  const [splitCount, setSplitCount] = useState(0);

  const stateRef = useRef({
    bubbles: [] as EtherealBubble[],
    embers: Array.from({ length: 45 }, () => ({
      x: Math.random() * 920,
      y: Math.random() * 440,
      vy: 0.5 + Math.random() * 1.4,
      size: 1.2 + Math.random() * 2.2,
    })),
    nextId: 1,
    score: 0,
    splitCount: 0,
  });

  const seedBubbles = () => {
    const colors = theme.bubbleColors;
    stateRef.current.bubbles = Array.from({ length: 7 }, (_, i) => {
      const noteIdx = i % colors.length;
      return {
        id: stateRef.current.nextId++,
        x: 160 + i * 95,
        y: 160 + (i % 3) * 75,
        vx: (Math.random() - 0.5) * 2.2,
        vy: -(1.2 + Math.random() * 1.5),
        radius: 44 + (i % 3) * 12,
        color: colors[noteIdx],
        noteIndex: noteIdx,
        z: (i * 35) % 180,
        wobble: i * 0.7,
        isPopped: false,
        popProgress: 0,
        sigilIndex: i % ALCHEMICAL_SIGILS.length,
      };
    });
  };

  const triggerBubbleSplitWave = () => {
    const st = stateRef.current;
    const active = st.bubbles.find((b) => !b.isPopped && b.radius > 28);
    if (!active) {
      seedBubbles();
      return;
    }
    active.isPopped = true;
    active.popProgress = 0.2;
    st.score += 15;
    st.splitCount += 1;
    setScore(st.score);
    setSplitCount(st.splitCount);

    const newRad = Math.max(24, active.radius * 0.62);
    const colors = theme.bubbleColors;
    st.bubbles.push(
      {
        id: st.nextId++,
        x: active.x - newRad,
        y: active.y,
        vx: -2.4,
        vy: -1.6,
        radius: newRad,
        color: colors[(active.noteIndex + 1) % colors.length],
        noteIndex: (active.noteIndex + 1) % 10,
        z: active.z,
        wobble: 0,
        isPopped: false,
        popProgress: 0,
        sigilIndex: (active.sigilIndex + 1) % ALCHEMICAL_SIGILS.length,
      },
      {
        id: st.nextId++,
        x: active.x + newRad,
        y: active.y,
        vx: 2.4,
        vy: -1.6,
        radius: newRad,
        color: colors[(active.noteIndex + 2) % colors.length],
        noteIndex: (active.noteIndex + 2) % 10,
        z: active.z,
        wobble: 0,
        isPopped: false,
        popProgress: 0,
        sigilIndex: (active.sigilIndex + 2) % ALCHEMICAL_SIGILS.length,
      }
    );
    soundEngine.playNoteIndex(active.noteIndex, 280);
  };

  useEffect(() => {
    seedBubbles();
    let animId = 0;

    const render = () => {
      const canvas = canvasRef.current;
      const st = stateRef.current;

      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;
          const centerX = width / 2;

          ctx.clearRect(0, 0, width, height);

          // 0. Alchemical Aether Chamber Backdrop
          const bgGrad = ctx.createRadialGradient(
            centerX,
            height,
            20,
            centerX,
            height * 0.4,
            width * 0.65
          );
          bgGrad.addColorStop(0, `${theme.starColor}28`);
          bgGrad.addColorStop(0.5, `${theme.primaryAccent}18`);
          bgGrad.addColorStop(1, "#04060E");
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, width, height);

          // Rising Golden Alchemical Embers
          ctx.fillStyle = `${theme.starColor}88`;
          for (const emb of st.embers) {
            emb.y -= vfxOverdrive ? emb.vy * 1.5 : emb.vy;
            if (emb.y < 0) {
              emb.y = height;
              emb.x = Math.random() * width;
            }
            ctx.beginPath();
            ctx.arc(emb.x, emb.y, emb.size, 0, Math.PI * 2);
            ctx.fill();
          }

          // Update bubble physics
          const nextBubbles: EtherealBubble[] = [];
          for (const b of st.bubbles) {
            if (b.isPopped) {
              b.popProgress += 0.08;
              if (b.popProgress < 1) nextBubbles.push(b);
            } else {
              b.x += b.vx;
              b.y += b.vy;
              b.wobble += 0.065;
              if (b.x - b.radius < 20) {
                b.x = b.radius + 20;
                b.vx = Math.abs(b.vx);
              }
              if (b.x + b.radius > width - 20) {
                b.x = width - 20 - b.radius;
                b.vx = -Math.abs(b.vx);
              }
              if (b.y + b.radius < -40) {
                b.y = height - 40;
                b.x = centerX + (Math.random() * 160 - 80);
              }
              nextBubbles.push(b);
            }
          }
          st.bubbles = nextBubbles;

          // Check merges & draw plasma filaments between nearby vessels
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          for (let i = 0; i < st.bubbles.length; i++) {
            for (let j = i + 1; j < st.bubbles.length; j++) {
              const b1 = st.bubbles[i];
              const b2 = st.bubbles[j];
              if (!b1.isPopped && !b2.isPopped) {
                const dist = Math.hypot(b1.x - b2.x, b1.y - b2.y);
                if (dist < (b1.radius + b2.radius) * 1.35 && dist >= (b1.radius + b2.radius) * 0.68) {
                  // Plasma resonance filament before merge
                  ctx.strokeStyle = `${b1.color}55`;
                  ctx.lineWidth = 2;
                  ctx.beginPath();
                  ctx.moveTo(b1.x, b1.y);
                  ctx.lineTo(b2.x, b2.y);
                  ctx.stroke();
                } else if (dist < (b1.radius + b2.radius) * 0.68) {
                  b1.radius = mergeBubbleRadii(b1.radius, b2.radius);
                  b2.isPopped = true;
                  b2.popProgress = 1;
                  st.score += 15;
                  setScore(st.score);
                  soundEngine.playNoteIndex((b1.noteIndex + 3) % 10, 420);
                }
              }
            }
          }
          ctx.restore();

          if (st.bubbles.filter((b) => !b.isPopped).length < 6) {
            const colors = theme.bubbleColors;
            const noteIdx = Math.floor(Math.random() * colors.length);
            st.bubbles.push({
              id: st.nextId++,
              x: centerX + (Math.random() * 90 - 45),
              y: height - 30,
              vx: (Math.random() - 0.5) * 3,
              vy: -(1.5 + Math.random() * 2),
              radius: 40 + Math.random() * 24,
              color: colors[noteIdx],
              noteIndex: noteIdx,
              z: Math.random() * 140,
              wobble: 0,
              isPopped: false,
              popProgress: 0,
              sigilIndex: noteIdx % ALCHEMICAL_SIGILS.length,
            });
          }

          // Draw Alchemical Athanor Emitter at bottom center
          ctx.fillStyle = `${theme.secondaryAccent}88`;
          ctx.beginPath();
          ctx.roundRect(centerX - 54, height - 36, 108, 36, 12);
          ctx.fill();

          // Render Iridescent Alchemical Vessels
          for (const b of st.bubbles) {
            const scale = 300 / (300 + 350 + b.z);
            const drawR = Math.max(14, b.radius * scale * 1.65);
            const wx = Math.sin(b.wobble) * 4.5;
            const wy = Math.cos(b.wobble) * 3.5;
            const bx = b.x + wx;
            const by = b.y + wy;

            if (b.isPopped) {
              for (let p = 0; p < 12; p++) {
                const ang = (p / 12) * Math.PI * 2;
                const dist = drawR * (1 + b.popProgress * 1.45);
                ctx.fillStyle = p % 2 === 0 ? "#FFFFFF" : b.color;
                ctx.globalAlpha = Math.max(0, 1 - b.popProgress);
                ctx.beginPath();
                ctx.arc(
                  bx + Math.cos(ang) * dist,
                  by + Math.sin(ang) * dist,
                  4 * (1 - b.popProgress),
                  0,
                  Math.PI * 2
                );
                ctx.fill();
              }
              ctx.globalAlpha = 1;
            } else {
              // Iridescent Soap-Film / Aether Shader Gradient
              const grad = ctx.createRadialGradient(
                bx - drawR * 0.32,
                by - drawR * 0.32,
                drawR * 0.08,
                bx,
                by,
                drawR
              );
              grad.addColorStop(0, "rgba(255,255,255,0.92)");
              grad.addColorStop(0.35, `${b.color}99`);
              grad.addColorStop(0.75, `${theme.secondaryAccent}44`);
              grad.addColorStop(1, `${b.color}18`);

              ctx.fillStyle = grad;
              ctx.beginPath();
              ctx.arc(bx, by, drawR, 0, Math.PI * 2);
              ctx.fill();

              // Iridescent Rim
              ctx.strokeStyle = "rgba(255,255,255,0.65)";
              ctx.lineWidth = 1.8;
              ctx.stroke();

              // Sacred Alchemical Sigil inside the Vessel
              ctx.font = "bold 14px 'Plus Jakarta Sans', sans-serif";
              ctx.fillStyle = "rgba(255,255,255,0.82)";
              ctx.textAlign = "center";
              ctx.textBaseline = "middle";
              ctx.fillText(ALCHEMICAL_SIGILS[b.sigilIndex], bx, by);
            }
          }
        }
      }
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [theme, vfxOverdrive]);

  return (
    <div
      className="rounded-3xl border border-white/15 p-6 md:p-8"
      style={{
        background: `linear-gradient(180deg, ${theme.bgGradient[0]} 0%, ${theme.bgGradient[1]} 55%, ${theme.bgGradient[2]} 100%)`,
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={() => onBack(score, splitCount)}
          data-testid="bubbles-back-button"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-sm font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Сохранить и выйти</span>
        </button>

        <div className="text-center">
          <h2 className="text-xl font-bold text-white">
            Эфирные Пузыри · Алхимические Ёмкости (Vas Hermeticum)
          </h2>
          <p className="text-xs text-slate-300">
            Иридисцентные сосуды сознания с герметическими сигилами и плазменным слиянием
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleVfx}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>VFX: {vfxOverdrive ? "МАКС" : "БАЗОВЫЙ"}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (score > 0) onSaveScore(score, splitCount);
              stateRef.current.score = 0;
              stateRef.current.splitCount = 0;
              setScore(0);
              setSplitCount(0);
              seedBubbles();
              soundEngine.playTone(440, 150);
            }}
            data-testid="bubbles-restart-button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Сбросить</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Гармония</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.primaryAccent }}
            data-testid="bubbles-score"
          >
            {score}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-xs text-slate-400">Деления сфер</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.secondaryAccent }}
          >
            {splitCount}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-right">
          <div className="text-xs text-slate-400">Рекорд зала</div>
          <div
            className="text-2xl md:text-3xl font-extrabold font-mono tabular-nums"
            style={{ color: theme.starColor }}
          >
            {Math.max(highScore, score)}
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-white/20 bg-[#04060E] shadow-2xl">
        <canvas
          ref={canvasRef}
          width={920}
          height={440}
          data-testid="bubbles-viewport"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const sx = e.currentTarget.width / rect.width;
            const sy = e.currentTarget.height / rect.height;
            const cx = (e.clientX - rect.left) * sx;
            const cy = (e.clientY - rect.top) * sy;

            const st = stateRef.current;
            for (const b of st.bubbles) {
              if (!b.isPopped && Math.hypot(cx - b.x, cy - b.y) < b.radius + 25) {
                b.isPopped = true;
                st.score += 10;
                setScore(st.score);
                soundEngine.playNoteIndex(b.noteIndex, 300);
                break;
              }
            }
          }}
          className="w-full h-[360px] md:h-[420px] block cursor-pointer touch-none"
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <span className="text-xs text-slate-300">
          Сближающиеся сосуды образуют плазменный мост и сливаются в мега-ёмкости (+15 очков)
        </span>
        <button
          type="button"
          onClick={triggerBubbleSplitWave}
          data-testid="bubbles-split-button"
          className="px-4 py-2 rounded-xl text-xs font-bold text-slate-950 transition-transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
          style={{ backgroundColor: theme.starColor }}
        >
          Разделить эфирную сферу (+15 Гармонии)
        </button>
      </div>
    </div>
  );
};
