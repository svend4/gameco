import React, { useEffect, useState } from "react";
import {
  Plus,
  ArrowLeft,
  Trash2,
  Play,
  Square,
  Brain,
  Wind,
  Sparkles,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import {
  MOOD_OPTIONS,
  DISTORTION_OPTIONS,
  calculateCbtRoadmapStage,
  calculateMoodDistribution,
  formatDurationRu,
  advanceBoxBreathingTimer,
  getBreathPhaseInfo,
  type JournalEntry,
  type BreathingSession,
  type MoodOption,
} from "../utils/appLogic";
import { soundEngine } from "../utils/soundEngine";

export type MindSyncSubScreen = "journal" | "insights" | "add-log" | "detail" | "breathing";

interface MindSyncViewProps {
  entries: JournalEntry[];
  breathingSessions: BreathingSession[];
  onAddEntry: (entry: Omit<JournalEntry, "id" | "timestamp">) => void;
  onDeleteEntry: (id: string) => void;
  onSaveBreathingSession: (durationSeconds: number) => void;
  activeSubScreen: MindSyncSubScreen;
  onChangeSubScreen: (screen: MindSyncSubScreen) => void;
}

export const MindSyncView: React.FC<MindSyncViewProps> = ({
  entries,
  breathingSessions,
  onAddEntry,
  onDeleteEntry,
  onSaveBreathingSession,
  activeSubScreen,
  onChangeSubScreen,
}) => {
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);

  // 3-Step CBT Wizard state
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedMood, setSelectedMood] = useState<MoodOption>(MOOD_OPTIONS[1]); // Тревога
  const [originalThought, setOriginalThought] = useState("");
  const [selectedDistortions, setSelectedDistortions] = useState<string[]>(["Catastrophizing"]);
  const [rationalThought, setRationalThought] = useState("");
  const [intensityBefore, setIntensityBefore] = useState(7);
  const [intensityAfter, setIntensityAfter] = useState(3);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const openAddWizard = () => {
    setStep(1);
    setSelectedMood(MOOD_OPTIONS[1]);
    setOriginalThought("");
    setSelectedDistortions(["Catastrophizing"]);
    setRationalThought("");
    setIntensityBefore(7);
    setIntensityAfter(3);
    setValidationError(null);
    onChangeSubScreen("add-log");
  };

  const toggleDistortion = (title: string) => {
    setSelectedDistortions((prev) =>
      prev.includes(title) ? prev.filter((item) => item !== title) : [...prev, title]
    );
  };

  const handleWizardNext = async () => {
    if (step === 1) {
      setValidationError(null);
      setStep(2);
      return;
    }
    if (step === 2) {
      if (!originalThought.trim()) {
        setValidationError("Пожалуйста, запишите тревожную мысль перед переходом к следующему шагу.");
        return;
      }
      setValidationError(null);
      setStep(3);
      return;
    }

    // Step 3: Submit to server-side Gemini CBT reflection endpoint
    if (!rationalThought.trim()) {
      setValidationError("Пожалуйста, сформулируйте рациональный ответ для закрепления рефрейминга.");
      return;
    }

    setValidationError(null);
    setIsAnalyzing(true);
    try {
      const ruDistortions = selectedDistortions.map(
        (d) => DISTORTION_OPTIONS.find((opt) => opt.title === d)?.ruTitle || d
      );

      const response = await fetch("/api/cbt/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mood: selectedMood.ruName,
          originalThought: originalThought.trim(),
          distortions: ruDistortions,
          rationalThought: rationalThought.trim(),
        }),
      });
      const data = await response.json();
      const feedback =
        typeof data?.feedback === "string"
          ? data.feedback
          : "Ваша запись сохранена. Вы проделали важную когнитивную работу, отделив факты от автоматических эмоций.";

      onAddEntry({
        mood: selectedMood.name,
        originalThought: originalThought.trim(),
        distortions: selectedDistortions.join(", "),
        rationalThought: rationalThought.trim(),
        intensityBefore,
        intensityAfter,
        geminiFeedback: feedback,
      });
      soundEngine.playArpeggio(4);
      onChangeSubScreen("journal");
    } catch {
      onAddEntry({
        mood: selectedMood.name,
        originalThought: originalThought.trim(),
        distortions: selectedDistortions.join(", "),
        rationalThought: rationalThought.trim(),
        intensityBefore,
        intensityAfter,
        geminiFeedback:
          "1. Эмпатия и принятие\nВаши чувства понятны. Запись мысли — уже половина пути к спокойствию.\n\n2. Поддержка рефрейминга\nВаш сбалансированный ответ помогает снизить эмоциональный накал и опереться на реальные факты.",
      });
      onChangeSubScreen("journal");
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (activeSubScreen === "breathing") {
    return (
      <BreathingExerciseStudio
        onSaveSession={(seconds) => {
          onSaveBreathingSession(seconds);
        }}
        onBack={() => onChangeSubScreen("insights")}
      />
    );
  }

  if (activeSubScreen === "detail" && selectedEntry) {
    const moodCfg = MOOD_OPTIONS.find((m) => m.name === selectedEntry.mood);
    const distList = selectedEntry.distortions
      ? selectedEntry.distortions.split(", ").filter(Boolean)
      : [];

    return (
      <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8">
        <div className="flex items-center justify-between gap-4 mb-6">
          <button
            type="button"
            onClick={() => onChangeSubScreen("journal")}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>К списку записей</span>
          </button>

          <h2 className="text-lg font-bold text-white">Детали записи КПТ</h2>

          <button
            type="button"
            onClick={() => {
              onDeleteEntry(selectedEntry.id);
              onChangeSubScreen("journal");
            }}
            data-testid="delete-entry-button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-semibold cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Удалить</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">{moodCfg?.emoji || "🧠"}</span>
                <div>
                  <div className="text-base font-bold text-white">
                    Настроение: {moodCfg?.ruName || selectedEntry.mood}
                  </div>
                  <div className="text-xs text-slate-400 font-mono tabular-nums">
                    {new Date(selectedEntry.timestamp).toLocaleString("ru-RU")} · Интенсивность:{" "}
                    {selectedEntry.intensityBefore}/10 → {selectedEntry.intensityAfter}/10
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
              <h3 className="text-sm font-bold text-indigo-300 mb-2">1. Тревожная мысль</h3>
              <p className="text-sm text-slate-100 leading-relaxed">{selectedEntry.originalThought}</p>
            </div>

            {distList.length > 0 && (
              <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
                <h3 className="text-sm font-bold text-purple-300 mb-3">
                  2. Выявленные когнитивные искажения
                </h3>
                <div className="space-y-2.5">
                  {distList.map((title) => {
                    const info = DISTORTION_OPTIONS.find((d) => d.title === title || d.ruTitle === title);
                    return (
                      <div key={title} className="text-xs">
                        <span className="font-bold text-white">{info?.ruTitle || title}</span>
                        {info?.description && (
                          <span className="text-slate-400"> — {info.description}</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
              <h3 className="text-sm font-bold text-emerald-300 mb-2">3. Рациональный ответ</h3>
              <p className="text-sm text-slate-100 leading-relaxed">{selectedEntry.rationalThought}</p>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-indigo-500/30 bg-indigo-950/25 p-6 h-full">
              <div className="flex items-center gap-2.5 pb-4 mb-4 border-b border-indigo-500/20">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white">AI Рефлексия от Gemini</h3>
              </div>
              <div className="text-sm text-slate-200 whitespace-pre-line leading-relaxed">
                {selectedEntry.geminiFeedback || "Анализ для данной записи не запрашивался."}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubScreen === "add-log") {
    return (
      <div
        className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8 max-w-3xl mx-auto"
        data-testid="cbt-wizard-container"
      >
        <div className="flex items-center justify-between gap-4 mb-6">
          <button
            type="button"
            onClick={() => {
              if (step > 1) setStep((s) => (s - 1) as 1 | 2 | 3);
              else onChangeSubScreen("journal");
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{step > 1 ? "Назад" : "Отмена"}</span>
          </button>

          <div className="text-sm font-bold text-white">
            Шаг {step} из 3:{" "}
            {step === 1
              ? "Настроение"
              : step === 2
              ? "Тревожная мысль и искажения"
              : "Рациональный ответ и оценка"}
          </div>

          <div className="text-xs font-mono tabular-nums text-indigo-400">КПТ-Протокол</div>
        </div>

        {validationError && (
          <div
            role="alert"
            className="mb-5 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 flex items-center gap-2"
          >
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {isAnalyzing ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 rounded-full border-2 border-indigo-400 border-t-transparent animate-spin mx-auto" />
            <div className="text-lg font-bold text-white">AI-компаньон анализирует запись...</div>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Gemini формирует поддерживающий КПТ-разбор вашей мысли и когнитивных искажений.
            </p>
          </div>
        ) : (
          <>
            {step === 1 && (
              <div>
                <h2 className="text-xl font-bold text-white mb-2">Как вы себя сейчас чувствуете?</h2>
                <p className="text-xs text-slate-400 mb-5">
                  Выберите ведущую эмоцию, чтобы отследить динамику состояния
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {MOOD_OPTIONS.map((mood) => {
                    const isSelected = selectedMood.name === mood.name;
                    return (
                      <button
                        key={mood.name}
                        type="button"
                        onClick={() => setSelectedMood(mood)}
                        data-testid={`mood-option-${mood.name}`}
                        className="p-4 rounded-2xl border text-left transition-all cursor-pointer"
                        style={{
                          borderColor: isSelected ? mood.color : "rgba(51, 65, 85, 0.8)",
                          backgroundColor: isSelected
                            ? `${mood.color}22`
                            : "rgba(15, 23, 42, 0.65)",
                        }}
                      >
                        <div className="text-2xl mb-1.5">{mood.emoji}</div>
                        <div className="text-sm font-bold text-white">{mood.ruName}</div>
                        <div className="text-[11px] text-slate-400">{mood.name}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-5">
                <div>
                  <label
                    htmlFor="cbt-original-thought"
                    className="block text-sm font-bold text-white mb-1"
                  >
                    Запишите автоматическую тревожную мысль
                  </label>
                  <p className="text-xs text-slate-400 mb-2.5">
                    Например: «Если я ошибусь на презентации, все решат, что я некомпетентен».
                  </p>
                  <textarea
                    id="cbt-original-thought"
                    data-testid="thought-input"
                    value={originalThought}
                    onChange={(e) => setOriginalThought(e.target.value)}
                    rows={3}
                    placeholder="Опишите тревожную мысль..."
                    className="w-full rounded-xl border border-slate-700 bg-slate-950/90 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-400"
                  />
                </div>

                <div>
                  <div className="text-sm font-bold text-white mb-1">
                    Отметьте когнитивные искажения
                  </div>
                  <p className="text-xs text-slate-400 mb-3">
                    Какие ловушки мышления присутствуют в этой мысли?
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {DISTORTION_OPTIONS.map((dist) => {
                      const checked = selectedDistortions.includes(dist.title);
                      return (
                        <button
                          key={dist.title}
                          type="button"
                          onClick={() => toggleDistortion(dist.title)}
                          className={`p-3.5 rounded-xl border text-left transition-colors cursor-pointer ${
                            checked
                              ? "border-indigo-400 bg-indigo-500/15"
                              : "border-slate-800 bg-slate-950/60 hover:border-slate-700"
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-white">{dist.ruTitle}</span>
                            <span className="text-[11px] font-mono text-indigo-300">
                              {checked ? "Выбрано" : "Выбрать"}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">{dist.description}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-5">
                <div>
                  <label
                    htmlFor="cbt-rational-thought"
                    className="block text-sm font-bold text-white mb-1"
                  >
                    Сформулируйте рациональный, сбалансированный ответ
                  </label>
                  <p className="text-xs text-slate-400 mb-2.5">
                    Посмотрите на ситуацию объективно: какие факты говорят в вашу пользу?
                  </p>
                  <textarea
                    id="cbt-rational-thought"
                    data-testid="reframing-input"
                    value={rationalThought}
                    onChange={(e) => setRationalThought(e.target.value)}
                    rows={3}
                    placeholder="Запишите взвешенный рациональный взгляд..."
                    className="w-full rounded-xl border border-slate-700 bg-slate-950/90 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="text-slate-300">Интенсивность ДО:</span>
                      <span className="font-mono font-bold text-amber-300 tabular-nums">
                        {intensityBefore} / 10
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={10}
                      value={intensityBefore}
                      onChange={(e) => setIntensityBefore(Number(e.target.value))}
                      aria-label="Интенсивность тревоги до рефрейминга"
                      className="w-full accent-amber-400"
                    />
                  </div>

                  <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="text-slate-300">Интенсивность ПОСЛЕ:</span>
                      <span className="font-mono font-bold text-emerald-300 tabular-nums">
                        {intensityAfter} / 10
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={10}
                      value={intensityAfter}
                      onChange={(e) => setIntensityAfter(Number(e.target.value))}
                      aria-label="Интенсивность тревоги после рефрейминга"
                      className="w-full accent-emerald-400"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep((s) => (s - 1) as 1 | 2 | 3)}
                  className="px-4 py-2.5 rounded-xl border border-slate-700 text-xs font-semibold text-slate-200 hover:bg-slate-800 cursor-pointer"
                >
                  Назад
                </button>
              )}
              <button
                type="button"
                onClick={handleWizardNext}
                data-testid="next-step-button"
                className="px-5 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-xs font-bold text-white transition-colors cursor-pointer"
              >
                {step === 3 ? "Сохранить и получить AI-разбор" : "Далее →"}
              </button>
            </div>
          </>
        )}
      </div>
    );
  }

  const roadmap = calculateCbtRoadmapStage(entries.length);
  const moodDist = calculateMoodDistribution(entries);
  const totalBreathingSeconds = breathingSessions.reduce((acc, s) => acc + s.durationSeconds, 0);

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/85 p-6 md:p-8" data-testid="mindsync-root">
      {/* Header & Bento Segmented Switch */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">MindSync</h1>
            <p className="text-xs text-slate-400">
              AI-дневник когнитивно-поведенческой терапии (КПТ) и практик осознанности
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          {/* Interactive Filter Tabs (Functional Buttons) */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              type="button"
              onClick={() => onChangeSubScreen("journal")}
              data-testid="tab-cbt-journal"
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSubScreen === "journal"
                  ? "bg-indigo-500 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Дневник КПТ ({entries.length})
            </button>
            <button
              type="button"
              onClick={() => onChangeSubScreen("insights")}
              data-testid="tab-cbt-insights"
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSubScreen === "insights"
                  ? "bg-indigo-500 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Инсайты и Практики
            </button>
          </div>

          <button
            type="button"
            onClick={openAddWizard}
            data-testid="add-log-button"
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Новая запись КПТ</span>
          </button>
        </div>
      </div>

      {activeSubScreen === "journal" ? (
        <div className="space-y-4">
          {entries.length === 0 ? (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-10 text-center">
              <Brain className="w-10 h-10 text-indigo-400 mx-auto mb-3" />
              <h2 className="text-lg font-bold text-white">Ваш дневник чист</h2>
              <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 mb-5">
                Добавьте первую запись, чтобы разобрать тревожную мысль и получить поддерживающий AI-анализ от Gemini.
              </p>
              <button
                type="button"
                onClick={openAddWizard}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-bold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Создать первую запись КПТ</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="journal-entries-list">
              {entries.map((entry) => {
                const moodCfg = MOOD_OPTIONS.find((m) => m.name === entry.mood);
                const ruName = moodCfg?.ruName || entry.mood;
                const emoji = moodCfg?.emoji || "🧠";
                const distRu = entry.distortions
                  .split(", ")
                  .filter(Boolean)
                  .map((d) => DISTORTION_OPTIONS.find((opt) => opt.title === d)?.ruTitle || d)
                  .join(", ");

                return (
                  <article
                    key={entry.id}
                    data-testid="journal-item"
                    onClick={() => {
                      setSelectedEntry(entry);
                      onChangeSubScreen("detail");
                    }}
                    className="rounded-2xl border border-slate-800 bg-slate-950/65 hover:border-indigo-500/40 p-5 transition-colors cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      {/* Clean unboxed metadata header per Zero-Pill rule */}
                      <div className="flex items-center justify-between gap-2 text-xs text-slate-400 mb-3">
                        <span className="font-semibold text-white">
                          {emoji} {ruName}
                        </span>
                        <span className="font-mono tabular-nums">
                          {new Date(entry.timestamp).toLocaleDateString("ru-RU", {
                            day: "2-digit",
                            month: "short",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>

                      <div className="text-[11px] font-semibold text-indigo-300 mb-1">
                        Тревожная мысль:
                      </div>
                      <h3 className="text-sm font-bold text-white line-clamp-2 mb-2">
                        {entry.originalThought}
                      </h3>

                      <div className="text-[11px] font-semibold text-emerald-300 mb-1">
                        Рациональный ответ:
                      </div>
                      <p className="text-xs text-slate-300 line-clamp-2 mb-3">
                        {entry.rationalThought}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2 text-xs text-slate-400">
                      <span>
                        Искажения: <strong className="text-slate-200">{distRu || "Не указаны"}</strong>
                      </span>
                      <span className="font-mono tabular-nums text-emerald-400 shrink-0">
                        Тревога: {entry.intensityBefore} → {entry.intensityAfter}/10
                      </span>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* INSIGHTS & BREATHING BENTO GRID */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5" data-testid="insights-bento-grid">
          {/* 1. CBT Development Roadmap Card */}
          <div className="lg:col-span-7 rounded-2xl border border-purple-500/30 bg-purple-950/20 p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <h2 className="text-lg font-bold text-white">Путь осознанности</h2>
                <span className="text-xs font-mono font-bold text-purple-300 tabular-nums">
                  {roadmap.phaseLabel}
                </span>
              </div>
              <p className="text-sm text-slate-300 mb-5">{roadmap.phaseTitle}</p>
            </div>

            <div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden mb-3">
                <div
                  className="h-full bg-purple-400 rounded-full transition-all duration-300"
                  style={{ width: `${roadmap.progressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Новичок рефлексии</span>
                <span className="font-mono tabular-nums">{roadmap.progressPercent}% освоено</span>
                <span>Мастер КПТ</span>
              </div>
            </div>
          </div>

          {/* 2. Box Breathing 4-4-4-4 Launcher Card */}
          <div className="lg:col-span-5 rounded-2xl border border-indigo-500/30 bg-indigo-950/25 p-6 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-indigo-300 uppercase tracking-wider mb-1">
                Анти-стресс практика
              </div>
              <h2 className="text-xl font-bold text-white mb-2">
                Квадратное дыхание (4-4-4-4)
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed mb-5">
                Снизьте острую тревогу и стабилизируйте пульс с помощью ритмичного дыхания по 4 секунды на каждую фазу.
              </p>
            </div>

            <button
              type="button"
              onClick={() => onChangeSubScreen("breathing")}
              data-testid="open-breathing-button"
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              <Wind className="w-4 h-4" />
              <span>Открыть тренажер дыхания</span>
            </button>
          </div>

          {/* 3. Stats Cells */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5 flex flex-col justify-between">
              <CheckCircle2 className="w-5 h-5 text-indigo-400 mb-4" />
              <div>
                <div
                  className="text-3xl font-extrabold font-mono text-white tabular-nums"
                  data-testid="stat-cbt-count"
                >
                  {entries.length}
                </div>
                <div className="text-xs text-slate-400 mt-1">Записей КПТ</div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5 flex flex-col justify-between">
              <Wind className="w-5 h-5 text-emerald-400 mb-4" />
              <div>
                <div
                  className="text-2xl font-extrabold font-mono text-emerald-300 tabular-nums"
                  data-testid="stat-breathing-time"
                >
                  {formatDurationRu(totalBreathingSeconds)}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Время дыхания ({breathingSessions.length} сессий)
                </div>
              </div>
            </div>
          </div>

          {/* 4. Mood Distribution Block */}
          <div className="lg:col-span-7 rounded-2xl border border-slate-800 bg-slate-950/60 p-6">
            <h3 className="text-base font-bold text-white mb-4">Распределение эмоций</h3>
            {moodDist.length === 0 ? (
              <p className="text-xs text-slate-400">
                Добавьте записи в дневник КПТ, чтобы увидеть аналитику эмоционального фона.
              </p>
            ) : (
              <div className="space-y-3">
                {moodDist.map((item) => (
                  <div key={item.mood}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-semibold text-white">
                        {item.emoji} {item.ruName}
                      </span>
                      <span className="font-mono tabular-nums text-slate-400">
                        {item.count} зап. · {item.percentage}%
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${item.percentage}%`,
                          backgroundColor: item.color,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// BOX BREATHING 4-4-4-4 EXERCISE STUDIO
// ============================================================================
interface BreathingStudioProps {
  onSaveSession: (durationSeconds: number) => void;
  onBack: () => void;
}

const BreathingExerciseStudio: React.FC<BreathingStudioProps> = ({
  onSaveSession,
  onBack,
}) => {
  const [isActive, setIsActive] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [breathPhase, setBreathPhase] = useState<0 | 1 | 2 | 3>(0);
  const [phaseTimer, setPhaseTimer] = useState(4);
  const reactorCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setSecondsElapsed((s) => s + 1);
      setPhaseTimer((prevTimer) => {
        const next = advanceBoxBreathingTimer(breathPhase, prevTimer);
        if (next.breathPhase !== breathPhase) {
          setBreathPhase(next.breathPhase);
          soundEngine.playNoteIndex(next.breathPhase * 2, 320);
        }
        return next.phaseTimer;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isActive, breathPhase]);

  const phaseInfo = getBreathPhaseInfo(breathPhase);

  // 60fps Sacred Geometry & Stargate Prana Reactor Canvas
  useEffect(() => {
    let animId = 0;
    let t = 0;
    const pranaParticles = Array.from({ length: 48 }, (_, i) => ({
      angle: (i / 48) * Math.PI * 2,
      radiusOffset: (i % 4) * 16,
      speed: 0.008 + (i % 3) * 0.004,
      size: 1.5 + (i % 3) * 0.9,
    }));

    const renderReactor = () => {
      t += isActive ? 0.025 : 0.01;
      const canvas = reactorCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          const cx = w / 2;
          const cy = h / 2;
          ctx.clearRect(0, 0, w, h);

          const targetScale = isActive
            ? breathPhase === 0 || breathPhase === 1
              ? 1.18
              : 0.86
            : 1.0;
          const baseR = 78 * targetScale + Math.sin(t * 2) * 3;

          // 1. Volumetric Prana Aura
          const auraGrad = ctx.createRadialGradient(cx, cy, 8, cx, cy, baseR * 1.65);
          auraGrad.addColorStop(0, `${phaseInfo.breathColor}55`);
          auraGrad.addColorStop(0.55, `${phaseInfo.breathColor}1E`);
          auraGrad.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = auraGrad;
          ctx.beginPath();
          ctx.arc(cx, cy, baseR * 1.65, 0, Math.PI * 2);
          ctx.fill();

          ctx.save();
          ctx.globalCompositeOperation = "lighter";

          // 2. Rotating Sacred 4-4-4-4 Octagram (Two Intersecting Squares of Box Breathing)
          for (let sq = 0; sq < 2; sq++) {
            const rot = t * (sq === 0 ? 0.45 : -0.45) + (sq * Math.PI) / 4;
            const sqR = baseR * 1.18;
            ctx.strokeStyle = sq === 0 ? `${phaseInfo.breathColor}AA` : "rgba(129, 140, 248, 0.55)";
            ctx.lineWidth = 2;
            ctx.beginPath();
            for (let corner = 0; corner < 4; corner++) {
              const cAng = rot + (corner * Math.PI) / 2;
              const x = cx + Math.cos(cAng) * sqR;
              const y = cy + Math.sin(cAng) * sqR;
              if (corner === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.stroke();
          }

          // 3. Stargate Prana Ring + 9 Locking Chevrons
          ctx.strokeStyle = phaseInfo.breathColor;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(cx, cy, baseR, 0, Math.PI * 2);
          ctx.stroke();

          for (let c = 0; c < 9; c++) {
            const ang = (c / 9) * Math.PI * 2 + t * 0.3;
            const chx = cx + Math.cos(ang) * baseR;
            const chy = cy + Math.sin(ang) * baseR;
            ctx.fillStyle = "#FFFFFF";
            ctx.beginPath();
            ctx.arc(chx, chy, 3.5, 0, Math.PI * 2);
            ctx.fill();
          }

          // 4. Orbital Prana Particles
          for (const p of pranaParticles) {
            p.angle += isActive ? p.speed * 1.8 : p.speed;
            const pr = baseR * 0.85 + p.radiusOffset + Math.sin(t * 2 + p.angle) * 6;
            const px = cx + Math.cos(p.angle) * pr;
            const py = cy + Math.sin(p.angle) * pr;
            ctx.fillStyle = phaseInfo.breathColor;
            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();

          // 5. Inner Core Disc
          ctx.fillStyle = phaseInfo.breathColor;
          ctx.beginPath();
          ctx.arc(cx, cy, 54, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      animId = requestAnimationFrame(renderReactor);
    };

    animId = requestAnimationFrame(renderReactor);
    return () => cancelAnimationFrame(animId);
  }, [isActive, breathPhase, phaseInfo.breathColor]);

  const handleFinishAndSave = () => {
    if (secondsElapsed > 0) {
      onSaveSession(secondsElapsed);
    }
    onBack();
  };

  return (
    <div
      className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 md:p-8 max-w-2xl mx-auto text-center"
      data-testid="breathing-studio"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={handleFinishAndSave}
          data-testid="breathing-back-button"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Завершить и сохранить</span>
        </button>

        <div className="text-sm font-bold text-white">Реактор Праны 4-4-4-4 (Stargate Mandala)</div>

        <button
          type="button"
          onClick={() => {
            setSecondsElapsed((s) => s + 16);
            soundEngine.playArpeggio(2);
          }}
          data-testid="breathing-add-cycle-button"
          className="px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400/30 text-indigo-200 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          +1 цикл (16 с)
        </button>
      </div>

      <h2 className="text-2xl font-bold text-white mb-2">Квадратное дыхание Навигатора (4-4-4-4)</h2>
      <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
        Следуйте за сакральной 4D-мандалой: 4 секунды вдох, 4 секунды задержка, 4 секунды выдох и 4 секунды пауза.
      </p>

      {/* Interactive 60fps Sacred Geometry & Stargate Prana Reactor Canvas */}
      <div className="relative w-72 h-72 mx-auto flex items-center justify-center my-4">
        <canvas
          ref={reactorCanvasRef}
          width={300}
          height={300}
          data-testid="breathing-reactor-canvas"
          className="absolute inset-0 w-full h-full block pointer-events-none"
        />
        <div className="relative z-10 flex flex-col items-center justify-center pointer-events-none">
          <div className="text-4xl font-extrabold font-mono text-slate-950 tabular-nums">
            {isActive ? phaseTimer : "4"}
          </div>
          <div className="text-xs font-bold text-slate-900 mt-0.5">
            {isActive ? phaseInfo.cycleText : "Готовы"}
          </div>
        </div>
      </div>

      <div className="my-5">
        <div className="text-lg font-bold text-white">
          {isActive ? phaseInfo.cycleText : "Нажмите «Начать практику»"}
        </div>
        <div
          className="text-sm font-mono tabular-nums text-slate-400 mt-1"
          data-testid="breathing-elapsed-text"
        >
          Длительность сессии: {formatDurationRu(secondsElapsed)}
        </div>
      </div>

      <div className="flex items-center justify-center gap-3">
        <button
          type="button"
          onClick={() => {
            setIsActive((prev) => !prev);
            soundEngine.playNoteIndex(0, 250);
          }}
          data-testid="breathing-start-stop-button"
          className={`inline-flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-bold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            isActive ? "bg-rose-500 hover:bg-rose-400" : "bg-indigo-500 hover:bg-indigo-400"
          }`}
        >
          {isActive ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isActive ? "Пауза" : "Начать практику"}</span>
        </button>
      </div>
    </div>
  );
};
