import React, { useEffect, useRef, useState } from "react";
import {
  Compass,
  Brain,
  Sparkles,
  Orbit,
  Layers,
  GitBranch,
  ShieldCheck,
  ArrowRight,
  Play,
  BookOpen,
  Cpu,
  Flame,
  Eye,
} from "lucide-react";
import {
  type ThemePreset,
  type NavigatorSyncTelemetry,
} from "../utils/appLogic";
import { soundEngine } from "../utils/soundEngine";

export interface LiminalNodeRoom {
  id: string;
  code: string;
  title: string;
  archetype: string;
  x: number; // normalized 0.1..0.9
  y: number; // normalized 0.15..0.85
  zDepth: number;
  vesselCapacity: string;
  externalAstralManifestation: string; // Part 1 (Outside the Astronaut)
  internalMentalManifestation: string; // Part 2 (Inside the Astronaut)
  liminalBridge: string; // What lies between the labyrinths/locations
  medievalParallel: string;
  scifiTechParallel: string;
  recommendedGate: "funnel" | "carousel" | "bubbles";
  connectedTo: string[];
}

export const LIMINAL_NODES: LiminalNodeRoom[] = [
  {
    id: "node-1",
    code: "УЗЕЛ I · CHVR-01",
    title: "Обсидиановый Вестибюль Сновидца",
    archetype: "Исходная Ёмкость (Точка Входа в Медитацию)",
    x: 0.15,
    y: 0.5,
    zDepth: 0.2,
    vesselCapacity: "Ёмкость Покоя · 108 Гц",
    externalAstralManifestation:
      "Чёрная зеркальная дорога из вулканического обсидиана, парящая над бездной, где слева и справа параллельно текут ленты прошлых и будущих событий.",
    internalMentalManifestation:
      "Первичное наблюдение за дыханием (4-4-4-4) внутри гермошлема Космонавта; отключение внешнего информационного шума.",
    liminalBridge:
      "Туннель «Ловца Сфер» — гравитационная воронка, собирающая разрозненные кванты внимания в единый луч.",
    medievalParallel:
      "Nigredo (Алхимическое чернение) и вход во «Дворец Памяти» Раймунда Луллия через врата безмолвия.",
    scifiTechParallel:
      "Инициализация Stargate-шевронов и квантовая декапсуляция сознания оператора перед гиперпрыжком.",
    recommendedGate: "funnel",
    connectedTo: ["node-2", "node-3"],
  },
  {
    id: "node-2",
    code: "УЗЕЛ II · CHVR-02",
    title: "Хроно-Коридор Параллельных Времён",
    archetype: "Осевое 4-е Измерение (Синхронность Пространства-Времени)",
    x: 0.36,
    y: 0.24,
    zDepth: 0.55,
    vesselCapacity: "Ёмкость Хроноса · 261.6 Гц (C4)",
    externalAstralManifestation:
      "Искривлённый мост Звёздных Врат, где причины и следствия видны одновременно как геометрия: созвездия вспыхивают до того, как к ним прикасается рука.",
    internalMentalManifestation:
      "Распознавание искажения «Катастрофизация» (страх будущего) и возврат ума Космонавта в точку осевого настоящего.",
    liminalBridge:
      "Вращающаяся 3D-призма «Карусели Созвездий» — переход из линейного времени в объёмное сферическое восприятие.",
    medievalParallel:
      "Армиллярная сфера и небесные колёса Иезекииля / герметический космос Роберта Фладда.",
    scifiTechParallel:
      "Четырёхмерный тессеракт (гиперкуб) и релятивистский коридор кротовой норы Эйнштейна — Розена.",
    recommendedGate: "carousel",
    connectedTo: ["node-1", "node-4", "node-5"],
  },
  {
    id: "node-3",
    code: "УЗЕЛ III · CHVR-03",
    title: "Зеркальный Лабиринт Искажений",
    archetype: "Испытание Ментальной Оболочки",
    x: 0.36,
    y: 0.76,
    zDepth: 0.4,
    vesselCapacity: "Ёмкость Очищения · 329.6 Гц (E4)",
    externalAstralManifestation:
      "Поле преломляющих обсидиановых кристаллов и ложных гравитационных течений, пытающихся увести корабль-аватар с главной оси.",
    internalMentalManifestation:
      "Фиксация тревожных автоматических мыслей («Чтение мыслей», «Чёрно-белое мышление») в КПТ-журнале MindSync и их алхимическая переплавка в рациональный ответ.",
    liminalBridge:
      "Шлюз «Эфирных Пузырей» — разделение тяжёлой монолитной тревоги на лёгкие, управляемые и прозрачные сферы.",
    medievalParallel:
      "Albedo (Омывание / Белая стадия алхимии) — очищение философского камня от шлаков иллюзий.",
    scifiTechParallel:
      "Адаптивная оптика телескопа и фильтрация когнитивных помех нейроинтерфейса с помощью ИИ Gemini.",
    recommendedGate: "bubbles",
    connectedTo: ["node-1", "node-4", "node-6"],
  },
  {
    id: "node-4",
    code: "УЗЕЛ IV · AXIS-00",
    title: "Осевой Астральный Шпиль (Axis Mundi)",
    archetype: "Центральный Перекрёсток Междумирья",
    x: 0.56,
    y: 0.5,
    zDepth: 0.9,
    vesselCapacity: "Ёмкость Абсолютного Резонанса · 440 Гц (A4)",
    externalAstralManifestation:
      "Вертикальная неоново-обсидиановая ось мира, вокруг которой вращаются все локации-комнаты. Здесь внешнее 3D-пространство выворачивается наизнанку, переходя в 4D.",
    internalMentalManifestation:
      "Точка нулевой тревоги внутри Космонавта: полное совпадение ритма сердца, дыхания (4-4-4-4) и ясного рационального сознания.",
    liminalBridge:
      "Прямой квантовый туннель Звёздных Врат (Stargate Event Horizon), соединяющий внутренний мир пилота с внешней космологией.",
    medievalParallel:
      "Изумрудная Скрижаль Гермеса Трисмегиста: «То, что внизу, аналогично тому, что вверху» и Мировое Древо.",
    scifiTechParallel:
      "Глобальный граф знаний Obsidian (Центральный Хаб-Узел с максимальной центральностью связей).",
    recommendedGate: "carousel",
    connectedTo: ["node-2", "node-3", "node-5", "node-6", "node-7"],
  },
  {
    id: "node-5",
    code: "УЗЕЛ V · CHVR-05",
    title: "Алхимический Реактор Эфирных Сосудов",
    archetype: "Трансмутация Состояний и Ёмкостей",
    x: 0.75,
    y: 0.25,
    zDepth: 0.6,
    vesselCapacity: "Ёмкость Синтеза · 523.2 Гц (C5)",
    externalAstralManifestation:
      "Восходящий поток радужных плазменных сфер из золотого сопла в невесомости, где малые капли опыта сливаются в мега-сферы мудрости.",
    internalMentalManifestation:
      "Интеграция инсайтов КПТ: перевод подавленной энергии страха или гнева в созидательный ресурс и концентрацию.",
    liminalBridge:
      "Мембрана поверхностного натяжения между двумя соседними лабиринтами: переход из жидкого эмоционального состояния в кристаллическое.",
    medievalParallel:
      "Vas Hermeticum (Герметический сосуд) и циркуляция квинтэссенции (Пятого элемента).",
    scifiTechParallel:
      "Магнитное удержание плазмы в термоядерном токамаке и слияние кластеров данных в векторном пространстве.",
    recommendedGate: "bubbles",
    connectedTo: ["node-2", "node-4", "node-7"],
  },
  {
    id: "node-6",
    code: "УЗЕЛ VI · CHVR-06",
    title: "Архив Живых Связей (Псевдо-Обсидиан)",
    archetype: "Нейронная Карта Локаций и Воспоминаний",
    x: 0.75,
    y: 0.75,
    zDepth: 0.5,
    vesselCapacity: "Ёмкость Памяти · 659.2 Гц (E5)",
    externalAstralManifestation:
      "Светящаяся паутина гиперссылок в тёмном обсидиановом космосе: каждая пройденная дорога оставляет золотую нить в графе.",
    internalMentalManifestation:
      "Долгосрочная память дневника MindSync и Журнала Сновидений: паттерны эмоций становятся прозрачной картой самопознания.",
    liminalBridge:
      "Синаптический зазор между комнатами — мгновенный телепорт по смысловому сходству (ассоциативный прыжок).",
    medievalParallel:
      "Нить Ариадны в критском лабиринте и средневековые бестиарии/кодексы с перекрёстными глоссами.",
    scifiTechParallel:
      "Графовая база знаний Obsidian (Second Brain) и многомерные эмбеддинги смыслов.",
    recommendedGate: "funnel",
    connectedTo: ["node-3", "node-4", "node-7"],
  },
  {
    id: "node-7",
    code: "УЗЕЛ VII · CHVR-07",
    title: "Горизонт Сингулярности Навигатора",
    archetype: "Высшая Ёмкость Пробуждённого Сновидения",
    x: 0.9,
    y: 0.5,
    zDepth: 1.0,
    vesselCapacity: "Ёмкость Бесконечности · 880 Гц (A5)",
    externalAstralManifestation:
      "Открытые Звёздные Врата 7-го шеврона: сияющий портал, где дорога, путник и сам космос осознаются как единая музыкальная симфония.",
    internalMentalManifestation:
      "Этап 4/4 «Мастер рефрейминга»: внутренняя тишина и ясность, при которой любая турбулентность мгновенно преобразуется в гармонию.",
    liminalBridge:
      "Выход за пределы переходов: способность свободно перемещаться между любыми ёмкостями и измерениями без потери осознанности.",
    medievalParallel:
      "Rubedo (Великое Делание в красном/золотом) и Coincidentia Oppositorum (совпадение противоположностей Николая Кузанского).",
    scifiTechParallel:
      "Квантовая когерентность сознания 4-го измерения и полная синхронизация Аватара с ядром симуляции.",
    recommendedGate: "carousel",
    connectedTo: ["node-4", "node-5", "node-6"],
  },
];

export interface TheoreticalPillar {
  id: string;
  category: string;
  title: string;
  subtitle: string;
  summary: string;
  part1Role: string;
  part2Role: string;
  betweenLocationsMechanics: string;
}

export const THEORETICAL_PILLARS: TheoreticalPillar[] = [
  {
    id: "pillar-1",
    category: "1. Космология и Дуализм Контуров",
    title: "Экзо-Астрал (Часть 1) × Эндо-Ментал Космонавта (Часть 2)",
    subtitle: "Единая кибернетическая и герметическая модель «Скафандр — Космос»",
    summary:
      "Представьте Аватара-Навигатора, плывущего в глубокой медитации сквозь многомерный космос. Часть 1 (Surreal Circus) — это то, что разворачивается СНАРУЖИ его скафандра: осевой 4D-астрал, псевдо-обсидиановая трасса, звёздные врата и гравитационные потоки, где прошлое и будущее текут параллельно. Часть 2 (MindSync) — это то, что происходит ВНУТРИ сознания самого Космонавта: его мысли, страхи, когнитивные искажения и дыхание.",
    part1Role:
      "Внешний макрокосм: 3D/4D-перспектива дороги, шевроны Stargate, созвездия-узлы и пентатоническая музыка сфер.",
    part2Role:
      "Внутренний микрокосм: приборная панель психики пилота (КПТ-рефрейминг тревоги + квадратное дыхание 4-4-4-4 для стабилизации пульса).",
    betweenLocationsMechanics:
      "Любое когнитивное искажение внутри Космонавта (Часть 2) вызывает турбулентность на внешней астральной дороге (Часть 1). Очищая мысль внутри, Навигатор открывает Звёздные Врата снаружи.",
  },
  {
    id: "pillar-2",
    category: "2. Теория «Ёмкостей» и Межлабиринтных Переходов",
    title: "Узлы-Комнаты, Ёмкости Сознания и Лиминальные Мосты",
    subtitle: "Что находится между локациями и как происходит перетекание",
    summary:
      "В классических играх и системах локации — это статичные комнаты, а переходы — просто экраны загрузки. В нашей методологии каждая комната — это «Ёмкость» (сосуд определённого объёма внимания и частоты). А то, что представлено в 1-й и 2-й частях приложения — это САМ ПРОЦЕСС ПЕРЕХОДА (Лиминальное Междумирье) между ёмкостями!",
    part1Role:
      "Аттракционы 1-й части — это динамические шлюзы (мосты-червоточины) между двумя комнатами-лабиринтами, где инерция старой локации сбрасывается через ритм и геометрию.",
    part2Role:
      "Практики 2-й части — это шлюз декомпрессии: прежде чем войти в новую «ёмкость», Космонавт должен опустошить сосуд от остаточного давления предыдущего лабиринта.",
    betweenLocationsMechanics:
      "Переход работает по принципу сообщающихся сосудов: 1) Сброс напряжения (КПТ), 2) Выравнивание давления (дыхание 4-4-4-4), 3) Пролёт по астральному мосту (Stargate-трасса).",
  },
  {
    id: "pillar-3",
    category: "3. Инновационный Псевдо-Обсидиановый Граф (Obsidian × Stargate)",
    title: "Визуальная эстетика: Чёрный Обсидиан, Неоновые Рёбра и Звёздные Врата",
    subtitle: "От графа знаний Obsidian к пространственному 4D-прыжку",
    summary:
      "Визуальный код объединяет две мощные эстетики: 1) Глубокое вулканическое обсидиановое стекло и светящуюся паутину связанных узлов-мыслей (как в графе Obsidian), и 2) Энергетическое кольцо Звёздных Врат (Stargate) с кодирующими шевронами и водянистым зеркалом горизонта событий.",
    part1Role:
      "На трассе и в карусели звёзды соединяются графовыми рёбрами в реальном времени; на горизонте сияет кольцо Врат с 9 шевронами и волнами хроно-сингулярности.",
    part2Role:
      "Каждая запись КПТ — это новый узел в личном графе самопознания, который связывает триггер, искажение и рациональный инсайт в устойчивую кристаллическую решётку.",
    betweenLocationsMechanics:
      "Соединение 3+ одноцветных узлов в «Карусели Созвездий» визуализирует момент смыслового инсайта (связывания заметок в Obsidian), открывающего червоточину в следующий зал.",
  },
  {
    id: "pillar-4",
    category: "4. Средневековая Герметика, Алхимия и Ars Memoria",
    title: "Средневековые корни: Театры Памяти, Астролябии и Vas Hermeticum",
    subtitle: "Древняя мудрость навигации по внутренним чертогам",
    summary:
      "Задолго до появления VR и нейросетей средневековые мыслители (Раймунд Луллий, Джордано Бруно, Роберт Фладд) разработали Ars Memoria — искусство путешествия по внутренним архитектурным лабиринтам и вращающимся концентрическим колёсам смыслов.",
    part1Role:
      "«Карусель Созвездий» напрямую наследует средневековую армиллярную сферу и комбинаторные круги Луллия, а пентатонический строй отражает пифагорейскую «Музыку Небесных Сфер» (Musica Universalis).",
    part2Role:
      "КПТ-дневник выполняет роль алхимического сосуда (Vas Hermeticum), где свинец тревоги (Nigredo) через честный анализ (Albedo) превращается в золото ясного разума (Rubedo).",
    betweenLocationsMechanics:
      "Переход между локациями соответствует герметическому принципу «Solve et Coagula» — растворяй застывшую форму старой комнаты (в Эфирных Пузырях) и кристаллизуй новую (в Созвездиях).",
  },
  {
    id: "pillar-5",
    category: "5. Фантастическая 4D-Физика и Осевое Время",
    title: "Осевой Астрал и Одновременность Времён на Трассе",
    subtitle: "Как показать 4-е измерение на экране",
    summary:
      "В трёхмерном мире путник видит только то, что прямо перед ним сейчас. В 4-м осевом измерении (Астральной Оси) время становится пространственной координатой: левая полоса дороги несёт отпечатки прошлого, центральная ось — чистое присутствие, а правая — веер вероятных будущих ветвлений.",
    part1Role:
      "В «Ловце Сфер» шары катятся по параллельным хроно-струнам одновременно, а проекция тессеракта в «Карусели» позволяет заглянуть за грань обычной перспективы.",
    part2Role:
      "Человек страдает в ментале потому, что застревает либо в вине прошлого, либо в катастрофизации будущего. Возврат ползунка тревоги к балансу — это центрирование на Оси Времени.",
    betweenLocationsMechanics:
      "Между локациями время течёт не по часам, а по плотности осознанности: один глубокий цикл дыхания 4-4-4-4 равен целому парсеку пути по Звёздному Мосту.",
  },
  {
    id: "pillar-6",
    category: "6. Уникальная Технологическая Методология (Bio-Cognitive Game Loop)",
    title: "Нейро-Игровой Контур: Геймификация Осознанности без Насилия",
    subtitle: "Практический фреймворк для современных приложений и метавселенных",
    summary:
      "Традиционные игры эксплуатируют дофамин стресса (таймеры смерти, враги, Game Over). Наша методология строит «Петлю Гармонического Перехода»: игра не наказывает за промах, а использует визуально-акустическую синестезию и ИИ-рефлексию как навигационный прибор.",
    part1Role:
      "Математическая 3D-проекция на 2D-холсте + процедурный синтез звука в реальном времени создают состояние мягкого потока (Flow state) и сенсорной разгрузки.",
    part2Role:
      "Большая языковая модель (Gemini) выступает как «Бортовой ИИ-Психолог корабля», помогающий расшифровать аномалии на пути между узлами.",
    betweenLocationsMechanics:
      "Единый индекс «Когерентности Навигатора» объединяет очки гармонии 1-й части и снижение тревоги 2-й части, открывая новые уровни допуска к измерениям.",
  },
];

interface CosmologyCodexViewProps {
  theme: ThemePreset;
  telemetry: NavigatorSyncTelemetry;
  onJumpToCircusGate: (gate: "funnel" | "carousel" | "bubbles") => void;
  onJumpToMindSync: (sub: "journal" | "add-log" | "breathing") => void;
}

export const CosmologyCodexView: React.FC<CosmologyCodexViewProps> = ({
  theme,
  telemetry,
  onJumpToCircusGate,
  onJumpToMindSync,
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>("node-4");
  const [selectedPillarId, setSelectedPillarId] = useState<string>("pillar-1");
  const [transitPulse, setTransitPulse] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const shockwaveRef = useRef<number>(0.85);

  const activeNode =
    LIMINAL_NODES.find((n) => n.id === selectedNodeId) || LIMINAL_NODES[3];

  const triggerKawooshShockwave = () => {
    shockwaveRef.current = 1.5;
    setTransitPulse((p) => p + 1);
    soundEngine.playArpeggio(3);
  };

  useEffect(() => {
    let animId = 0;
    let t = 0;
    const bgStars = Array.from({ length: 55 }, (_, i) => ({
      x: (i * 137.5) % 740,
      y: (i * 89.3) % 400,
      r: (i % 3) * 0.65 + 0.7,
      phase: i * 0.6,
    }));

    const render = () => {
      t += 0.022;
      shockwaveRef.current = Math.max(0, shockwaveRef.current * 0.96);
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          ctx.clearRect(0, 0, w, h);

          const axisNode = LIMINAL_NODES[3];
          const axX = axisNode.x * w;
          const axY = axisNode.y * h;

          // 0. Deep Obsidian Cosmic Nebula Backdrop
          const nebulaGrad = ctx.createRadialGradient(axX, axY, 8, axX, axY, w * 0.58);
          nebulaGrad.addColorStop(0, `${theme.secondaryAccent}38`);
          nebulaGrad.addColorStop(0.4, `${theme.primaryAccent}1E`);
          nebulaGrad.addColorStop(0.8, "#070916");
          nebulaGrad.addColorStop(1, "#04060E");
          ctx.fillStyle = nebulaGrad;
          ctx.fillRect(0, 0, w, h);

          // Twinkling Astral Dust
          for (const st of bgStars) {
            const alpha = 0.25 + 0.45 * Math.sin(t * 2 + st.phase);
            ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.beginPath();
            ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
            ctx.fill();
          }

          // 1. Background Obsidian Coordinate Grid & Perspective Horizon Rays
          ctx.strokeStyle = "rgba(148, 163, 184, 0.07)";
          ctx.lineWidth = 1;
          for (let gx = 40; gx < w; gx += 55) {
            ctx.beginPath();
            ctx.moveTo(gx, 0);
            ctx.lineTo(gx, h);
            ctx.stroke();
          }
          for (let gy = 30; gy < h; gy += 45) {
            ctx.beginPath();
            ctx.moveTo(0, gy);
            ctx.lineTo(w, gy);
            ctx.stroke();
          }

          // 1.5 Central Stargate Event Horizon Ring behind Node IV (Axis Mundi)
          ctx.save();
          ctx.globalCompositeOperation = "lighter";

          // Liquid Event Horizon Vortex Puddle
          const vortexR = 118 + shockwaveRef.current * 24;
          const vortexGrad = ctx.createRadialGradient(axX, axY, 4, axX, axY, vortexR);
          vortexGrad.addColorStop(0, "rgba(255,255,255,0.65)");
          vortexGrad.addColorStop(0.3, `${theme.secondaryAccent}55`);
          vortexGrad.addColorStop(0.65, `${theme.primaryAccent}28`);
          vortexGrad.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = vortexGrad;
          ctx.beginPath();
          ctx.arc(axX, axY, vortexR, 0, Math.PI * 2);
          ctx.fill();

          // Expanding Kawoosh Shockwave Ring when triggered
          if (shockwaveRef.current > 0.05) {
            const waveRadius = (1.55 - shockwaveRef.current) * 260 + 25;
            ctx.strokeStyle = `${theme.secondaryAccent}${Math.min(
              255,
              Math.round(shockwaveRef.current * 190)
            )
              .toString(16)
              .padStart(2, "0")}`;
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.arc(axX, axY, waveRadius, 0, Math.PI * 2);
            ctx.stroke();
          }

          for (let ring = 1; ring <= 3; ring++) {
            const rad = 42 * ring + Math.sin(t * 1.8 + ring) * 3.5;
            ctx.strokeStyle =
              ring === 1
                ? `${theme.primaryAccent}66`
                : ring === 2
                ? `${theme.secondaryAccent}55`
                : "rgba(255,255,255,0.16)";
            ctx.lineWidth = ring === 1 ? 2.6 : ring === 2 ? 1.8 : 1.4;
            ctx.beginPath();
            ctx.arc(axX, axY, rad, 0, Math.PI * 2);
            ctx.stroke();

            // 36 Stargate Glyphs + 9 Glowing Chevrons around outer ring
            if (ring === 3) {
              for (let g = 0; g < 36; g++) {
                const gAng = (g / 36) * Math.PI * 2 - t * 0.25;
                ctx.strokeStyle = "rgba(255,255,255,0.28)";
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(axX + Math.cos(gAng) * (rad - 3), axY + Math.sin(gAng) * (rad - 3));
                ctx.lineTo(axX + Math.cos(gAng) * (rad + 3), axY + Math.sin(gAng) * (rad + 3));
                ctx.stroke();
              }

              for (let c = 0; c < 9; c++) {
                const ang = (c / 9) * Math.PI * 2 + t * 0.32;
                const cx = axX + Math.cos(ang) * rad;
                const cy = axY + Math.sin(ang) * rad;
                ctx.fillStyle = c % 2 === 0 ? theme.starColor : theme.primaryAccent;
                ctx.beginPath();
                ctx.arc(cx, cy, 4.2, 0, Math.PI * 2);
                ctx.fill();
              }
            }
          }

          // 2. Draw Obsidian Graph Edges & Curved Wormhole Conduits
          for (const node of LIMINAL_NODES) {
            const x1 = node.x * w;
            const y1 = node.y * h;
            for (const targetId of node.connectedTo) {
              if (node.id < targetId) {
                const target = LIMINAL_NODES.find((n) => n.id === targetId);
                if (target) {
                  const x2 = target.x * w;
                  const y2 = target.y * h;
                  const isHighlighted =
                    node.id === selectedNodeId || target.id === selectedNodeId;

                  // Direct Synaptic Laser Edge
                  ctx.strokeStyle = isHighlighted
                    ? theme.secondaryAccent
                    : "rgba(148, 163, 184, 0.26)";
                  ctx.lineWidth = isHighlighted ? 2.8 : 1.3;
                  ctx.beginPath();
                  ctx.moveTo(x1, y1);
                  ctx.lineTo(x2, y2);
                  ctx.stroke();

                  // Curved Wormhole Arc for highlighted transits
                  if (isHighlighted) {
                    const midX = (x1 + x2) / 2;
                    const midY = (y1 + y2) / 2 - 26;
                    ctx.strokeStyle = `${theme.primaryAccent}77`;
                    ctx.lineWidth = 1.6;
                    ctx.beginPath();
                    ctx.moveTo(x1, y1);
                    ctx.quadraticCurveTo(midX, midY, x2, y2);
                    ctx.stroke();

                    // Dual Flowing Quantum Packets along highlighted transit edge
                    for (let pIdx = 0; pIdx < 2; pIdx++) {
                      const prog = (t * 0.62 + pIdx * 0.5) % 1;
                      const px = x1 + (x2 - x1) * prog;
                      const py = y1 + (y2 - y1) * prog;
                      ctx.fillStyle = pIdx === 0 ? "#FFFFFF" : theme.starColor;
                      ctx.beginPath();
                      ctx.arc(px, py, 4.2, 0, Math.PI * 2);
                      ctx.fill();
                    }
                  }
                }
              }
            }
          }
          ctx.restore();

          // 3. Draw Hexagonal Faceted Obsidian Nodes (Rooms / Vessels)
          for (const node of LIMINAL_NODES) {
            const nx = node.x * w;
            const ny = node.y * h;
            const isSelected = node.id === selectedNodeId;
            const isNeighbor = activeNode.connectedTo.includes(node.id);
            const r = isSelected ? 20 : isNeighbor ? 15 : 12;

            // Outer Volumetric Obsidian Aura
            const auraGrad = ctx.createRadialGradient(nx, ny, 2, nx, ny, r * 2.2);
            auraGrad.addColorStop(
              0,
              isSelected
                ? `${theme.primaryAccent}99`
                : isNeighbor
                ? `${theme.secondaryAccent}66`
                : "rgba(99, 102, 241, 0.25)"
            );
            auraGrad.addColorStop(1, "rgba(0,0,0,0)");
            ctx.fillStyle = auraGrad;
            ctx.beginPath();
            ctx.arc(nx, ny, r * 2.2, 0, Math.PI * 2);
            ctx.fill();

            // Hexagonal Obsidian Crystal Vessel
            ctx.fillStyle = "#080A14";
            ctx.strokeStyle = isSelected
              ? "#FFFFFF"
              : isNeighbor
              ? theme.secondaryAccent
              : "rgba(255,255,255,0.5)";
            ctx.lineWidth = isSelected ? 3 : 2;
            ctx.beginPath();
            for (let side = 0; side < 6; side++) {
              const hAng = (side / 6) * Math.PI * 2 + (isSelected ? t * 0.8 : 0);
              const hx = nx + Math.cos(hAng) * r;
              const hy = ny + Math.sin(hAng) * r;
              if (side === 0) ctx.moveTo(hx, hy);
              else ctx.lineTo(hx, hy);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Inner Glowing Core
            ctx.fillStyle = isSelected ? theme.primaryAccent : theme.starColor;
            ctx.beginPath();
            ctx.arc(nx, ny, isSelected ? 6.5 : 3.8, 0, Math.PI * 2);
            ctx.fill();

            // Label & Frequency Subtitle
            ctx.font = isSelected
              ? "bold 12px 'Plus Jakarta Sans', sans-serif"
              : "600 11px 'Plus Jakarta Sans', sans-serif";
            ctx.fillStyle = isSelected ? "#FFFFFF" : "rgba(226, 232, 240, 0.9)";
            ctx.textAlign = "center";
            ctx.fillText(node.title, nx, ny - r - 10);
          }
        }
      }
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [selectedNodeId, theme, activeNode]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.currentTarget.width / rect.width;
    const sy = e.currentTarget.height / rect.height;
    const cx = (e.clientX - rect.left) * sx;
    const cy = (e.clientY - rect.top) * sy;

    shockwaveRef.current = 1.25;
    for (const node of LIMINAL_NODES) {
      const nx = node.x * e.currentTarget.width;
      const ny = node.y * e.currentTarget.height;
      if (Math.hypot(cx - nx, cy - ny) < 38) {
        setSelectedNodeId(node.id);
        setTransitPulse((p) => p + 1);
        soundEngine.playArpeggio(LIMINAL_NODES.indexOf(node));
        break;
      }
    }
  };

  return (
    <div className="space-y-8" data-testid="cosmology-codex-root">
      {/* 1. HERO: Unified Cosmology & Navigator Telemetry Bridge */}
      <section
        className="rounded-3xl border border-white/15 p-6 md:p-8 relative overflow-hidden"
        style={{
          background: `linear-gradient(135deg, #070812 0%, ${theme.bgGradient[1]} 55%, ${theme.bgGradient[2]} 100%)`,
        }}
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest mb-2" style={{ color: theme.secondaryAccent }}>
                Кодекс Навигатора · Осевое 4-е Измерение · Псевдо-Обсидиан × Stargate
              </div>
              <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-3">
                Архитектура Междумирья: Астральная Дорога и Ментальное Ядро Космонавта
              </h1>
              <p className="text-sm md:text-base text-slate-300 leading-relaxed">
                Единая теория и методология двух частей приложения: <strong>Часть 1 (Surreal Circus)</strong> — это
                внешний 4D-астрал, псевдо-обсидиановый мост и Звёздные Врата, сквозь которые летит Аватар
                в медитации-сновидении. <strong>Часть 2 (MindSync)</strong> — это внутренний ментальный контур
                самого Космонавта, где КПТ-рефрейминг и дыхание 4-4-4-4 стабилизируют переход из одной{" "}
                <em>Ёмкости (комнаты-узла)</em> в другую.
              </p>
            </div>

            <div className="mt-6 pt-5 border-t border-white/10 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onJumpToCircusGate(activeNode.recommendedGate)}
                data-testid="codex-launch-astral-gate"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white transition-transform active:scale-95 cursor-pointer"
                style={{ backgroundColor: theme.primaryAccent }}
              >
                <Orbit className="w-4 h-4" />
                <span>Открыть Внешний Переход (Часть 1 · Астрал 4D)</span>
              </button>

              <button
                type="button"
                onClick={() => onJumpToMindSync("add-log")}
                data-testid="codex-launch-mental-core"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-xs font-bold text-white transition-colors cursor-pointer"
              >
                <Brain className="w-4 h-4" />
                <span>Калибровать Ментал Космонавта (Часть 2 · КПТ)</span>
              </button>
            </div>
          </div>

          {/* Live Astronaut-Avatar Sync Telemetry Panel */}
          <div className="lg:col-span-5 rounded-2xl border border-white/15 bg-black/45 p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-300">
                  Телеметрия Аватара-Навигатора
                </span>
                <span className="text-xs font-mono tabular-nums text-emerald-400">
                  Синхронизация: {telemetry.coherenceIndex}%
                </span>
              </div>

              <div className="text-lg font-bold text-white mb-1">{telemetry.dimensionalRank}</div>
              <div className="text-xs text-slate-300 mb-5">{telemetry.vesselStatus}</div>

              <div className="space-y-3.5">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">1. Внешний Астральный Резонанс (4D-Мост)</span>
                    <span className="font-mono font-bold text-pink-400 tabular-nums">
                      {telemetry.astralResonance}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${telemetry.astralResonance}%`,
                        backgroundColor: theme.primaryAccent,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">2. Внутренняя Ментальная Стабильность (КПТ + Прана)</span>
                    <span className="font-mono font-bold text-cyan-300 tabular-nums">
                      {telemetry.mentalStability}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${telemetry.mentalStability}%`,
                        backgroundColor: theme.secondaryAccent,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 text-xs text-slate-400 flex items-center justify-between">
              <span>Статус шлюза между ёмкостями:</span>
              <span className="font-mono text-white">Шевроны 1–7 активны</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. INTERACTIVE OBSIDIAN × STARGATE 4D NODE-ROOM-TRANSIT GRAPH */}
      <section className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-2xl font-extrabold text-white">
              Псевдо-Обсидиановый Граф Узлов-Комнат и Лиминальных Переходов
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Нажмите на любой из 7 узлов на карте (или выберите ниже), чтобы исследовать, что находится внутри
              Ёмкости, снаружи Космонавта (Часть 1), внутри его Ментала (Часть 2) и в переходе между лабиринтами
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="text-xs font-mono text-indigo-300 tabular-nums">
              Активный узел: {activeNode.code} · Импульсов перехода: {transitPulse}
            </div>
            <button
              type="button"
              onClick={triggerKawooshShockwave}
              data-testid="codex-kawoosh-button"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Квантовый Всплеск Врат (Kawoosh)</span>
            </button>
          </div>
        </div>

        {/* Node Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4">
          {LIMINAL_NODES.map((node, idx) => {
            const selected = node.id === selectedNodeId;
            return (
              <button
                key={node.id}
                type="button"
                onClick={() => {
                  setSelectedNodeId(node.id);
                  setTransitPulse((p) => p + 1);
                  soundEngine.playNoteIndex(idx, 260);
                }}
                data-testid={`select-node-${node.id}`}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selected
                    ? "bg-indigo-500/25 border-indigo-400 text-white"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {idx + 1}. {node.title}
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Interactive Obsidian-Stargate Graph Canvas */}
          <div className="lg:col-span-7 rounded-2xl border border-slate-800 bg-[#060811] overflow-hidden flex flex-col justify-between">
            <canvas
              ref={canvasRef}
              width={740}
              height={400}
              data-testid="obsidian-stargate-canvas"
              onClick={handleCanvasClick}
              className="w-full h-[320px] md:h-[380px] block cursor-pointer"
            />
            <div className="px-4 py-3 bg-slate-950/90 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>
                Кольцо в центре — Осевые Звёздные Врата (Axis Mundi · 9 шевронов) · Линии — межлабиринтные переходы
              </span>
              <span className="font-mono text-slate-300">{activeNode.vesselCapacity}</span>
            </div>
          </div>

          {/* Selected Node Deep-Dive Inspector */}
          <div
            className="lg:col-span-5 rounded-2xl border border-slate-800 bg-slate-950/80 p-6 flex flex-col justify-between"
            data-testid="selected-node-inspector"
          >
            <div className="space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <div className="text-xs font-mono text-indigo-400">{activeNode.code} · {activeNode.vesselCapacity}</div>
                <h3 className="text-xl font-bold text-white mt-0.5">{activeNode.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{activeNode.archetype}</p>
              </div>

              <div>
                <div className="text-xs font-bold text-pink-400 mb-1 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5" />
                  <span>Часть 1 · Внешний Астрал (Снаружи Космонавта):</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {activeNode.externalAstralManifestation}
                </p>
              </div>

              <div>
                <div className="text-xs font-bold text-cyan-300 mb-1 flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5" />
                  <span>Часть 2 · Внутренний Ментал (Внутри Космонавта):</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {activeNode.internalMentalManifestation}
                </p>
              </div>

              <div>
                <div className="text-xs font-bold text-amber-300 mb-1 flex items-center gap-1.5">
                  <GitBranch className="w-3.5 h-3.5" />
                  <span>Межлабиринтный переход (Между Ёмкостями):</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">{activeNode.liminalBridge}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-slate-800/80">
                <div className="rounded-xl bg-slate-900/90 border border-slate-800 p-3">
                  <div className="text-[11px] font-bold text-purple-300 mb-1">Средневековый ключ</div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{activeNode.medievalParallel}</p>
                </div>
                <div className="rounded-xl bg-slate-900/90 border border-slate-800 p-3">
                  <div className="text-[11px] font-bold text-emerald-300 mb-1">Технологический / Sci-Fi ключ</div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{activeNode.scifiTechParallel}</p>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-800 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5">
              <button
                type="button"
                onClick={() => onJumpToCircusGate(activeNode.recommendedGate)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Play className="w-3.5 h-3.5 shrink-0" />
                <span>Туннель 4D (Часть 1)</span>
              </button>
              <button
                type="button"
                onClick={() => onJumpToMindSync("breathing")}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                <span>Стабилизация (Часть 2)</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. SIX THEORETICAL & METHODOLOGICAL LENSES (Medieval, Sci-Fi, Obsidian, Astral, Mental, Technological) */}
      <section className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8">
        <div className="mb-6">
          <h2 className="text-2xl font-extrabold text-white">
            Фундаментальная Теория и Методология: 6 Измерений Синтеза
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Детальная проработка концепции: от средневековой герметики и алхимии до квантовой топологии Stargate,
            графов Obsidian и нейро-когнитивной терапии Космонавта
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {THEORETICAL_PILLARS.map((pillar) => {
            const isSelected = pillar.id === selectedPillarId;
            return (
              <button
                key={pillar.id}
                type="button"
                onClick={() => {
                  setSelectedPillarId(pillar.id);
                  soundEngine.playNoteIndex(THEORETICAL_PILLARS.indexOf(pillar), 220);
                }}
                data-testid={`pillar-card-${pillar.id}`}
                className={`text-left rounded-2xl border p-5 transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? "border-indigo-400 bg-indigo-950/35"
                    : "border-slate-800 bg-slate-950/60 hover:border-slate-700"
                }`}
              >
                <div>
                  <div className="text-xs font-mono text-indigo-300 mb-1.5">{pillar.category}</div>
                  <h3 className="text-base font-bold text-white mb-1.5">{pillar.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                    {pillar.summary}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-indigo-300 font-semibold">
                  <span>Развернуть методологию</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Expanded Active Pillar Detail Box */}
        {(() => {
          const activePillar =
            THEORETICAL_PILLARS.find((p) => p.id === selectedPillarId) || THEORETICAL_PILLARS[0];
          return (
            <div
              className="rounded-2xl border border-indigo-500/40 bg-slate-950/90 p-6 md:p-7"
              data-testid="active-pillar-detail"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-800">
                <div>
                  <div className="text-xs font-mono text-indigo-400">{activePillar.category}</div>
                  <h3 className="text-xl font-extrabold text-white mt-0.5">{activePillar.title}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{activePillar.subtitle}</p>
                </div>
                <BookOpen className="w-6 h-6 text-indigo-400 shrink-0" />
              </div>

              <p className="text-sm text-slate-200 leading-relaxed mb-6">{activePillar.summary}</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
                  <div className="text-xs font-bold text-pink-400 mb-1.5 flex items-center gap-1.5">
                    <Eye className="w-4 h-4" />
                    <span>Воплощение в 1-й части (Астрал / Внешнее)</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{activePillar.part1Role}</p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
                  <div className="text-xs font-bold text-cyan-300 mb-1.5 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4" />
                    <span>Воплощение во 2-й части (Ментал / Внутреннее)</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{activePillar.part2Role}</p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
                  <div className="text-xs font-bold text-amber-300 mb-1.5 flex items-center gap-1.5">
                    <Flame className="w-4 h-4" />
                    <span>Механика перехода между Ёмкостями</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {activePillar.betweenLocationsMechanics}
                  </p>
                </div>
              </div>
            </div>
          );
        })()}
      </section>

      {/* 4. COMPARATIVE ARCHITECTURE MATRIX: MEDIEVAL × MODERN × SCI-FI × GAMEPLAY */}
      <section className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 md:p-8">
        <div className="mb-5">
          <h2 className="text-xl font-extrabold text-white">
            Матрица Соответствий: Узлы, Ёмкости и Межпространственные Переходы
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Как каждый элемент вашей идеи работает одновременно в 4 культурно-технологических пластах
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-3 px-4 font-bold">Элемент Системы</th>
                <th className="py-3 px-4 font-bold">Средневековая Герметика</th>
                <th className="py-3 px-4 font-bold">Псевдо-Обсидиан &amp; ИТ</th>
                <th className="py-3 px-4 font-bold">Фантастика (Stargate 4D)</th>
                <th className="py-3 px-4 font-bold">Психология Космонавта</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-200">
              <tr>
                <td className="py-3.5 px-4 font-bold text-white">Узел / Комната (Локация)</td>
                <td className="py-3.5 px-4">Чертог в «Театре Памяти» (Ars Memoria)</td>
                <td className="py-3.5 px-4">Вершина графа (Markdown-узел в Obsidian)</td>
                <td className="py-3.5 px-4">Планетарная база со Звёздными Вратами</td>
                <td className="py-3.5 px-4">Устойчивое состояние сознания («Ёмкость»)</td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-bold text-white">Часть 1 (Дорога и Карусель)</td>
                <td className="py-3.5 px-4">Музыка сфер и Армиллярная астролябия</td>
                <td className="py-3.5 px-4">Активные гиперссылки и 3D-рендер связей</td>
                <td className="py-3.5 px-4">Полёт сквозь червоточину и горизонт событий</td>
                <td className="py-3.5 px-4">Внешний фокус внимания в осознанном сне</td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-bold text-white">Часть 2 (MindSync КПТ)</td>
                <td className="py-3.5 px-4">Vas Hermeticum (трансмутация свинца в золото)</td>
                <td className="py-3.5 px-4">Дебаггинг когнитивных ошибок с ИИ Gemini</td>
                <td className="py-3.5 px-4">Стабилизация жизнеобеспечения скафандра</td>
                <td className="py-3.5 px-4">Рефрейминг тревоги и дыхание 4-4-4-4</td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-bold text-white">Пространство Между Лабиринтами</td>
                <td className="py-3.5 px-4">Лиминальный порог и Ось Мира (Axis Mundi)</td>
                <td className="py-3.5 px-4">Буфер обмена состояниями (State Transition)</td>
                <td className="py-3.5 px-4">4-е осевое измерение (прошлое ║ будущее)</td>
                <td className="py-3.5 px-4">Момент инсайта и перетекания энергии</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
