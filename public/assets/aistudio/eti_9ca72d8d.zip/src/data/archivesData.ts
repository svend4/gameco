export interface ArchiveFileItem {
  path: string;
  language: string;
  summary: string;
  code: string;
}

export interface ProjectArchiveInfo {
  id: "surreal-circus" | "mindsync";
  name: string;
  ruTitle: string;
  packageId: string;
  sdkInfo: string;
  zipUrl: string;
  zipFilename: string;
  description: string;
  highlights: string[];
  files: ArchiveFileItem[];
}

export const ATTACHED_ARCHIVES: ProjectArchiveInfo[] = [
  {
    id: "surreal-circus",
    name: "Surreal Circus",
    ruTitle: "Сюрреалистический Цирк Снов",
    packageId: "com.aistudio.surrealcircus.qxlmpt",
    sdkInfo: "Kotlin 2.2.10 · Jetpack Compose · Room DB · AudioTrack PCM Synth · Target SDK 36",
    zipUrl: "/assets/aistudio/surreal-circus_67a2ed2c.zip",
    zipFilename: "surreal-circus_67a2ed2c.zip",
    description:
      "Ненасильственный сюрреалистический 3D-аттракцион на Jetpack Compose Canvas, где каждое действие игрока рождает пентатоническую музыкальную гармонию в реальном времени.",
    highlights: [
      "3 интерактивных 3D-аттракциона на матрицах перспективной проекции: Ловец Сфер, Карусель Звезд, Сферы Эфира",
      "Процедурный синтезатор SurrealSoundGenerator на базе Android AudioTrack (PCM 16-bit, пентатоника без диссонанса)",
      "4 динамических измерения палитр: Космические сумерки, Неоновый аттракцион, Изумрудный сон, Глубокий индиго",
      "Хранение рекордов и цепочек созвучий в локальной БД Room (HarmonyRecord / HarmonyDao)",
    ],
    files: [
      {
        path: "GDD.md",
        language: "markdown",
        summary: "Документ геймдизайна (GDD): концепция 3D-перспективы и музыкальной синестезии",
        code: `# Документ Геймдизайна (GDD): Сюрреалистический Цирк (Surreal Circus)
Версия: 1.0
Платформа: Android (Jetpack Compose, Kotlin)

## 1. Концепция
Сюрреалистическое 3D-пространство цирковых аттракционов без насилия и проигрыша.

## 2. Ключевые столпы (Core Pillars)
* Физика Гармонии: отсутствие экрана Game Over, накопление созвучий.
* Музыкальная Синестезия: каждое касание генерирует чистую ноту пентатоники.
* 3D-перспектива на 2D-холсте: математическая проекция (X, Y, Z) при 60 FPS.

## 3. Аттракционы
1. Ловцы Блуждающих Сфер (Gravity Funnel)
2. Карусель Созвездий (Celestial Carousel)
3. Эфирные Пузыри (Ethereal Bubbles)`,
      },
      {
        path: "app/src/main/java/com/example/audio/SurrealSoundGenerator.kt",
        language: "kotlin",
        summary: "Процедурный PCM-синтезатор пентатонических аккордов с мягкой огибающей Attack/Decay",
        code: `class SurrealSoundGenerator {
    private val sampleRate = 22050
    val pentatonicNotes = floatArrayOf(
        261.63f, 293.66f, 329.63f, 392.00f, 440.00f,
        523.25f, 587.33f, 659.25f, 783.99f, 880.00f
    )

    fun playNoteIndex(index: Int, durationMs: Long = 350L) {
        val safeIndex = index.coerceIn(0, pentatonicNotes.lastIndex)
        playTone(pentatonicNotes[safeIndex], durationMs)
    }
}`,
      },
      {
        path: "app/src/main/java/com/example/ui/screens/AttractionGravityFunnel.kt",
        language: "kotlin",
        summary: "3D-аттракцион «Ловцы Блуждающих Сфер» с перспективной трассой и магнитным порталом",
        code: `data class DreamSphere(
    var id: Long,
    var x: Float, // -250..250
    var y: Float,
    var z: Float, // 1000 -> 0
    var radius: Float = 26f,
    val color: Color,
    val noteIndex: Int,
    val speed: Float
)
// Perspective projection: scale = focalLength / (focalLength + sphere.z)`,
      },
      {
        path: "app/src/main/java/com/example/ui/screens/AttractionCelestialCarousel.kt",
        language: "kotlin",
        summary: "3D-аттракцион «Карусель Созвездий» с вращением по осям X/Y и лазерным слиянием созвездий",
        code: `fun updateRotations(w: Float, h: Float) {
    val cosY = cos(angleY); val sinY = sin(angleY)
    val cosX = cos(angleX); val sinX = sin(angleX)
    carouselStars.forEach { star ->
        val rx1 = star.baseX * cosY - star.baseZ * sinY
        val rz1 = star.baseX * sinY + star.baseZ * cosY
        star.rotatedX = rx1
        star.rotatedY = star.baseY * cosX - rz1 * sinX
        star.rotatedZ = star.baseY * sinX + rz1 * cosX
    }
}`,
      },
    ],
  },
  {
    id: "mindsync",
    name: "MindSync",
    ruTitle: "MindSync: КПТ-Дневник и Осознанность",
    packageId: "com.aistudio.mindsync.cbtvqx",
    sdkInfo: "Kotlin 2.2.10 · Jetpack Compose · Room DB · Gemini CBT Reflection · Target SDK 35",
    zipUrl: "/assets/aistudio/mindsync_86ed3d0a.zip",
    zipFilename: "mindsync_86ed3d0a.zip",
    description:
      "Интеллектуальный дневник когнитивно-поведенческой терапии (КПТ) и трекер эмоционального состояния для снижения тревожности, рефрейминга негативных мыслей и дыхательных практик.",
    highlights: [
      "3-шаговый мастер КПТ-записи: выбор эмоции, фиксация тревожной мысли + когнитивных искажений, рациональный ответ и оценка интенсивности До/После",
      "Глубокая терапевтическая AI-рефлексия от Gemini на русском языке с эмпатией и разбором искажений",
      "Bento-панель «Инсайты и Практики»: 4 этапа пути осознанности, статистика эмоций и трекер прогресса",
      "Тренажер «Квадратное дыхание (4-4-4-4)» с пульсирующей визуализацией фаз и автосохранением сессий",
    ],
    files: [
      {
        path: "app/src/main/java/com/example/data/Models.kt",
        language: "kotlin",
        summary: "Сущности Room Database: JournalEntry (запись КПТ) и BreathingSession (сессия дыхания)",
        code: `@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val mood: String,
    val originalThought: String,
    val distortions: String,
    val rationalThought: String,
    val intensityBefore: Int,
    val intensityAfter: Int,
    val geminiFeedback: String?,
    val timestamp: Long = System.currentTimeMillis()
)`,
      },
      {
        path: "app/src/main/java/com/example/data/GeminiService.kt",
        language: "kotlin",
        summary: "Сервис анализа тревожных мыслей и когнитивных искажений с помощью Gemini",
        code: `suspend fun analyzeCBTThought(
    mood: String,
    originalThought: String,
    distortions: List<String>,
    rationalThought: String
): String
// System instruction: Validate feelings with empathy, analyze cognitive distortions,
// support reframed rational thought, and suggest a mindfulness step in Russian.`,
      },
      {
        path: "app/src/main/java/com/example/ui/Screens.kt",
        language: "kotlin",
        summary: "Экраны DashboardScreen (Bento Grid), CbtLogScreen (3 шага), LogDetailScreen и BreathingScreen (4-4-4-4)",
        code: `val Moods = listOf(
    MoodOption("Peaceful", "Спокойствие", "🧘", Color(0xFF81C784)),
    MoodOption("Anxious", "Тревога", "😰", Color(0xFFFFB74D)),
    MoodOption("Sad", "Грусть", "😢", Color(0xFF64B5F6)),
    MoodOption("Happy", "Радость", "😊", Color(0xFFFFF176)),
    MoodOption("Angry", "Гнев", "😡", Color(0xFFE57373)),
    MoodOption("Tired", "Усталость", "🥱", Color(0xFFB0BEC5))
)`,
      },
    ],
  },
];
