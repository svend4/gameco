export interface ThemePreset {
  index: number;
  name: string;
  enName: string;
  stargateTitle: string;
  bgGradient: [string, string, string];
  bgSolid: string;
  primaryAccent: string;
  secondaryAccent: string;
  surfaceColor: string;
  starColor: string;
  bubbleColors: string[];
  description: string;
}

export const SURREAL_THEMES: ThemePreset[] = [
  {
    index: 0,
    name: "Обсидиановый Горизонт",
    enName: "Obsidian Stargate",
    stargateTitle: "Врата I · Осевой Астрал",
    bgGradient: ["#07060E", "#110D22", "#1F1037"],
    bgSolid: "#0D0A1A",
    primaryAccent: "#FF2A85",
    secondaryAccent: "#00F0FF",
    surfaceColor: "rgba(91, 39, 162, 0.22)",
    starColor: "#FFD700",
    bubbleColors: ["#FF2A85", "#00F0FF", "#9D4EDD", "#3A86C8"],
    description: "Вулканическое обсидиановое стекло, шевроны Звёздных Врат и фиолетовые токи 4-го измерения.",
  },
  {
    index: 1,
    name: "Гелио-Манеж Хроноса",
    enName: "Chronos Event Horizon",
    stargateTitle: "Врата II · Сдвиг Времён",
    bgGradient: ["#160514", "#28081B", "#421019"],
    bgSolid: "#28081B",
    primaryAccent: "#FF6B00",
    secondaryAccent: "#39FF14",
    surfaceColor: "rgba(126, 25, 42, 0.24)",
    starColor: "#FFA500",
    bubbleColors: ["#FF6B00", "#39FF14", "#FFD700", "#FF007F"],
    description: "Плазменное кольцо червоточины, где прошлое и будущее текут по параллельным струнам.",
  },
  {
    index: 2,
    name: "Герметический Изумруд",
    enName: "Emerald Tabula Smaragdina",
    stargateTitle: "Врата III · Изумрудная Скрижаль",
    bgGradient: ["#041812", "#082919", "#0F3B23"],
    bgSolid: "#082919",
    primaryAccent: "#00FFCC",
    secondaryAccent: "#FFE347",
    surfaceColor: "rgba(26, 92, 58, 0.24)",
    starColor: "#FFFF99",
    bubbleColors: ["#00FFCC", "#FFE347", "#48CAE4", "#80FFDB"],
    description: "Средневековая алхимия «Что наверху, то и внизу» — мост между внешним космосом и душой.",
  },
  {
    index: 3,
    name: "Астральный Навигатор",
    enName: "Astral Indigo Tesseract",
    stargateTitle: "Врата IV · Ось Тессеракта",
    bgGradient: ["#070B1C", "#0D152E", "#172542"],
    bgSolid: "#0D152E",
    primaryAccent: "#8B5CF6",
    secondaryAccent: "#00BFFF",
    surfaceColor: "rgba(44, 64, 117, 0.25)",
    starColor: "#E2E2E2",
    bubbleColors: ["#8B5CF6", "#00BFFF", "#B5179E", "#4CC9F0"],
    description: "Серебряный шнур сновидения, соединяющий скафандр Космонавта с многомерным гиперкубом.",
  },
];

export const PENTATONIC_NOTES: readonly number[] = [
  261.63, // C4
  293.66, // D4
  329.63, // E4
  392.0,  // G4
  440.0,  // A4
  523.25, // C5
  587.33, // D5
  659.25, // E5
  783.99, // G5
  880.0,  // A5
];

export function getThemePreset(index: number): ThemePreset {
  const safeIdx = ((index % SURREAL_THEMES.length) + SURREAL_THEMES.length) % SURREAL_THEMES.length;
  return SURREAL_THEMES[safeIdx];
}

export function getPentatonicFrequency(noteIndex: number): number {
  const clamped = Math.max(0, Math.min(PENTATONIC_NOTES.length - 1, Math.floor(noteIndex)));
  return PENTATONIC_NOTES[clamped];
}

export interface HarmonyRecord {
  id: string;
  attractionName: "Ловец Сфер" | "Карусель Звезд" | "Сферы Эфира" | string;
  score: number;
  dateString: string;
  noteChainLength: number;
  themePalette: string;
}

export function getBestScoreForAttraction(
  records: HarmonyRecord[],
  attractionName: string,
  liveScore = 0
): number {
  const maxStored = records
    .filter((r) => r.attractionName === attractionName)
    .reduce((max, r) => (r.score > max ? r.score : max), 0);
  return Math.max(maxStored, liveScore);
}

export function calculateFunnelHit(
  currentScore: number,
  currentStreak: number,
  maxStreak: number,
  isHit: boolean
): { score: number; streak: number; maxStreak: number } {
  if (!isHit) {
    return {
      score: currentScore,
      streak: 0,
      maxStreak,
    };
  }
  const nextScore = currentScore + 10 + currentStreak;
  const nextStreak = currentStreak + 1;
  return {
    score: nextScore,
    streak: nextStreak,
    maxStreak: Math.max(maxStreak, nextStreak),
  };
}

export function calculateCarouselFusionScore(
  currentScore: number,
  currentScaleCount: number,
  matchedCount: number
): { score: number; scaleCount: number } {
  if (matchedCount < 3) {
    return { score: currentScore, scaleCount: currentScaleCount };
  }
  return {
    score: currentScore + matchedCount * 25,
    scaleCount: currentScaleCount + 1,
  };
}

export function project3DPoint(
  x: number,
  y: number,
  z: number,
  centerX: number,
  centerY: number,
  focalLength: number,
  cameraDistance = 0
): { px: number; py: number; scale: number } {
  const denom = Math.max(10, focalLength + cameraDistance + z);
  const scale = focalLength / denom;
  return {
    px: centerX + x * scale,
    py: centerY + y * scale,
    scale,
  };
}

export function rotate3DPoint(
  x: number,
  y: number,
  z: number,
  angleX: number,
  angleY: number
): { rx: number; ry: number; rz: number } {
  const cosY = Math.cos(angleY);
  const sinY = Math.sin(angleY);
  const cosX = Math.cos(angleX);
  const sinX = Math.sin(angleX);

  const rx1 = x * cosY - z * sinY;
  const rz1 = x * sinY + z * cosY;

  const ry2 = y * cosX - rz1 * sinX;
  const rz2 = y * sinX + rz1 * cosX;

  return { rx: rx1, ry: ry2, rz: rz2 };
}

export function mergeBubbleRadii(r1: number, r2: number): number {
  return Math.min(130, r1 + r2 * 0.5);
}

// ==========================================
// MindSync CBT & Mindfulness Domain Logic
// ==========================================

export interface MoodOption {
  name: string;
  ruName: string;
  emoji: string;
  color: string;
}

export const MOOD_OPTIONS: MoodOption[] = [
  { name: "Peaceful", ruName: "Спокойствие", emoji: "🧘", color: "#81C784" },
  { name: "Anxious", ruName: "Тревога", emoji: "😰", color: "#FFB74D" },
  { name: "Sad", ruName: "Грусть", emoji: "😢", color: "#64B5F6" },
  { name: "Happy", ruName: "Радость", emoji: "😊", color: "#FFF176" },
  { name: "Angry", ruName: "Гнев", emoji: "😡", color: "#E57373" },
  { name: "Tired", ruName: "Усталость", emoji: "🥱", color: "#B0BEC5" },
];

export interface DistortionOption {
  title: string;
  ruTitle: string;
  description: string;
}

export const DISTORTION_OPTIONS: DistortionOption[] = [
  {
    title: "Catastrophizing",
    ruTitle: "Катастрофизация",
    description: "Ожидание худшего сценария в любой ситуации.",
  },
  {
    title: "All-or-Nothing",
    ruTitle: "Черно-белое мышление",
    description: "Видение мира только в категориях крайностей.",
  },
  {
    title: "Overgeneralization",
    ruTitle: "Сверхобобщение",
    description: "Вывод на основе одного негативного случая.",
  },
  {
    title: "Mind Reading",
    ruTitle: "Чтение мыслей",
    description: "Уверенность в том, что знаете мотивы и мысли других.",
  },
  {
    title: "Emotional Reasoning",
    ruTitle: "Эмоциональное обоснование",
    description: "Превращение своих сиюминутных эмоций в истину.",
  },
  {
    title: "Personalization",
    ruTitle: "Персонализация",
    description: "Принятие чужих реакций на свой счет.",
  },
];

export interface JournalEntry {
  id: string;
  mood: string;
  originalThought: string;
  distortions: string; // comma-separated titles
  rationalThought: string;
  intensityBefore: number;
  intensityAfter: number;
  geminiFeedback: string | null;
  timestamp: number;
}

export interface BreathingSession {
  id: string;
  durationSeconds: number;
  timestamp: number;
}

export interface CbtRoadmapStage {
  phaseLabel: string;
  phaseTitle: string;
  progressPercent: number;
}

export function calculateCbtRoadmapStage(entriesCount: number): CbtRoadmapStage {
  if (entriesCount <= 2) {
    return {
      phaseLabel: "Этап 1/4",
      phaseTitle: "Начало пути: стабилизация ментального скафандра",
      progressPercent: 35,
    };
  }
  if (entriesCount <= 5) {
    return {
      phaseLabel: "Этап 2/4",
      phaseTitle: "Осознание гравитационных аномалий и искажений ума",
      progressPercent: 60,
    };
  }
  if (entriesCount <= 9) {
    return {
      phaseLabel: "Этап 3/4",
      phaseTitle: "Калибровка внутренней Ёмкости перед прыжком в 4D",
      progressPercent: 80,
    };
  }
  return {
    phaseLabel: "Этап 4/4",
    phaseTitle: "Мастер-Навигатор: полный резонанс Астрала и Ментала",
    progressPercent: 100,
  };
}

export interface MoodDistributionItem {
  mood: string;
  ruName: string;
  emoji: string;
  color: string;
  count: number;
  percentage: number;
}

export function calculateMoodDistribution(entries: JournalEntry[]): MoodDistributionItem[] {
  if (entries.length === 0) return [];
  const counts = new Map<string, number>();
  for (const entry of entries) {
    counts.set(entry.mood, (counts.get(entry.mood) || 0) + 1);
  }
  const result: MoodDistributionItem[] = [];
  for (const [mood, count] of counts.entries()) {
    const cfg = MOOD_OPTIONS.find((m) => m.name === mood);
    result.push({
      mood,
      ruName: cfg?.ruName || mood,
      emoji: cfg?.emoji || "🧠",
      color: cfg?.color || "#8B5CF6",
      count,
      percentage: Math.round((count / entries.length) * 100),
    });
  }
  return result.sort((a, b) => b.count - a.count);
}

export function formatDurationRu(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${mins} м ${secs} с`;
}

export interface BreathStepState {
  breathPhase: 0 | 1 | 2 | 3;
  phaseTimer: number;
  cycleText: string;
  breathColor: string;
}

export function getBreathPhaseInfo(phase: 0 | 1 | 2 | 3): {
  cycleText: string;
  breathColor: string;
} {
  switch (phase) {
    case 0:
      return { cycleText: "Вдох...", breathColor: "#4DB6AC" };
    case 1:
      return { cycleText: "Задержка...", breathColor: "#90A4AE" };
    case 2:
      return { cycleText: "Выдох...", breathColor: "#64B5F6" };
    default:
      return { cycleText: "Задержка...", breathColor: "#9575CD" };
  }
}

export function advanceBoxBreathingTimer(
  breathPhase: 0 | 1 | 2 | 3,
  phaseTimer: number
): BreathStepState {
  if (phaseTimer > 1) {
    const nextTimer = phaseTimer - 1;
    return {
      breathPhase,
      phaseTimer: nextTimer,
      ...getBreathPhaseInfo(breathPhase),
    };
  }
  const nextPhase = ((breathPhase + 1) % 4) as 0 | 1 | 2 | 3;
  return {
    breathPhase: nextPhase,
    phaseTimer: 4,
    ...getBreathPhaseInfo(nextPhase),
  };
}

// ============================================================================
// COSMOLOGY & METHODOLOGY: ASTRAL (PART 1) <-> MENTAL (PART 2) TRANSIT ENGINE
// ============================================================================

export interface NavigatorSyncTelemetry {
  astralResonance: number; // 0..100 from Part 1 Harmony Records
  mentalStability: number; // 0..100 from Part 2 CBT & Breathing
  coherenceIndex: number;  // 0..100 combined Stargate lock
  vesselStatus: string;
  dimensionalRank: string;
}

export function calculateNavigatorCoherence(
  records: HarmonyRecord[],
  entries: JournalEntry[],
  breathingSessions: BreathingSession[]
): NavigatorSyncTelemetry {
  const totalHarmony = records.reduce((sum, r) => sum + r.score, 0);
  const astralResonance = Math.min(100, Math.round(25 + totalHarmony / 12));

  const totalBreathingSec = breathingSessions.reduce((sum, s) => sum + s.durationSeconds, 0);
  const avgRelief =
    entries.length > 0
      ? entries.reduce((sum, e) => sum + Math.max(0, e.intensityBefore - e.intensityAfter), 0) /
        entries.length
      : 3;

  const mentalStability = Math.min(
    100,
    Math.round(30 + entries.length * 10 + avgRelief * 5 + totalBreathingSec / 15)
  );

  const coherenceIndex = Math.min(100, Math.round(astralResonance * 0.5 + mentalStability * 0.5));

  let vesselStatus = "Первичная калибровка шлюза";
  let dimensionalRank = "Странник Порога (3D → 4D)";

  if (coherenceIndex >= 85) {
    vesselStatus = "Сверхпроводимость Звёздных Врат (Обсидиановый Резонанс)";
    dimensionalRank = "Архитектор Осевого Астрала (4D-Навигатор)";
  } else if (coherenceIndex >= 65) {
    vesselStatus = "Устойчивый мост между Ёмкостями сознания";
    dimensionalRank = "Навигатор Сновидческих Узлов";
  } else if (coherenceIndex >= 45) {
    vesselStatus = "Ламинарный поток перехода между локациями";
    dimensionalRank = "Исследователь Лиминальных Лабиринтов";
  }

  return {
    astralResonance,
    mentalStability,
    coherenceIndex,
    vesselStatus,
    dimensionalRank,
  };
}
