import test from "node:test";
import assert from "node:assert/strict";
import {
  getThemePreset,
  getPentatonicFrequency,
  calculateFunnelHit,
  calculateCarouselFusionScore,
  project3DPoint,
  mergeBubbleRadii,
  getBestScoreForAttraction,
  calculateCbtRoadmapStage,
  calculateMoodDistribution,
  formatDurationRu,
  advanceBoxBreathingTimer,
  calculateNavigatorCoherence,
  type HarmonyRecord,
  type JournalEntry,
} from "./appLogic";

test("Surreal Circus theme cycling wraps modulo 4 cleanly", () => {
  assert.equal(getThemePreset(0).name, "Обсидиановый Горизонт");
  assert.equal(getThemePreset(1).name, "Гелио-Манеж Хроноса");
  assert.equal(getThemePreset(4).name, "Обсидиановый Горизонт");
  assert.equal(getThemePreset(-1).name, "Астральный Навигатор");
});

test("Pentatonic frequency clamps out-of-range note indices safely", () => {
  assert.equal(getPentatonicFrequency(0), 261.63);
  assert.equal(getPentatonicFrequency(4), 440.0);
  assert.equal(getPentatonicFrequency(99), 880.0);
  assert.equal(getPentatonicFrequency(-5), 261.63);
});

test("Gravity Funnel scoring increments with streak multiplier and resets streak on miss", () => {
  const hit1 = calculateFunnelHit(0, 0, 0, true);
  assert.equal(hit1.score, 10);
  assert.equal(hit1.streak, 1);
  assert.equal(hit1.maxStreak, 1);

  const hit2 = calculateFunnelHit(hit1.score, hit1.streak, hit1.maxStreak, true);
  assert.equal(hit2.score, 21);
  assert.equal(hit2.streak, 2);
  assert.equal(hit2.maxStreak, 2);

  const miss = calculateFunnelHit(hit2.score, hit2.streak, hit2.maxStreak, false);
  assert.equal(miss.score, 21);
  assert.equal(miss.streak, 0);
  assert.equal(miss.maxStreak, 2);
});

test("Celestial Carousel fusion score requires at least 3 connected stars", () => {
  const noFusion = calculateCarouselFusionScore(50, 2, 2);
  assert.equal(noFusion.score, 50);
  assert.equal(noFusion.scaleCount, 2);

  const fusion = calculateCarouselFusionScore(50, 2, 4);
  assert.equal(fusion.score, 150);
  assert.equal(fusion.scaleCount, 3);
});

test("3D perspective projection scales coordinates accurately", () => {
  const projFront = project3DPoint(100, 0, 0, 500, 400, 350, 0);
  assert.equal(projFront.scale, 1);
  assert.equal(projFront.px, 600);

  const projFar = project3DPoint(100, 0, 350, 500, 400, 350, 0);
  assert.equal(projFar.scale, 0.5);
  assert.equal(projFar.px, 550);
});

test("Ethereal Bubbles merge clamps mega bubble radius to 130", () => {
  assert.equal(mergeBubbleRadii(40, 40), 60);
  assert.equal(mergeBubbleRadii(110, 80), 130);
});

test("Best score lookup considers both stored records and live session score", () => {
  const records: HarmonyRecord[] = [
    {
      id: "1",
      attractionName: "Ловец Сфер",
      score: 145,
      dateString: "29.10.2026 16:00",
      noteChainLength: 7,
      themePalette: "Обсидиановый Горизонт",
    },
  ];
  assert.equal(getBestScoreForAttraction(records, "Ловец Сфер", 80), 145);
  assert.equal(getBestScoreForAttraction(records, "Ловец Сфер", 210), 210);
  assert.equal(getBestScoreForAttraction(records, "Карусель Звезд", 0), 0);
});

test("MindSync CBT roadmap progresses across 4 stages based on entry count", () => {
  assert.equal(calculateCbtRoadmapStage(1).phaseLabel, "Этап 1/4");
  assert.equal(calculateCbtRoadmapStage(3).phaseLabel, "Этап 2/4");
  assert.equal(calculateCbtRoadmapStage(7).phaseLabel, "Этап 3/4");
  assert.equal(calculateCbtRoadmapStage(12).phaseLabel, "Этап 4/4");
  assert.equal(calculateCbtRoadmapStage(12).progressPercent, 100);
});

test("MindSync mood distribution computes percentages and sorts descending", () => {
  const sample: JournalEntry[] = [
    {
      id: "1",
      mood: "Anxious",
      originalThought: "Тест 1",
      distortions: "Catastrophizing",
      rationalThought: "Ответ 1",
      intensityBefore: 8,
      intensityAfter: 4,
      geminiFeedback: null,
      timestamp: 1000,
    },
    {
      id: "2",
      mood: "Anxious",
      originalThought: "Тест 2",
      distortions: "Mind Reading",
      rationalThought: "Ответ 2",
      intensityBefore: 7,
      intensityAfter: 3,
      geminiFeedback: null,
      timestamp: 2000,
    },
    {
      id: "3",
      mood: "Peaceful",
      originalThought: "Тест 3",
      distortions: "",
      rationalThought: "Ответ 3",
      intensityBefore: 3,
      intensityAfter: 2,
      geminiFeedback: null,
      timestamp: 3000,
    },
  ];

  const dist = calculateMoodDistribution(sample);
  assert.equal(dist.length, 2);
  assert.equal(dist[0].ruName, "Тревога");
  assert.equal(dist[0].count, 2);
  assert.equal(dist[0].percentage, 67);
  assert.equal(dist[1].ruName, "Спокойствие");
  assert.equal(dist[1].percentage, 33);
});

test("MindSync 4-4-4-4 box breathing timer advances and cycles phases", () => {
  assert.equal(formatDurationRu(125), "2 м 5 с");
  const step1 = advanceBoxBreathingTimer(0, 4);
  assert.equal(step1.breathPhase, 0);
  assert.equal(step1.phaseTimer, 3);
  assert.equal(step1.cycleText, "Вдох...");

  const nextPhase = advanceBoxBreathingTimer(0, 1);
  assert.equal(nextPhase.breathPhase, 1);
  assert.equal(nextPhase.phaseTimer, 4);
  assert.equal(nextPhase.cycleText, "Задержка...");
});

test("Navigator coherence calculates combined Astral (Part 1) and Mental (Part 2) resonance", () => {
  const telemetry = calculateNavigatorCoherence(
    [
      {
        id: "r1",
        attractionName: "Ловец Сфер",
        score: 600,
        dateString: "29.10.2026",
        noteChainLength: 10,
        themePalette: "Обсидиановый Горизонт",
      },
    ],
    [
      {
        id: "e1",
        mood: "Anxious",
        originalThought: "Шум в канале",
        distortions: "Catastrophizing",
        rationalThought: "Стабилизация курса",
        intensityBefore: 9,
        intensityAfter: 2,
        geminiFeedback: null,
        timestamp: 1000,
      },
    ],
    [{ id: "b1", durationSeconds: 300, timestamp: 1000 }]
  );

  assert.equal(telemetry.astralResonance, 75);
  assert.equal(telemetry.mentalStability >= 75, true);
  assert.equal(telemetry.coherenceIndex >= 75, true);
});
