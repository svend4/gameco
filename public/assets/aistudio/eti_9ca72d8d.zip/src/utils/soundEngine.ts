import { getPentatonicFrequency } from "./appLogic";

class SurrealSoundEngine {
  private ctx: AudioContext | null = null;
  public isMuted = false;

  public isEnabled(): boolean {
    return !this.isMuted;
  }

  public setEnabled(enabled: boolean): void {
    this.isMuted = !enabled;
  }

  private ensureContext(): AudioContext | null {
    if (this.isMuted || typeof window === "undefined") return null;
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!this.ctx) {
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playTone(frequency: number, durationMs = 350, type: OscillatorType = "sine"): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const durationSec = Math.max(0.05, durationMs / 1000);

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(frequency, now);

      // Smooth attack (10%) and decay (last 35%) envelope matching SurrealSoundGenerator.kt
      const attackEnd = now + durationSec * 0.1;
      const decayStart = now + durationSec * 0.65;
      const end = now + durationSec;

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.18, attackEnd);
      gain.gain.setValueAtTime(0.18, decayStart);
      gain.gain.exponentialRampToValueAtTime(0.0001, end);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(end + 0.02);
    } catch {
      // Ignore audio autoplay block until user gesture
    }
  }

  public playNoteIndex(index: number, durationMs = 350): void {
    const freq = getPentatonicFrequency(index);
    this.playTone(freq, durationMs, "sine");
  }

  public playArpeggio(baseIndex: number): void {
    this.playNoteIndex(baseIndex, 180);
    setTimeout(() => this.playNoteIndex((baseIndex + 2) % 10, 180), 95);
    setTimeout(() => this.playNoteIndex((baseIndex + 4) % 10, 320), 190);
  }

  public playGateWelcome(): void {
    this.playTone(440.0, 140, "sine");
    setTimeout(() => this.playTone(523.25, 240, "triangle"), 90);
  }
}

export const soundEngine = new SurrealSoundEngine();
