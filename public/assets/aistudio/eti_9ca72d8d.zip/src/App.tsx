import { useEffect, useState } from "react";
import {
  getThemePreset,
  calculateNavigatorCoherence,
  type HarmonyRecord,
  type JournalEntry,
  type BreathingSession,
} from "./utils/appLogic";
import { soundEngine } from "./utils/soundEngine";
import { SurrealCircusView, type CircusScreen } from "./components/SurrealCircusView";
import { MindSyncView, type MindSyncSubScreen } from "./components/MindSyncView";
import { ArchiveInspectorView } from "./components/ArchiveInspectorView";
import { CosmologyCodexView } from "./components/CosmologyCodexView";

type ActiveModule = "circus" | "codex" | "mindsync" | "archives";

const INITIAL_HARMONY_RECORDS: HarmonyRecord[] = [
  {
    id: "seed-1",
    attractionName: "Ловец Сфер",
    score: 185,
    dateString: "29.10.2026 15:40",
    noteChainLength: 9,
    themePalette: "Обсидиановый Горизонт",
  },
  {
    id: "seed-2",
    attractionName: "Карусель Звезд",
    score: 225,
    dateString: "29.10.2026 16:05",
    noteChainLength: 3,
    themePalette: "Гелио-Манеж Хроноса",
  },
  {
    id: "seed-3",
    attractionName: "Сферы Эфира",
    score: 140,
    dateString: "29.10.2026 16:20",
    noteChainLength: 5,
    themePalette: "Герметический Изумруд",
  },
];

const INITIAL_CBT_ENTRIES: JournalEntry[] = [
  {
    id: "cbt-seed-1",
    mood: "Anxious",
    originalThought:
      "Если релиз мобильного приложения задержится хотя бы на день, вся команда сочтет мою работу провальной.",
    distortions: "Catastrophizing, Mind Reading",
    rationalThought:
      "Сроки разработки зависят от множества факторов. Команда ценит прозрачность и качество кода, а предупреждение о статусе задач — нормальная инженерная практика.",
    intensityBefore: 8,
    intensityAfter: 3,
    geminiFeedback: [
      "1. Эмпатия и принятие чувств",
      "Тревога перед важным релизом совершенно естественна — она говорит о том, что вам небезразличен результат команды.",
      "",
      "2. Разбор когнитивных искажений",
      "Здесь переплелись «Катастрофизация» (ожидание полного краха из-за небольшой задержки) и «Чтение мыслей» (приписывание коллегам жесткого осуждения без реальных доказательств).",
      "",
      "3. Поддержка рационального ответа",
      "Ваш переформулированный ответ опираясь на зрелую инженерную культуру: открытая коммуникация всегда продуктивнее самокритики.",
    ].join("\n"),
    timestamp: Date.now() - 1000 * 60 * 95,
  },
  {
    id: "cbt-seed-2",
    mood: "Peaceful",
    originalThought:
      "Мне нужно успеть идеально закрыть все задачи до вечера, иначе день прошел зря.",
    distortions: "All-or-Nothing",
    rationalThought:
      "Даже завершение двух ключевых приоритетов — это весомый вклад в проект. Прогресс важнее недостижимого перфекционизма.",
    intensityBefore: 6,
    intensityAfter: 2,
    geminiFeedback: [
      "1. Эмпатия и принятие чувств",
      "Стремление к продуктивности похвально, но требование абсолютного идеала быстро истощает ресурсы.",
      "",
      "2. Разбор когнитивных искажений",
      "«Черно-белое мышление» заставляет обесценивать частичный, но реальный прогресс.",
      "",
      "3. Практический шаг осознанности",
      "Выпишите 3 уже выполненных сегодня дела и сделайте 2 минуты спокойного квадратного дыхания 4-4-4-4.",
    ].join("\n"),
    timestamp: Date.now() - 1000 * 60 * 240,
  },
];

const INITIAL_BREATHING_SESSIONS: BreathingSession[] = [
  { id: "br-1", durationSeconds: 120, timestamp: Date.now() - 1000 * 60 * 180 },
  { id: "br-2", durationSeconds: 64, timestamp: Date.now() - 1000 * 60 * 45 },
];

export default function App() {
  const [activeModule, setActiveModule] = useState<ActiveModule>("circus");
  const [circusScreen, setCircusScreen] = useState<CircusScreen>("dashboard");
  const [mindSyncScreen, setMindSyncScreen] = useState<MindSyncSubScreen>("journal");

  const [themeIndex, setThemeIndex] = useState<number>(() => {
    try {
      const saved = localStorage.getItem("surreal_theme_idx");
      return saved ? Number(saved) : 0;
    } catch {
      return 0;
    }
  });

  const [harmonyRecords, setHarmonyRecords] = useState<HarmonyRecord[]>(() => {
    try {
      const saved = localStorage.getItem("surreal_harmony_records");
      return saved ? JSON.parse(saved) : INITIAL_HARMONY_RECORDS;
    } catch {
      return INITIAL_HARMONY_RECORDS;
    }
  });

  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem("mindsync_cbt_entries");
      return saved ? JSON.parse(saved) : INITIAL_CBT_ENTRIES;
    } catch {
      return INITIAL_CBT_ENTRIES;
    }
  });

  const [breathingSessions, setBreathingSessions] = useState<BreathingSession[]>(() => {
    try {
      const saved = localStorage.getItem("mindsync_breathing_sessions");
      return saved ? JSON.parse(saved) : INITIAL_BREATHING_SESSIONS;
    } catch {
      return INITIAL_BREATHING_SESSIONS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("surreal_theme_idx", String(themeIndex));
    } catch {
      // ignore storage quota errors
    }
  }, [themeIndex]);

  useEffect(() => {
    try {
      localStorage.setItem("surreal_harmony_records", JSON.stringify(harmonyRecords));
    } catch {
      // ignore
    }
  }, [harmonyRecords]);

  useEffect(() => {
    try {
      localStorage.setItem("mindsync_cbt_entries", JSON.stringify(journalEntries));
    } catch {
      // ignore
    }
  }, [journalEntries]);

  useEffect(() => {
    try {
      localStorage.setItem("mindsync_breathing_sessions", JSON.stringify(breathingSessions));
    } catch {
      // ignore
    }
  }, [breathingSessions]);

  const activeTheme = getThemePreset(themeIndex);
  const navigatorTelemetry = calculateNavigatorCoherence(
    harmonyRecords,
    journalEntries,
    breathingSessions
  );

  const handleCycleTheme = () => {
    setThemeIndex((prev) => (prev + 1) % 4);
    soundEngine.playNoteIndex(3, 180);
  };

  const handleSaveHarmonyRecord = (
    attractionName: string,
    score: number,
    noteChainLength: number
  ) => {
    if (score <= 0) return;
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const dateString = `${pad(now.getDate())}.${pad(now.getMonth() + 1)}.${now.getFullYear()} ${pad(
      now.getHours()
    )}:${pad(now.getMinutes())}`;

    const newRec: HarmonyRecord = {
      id: `rec-${Date.now()}`,
      attractionName,
      score,
      dateString,
      noteChainLength,
      themePalette: activeTheme.name,
    };
    setHarmonyRecords((prev) => [newRec, ...prev]);
  };

  const handleClearHarmonyRecords = () => {
    setHarmonyRecords([]);
    soundEngine.playTone(220, 320);
  };

  const handleAddJournalEntry = (entryData: Omit<JournalEntry, "id" | "timestamp">) => {
    const newEntry: JournalEntry = {
      ...entryData,
      id: `cbt-${Date.now()}`,
      timestamp: Date.now(),
    };
    setJournalEntries((prev) => [newEntry, ...prev]);
  };

  const handleDeleteJournalEntry = (id: string) => {
    setJournalEntries((prev) => prev.filter((item) => item.id !== id));
  };

  const handleSaveBreathingSession = (durationSeconds: number) => {
    if (durationSeconds <= 0) return;
    const newSession: BreathingSession = {
      id: `br-${Date.now()}`,
      durationSeconds,
      timestamp: Date.now(),
    };
    setBreathingSessions((prev) => [newSession, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#0B0D17] text-slate-100 flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 flex flex-wrap md:flex-nowrap items-center justify-between gap-3 md:gap-8 px-4 sm:px-6 py-3.5 border-b border-slate-800/80 bg-[#0B0D17]/95">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveModule("circus");
            setCircusScreen("dashboard");
          }}
          className="text-base sm:text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          Surreal Circus &amp; MindSync
        </a>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav
          aria-label="Основная навигация"
          className="order-3 md:order-2 w-full md:w-auto flex items-center gap-4 sm:gap-6 text-xs sm:text-sm font-medium overflow-x-auto pt-1 md:pt-0"
        >
          <button
            type="button"
            onClick={() => {
              setActiveModule("circus");
              setCircusScreen("dashboard");
            }}
            data-testid="nav-surreal-circus"
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 ${
              activeModule === "circus"
                ? "text-white border-pink-500"
                : "text-slate-400 hover:text-white border-transparent"
            }`}
          >
            Астрал 4D
          </button>

          <button
            type="button"
            onClick={() => setActiveModule("codex")}
            data-testid="nav-cosmology-codex"
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 ${
              activeModule === "codex"
                ? "text-white border-cyan-400"
                : "text-slate-400 hover:text-white border-transparent"
            }`}
          >
            Кодекс и Граф 4D
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveModule("mindsync");
              setMindSyncScreen("journal");
            }}
            data-testid="nav-mindsync"
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 ${
              activeModule === "mindsync" && mindSyncScreen !== "breathing"
                ? "text-white border-indigo-400"
                : "text-slate-400 hover:text-white border-transparent"
            }`}
          >
            Ментал Космонавта
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveModule("mindsync");
              setMindSyncScreen("breathing");
            }}
            data-testid="nav-breathing"
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 ${
              activeModule === "mindsync" && mindSyncScreen === "breathing"
                ? "text-white border-emerald-400"
                : "text-slate-400 hover:text-white border-transparent"
            }`}
          >
            Дыхание 4-4-4-4
          </button>

          <button
            type="button"
            onClick={() => setActiveModule("archives")}
            data-testid="nav-archives"
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 ${
              activeModule === "archives"
                ? "text-white border-amber-400"
                : "text-slate-400 hover:text-white border-transparent"
            }`}
          >
            Архивы (.zip)
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="order-2 md:order-3 flex items-center shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveModule("mindsync");
              setMindSyncScreen("add-log");
            }}
            data-testid="header-cta-cbt"
            className="px-3.5 py-2 text-xs font-bold text-white bg-indigo-500 hover:bg-indigo-400 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Запись КПТ
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-[1240px] mx-auto px-4 sm:px-6 py-8">
        {activeModule === "circus" && (
          <SurrealCircusView
            theme={activeTheme}
            onCycleTheme={handleCycleTheme}
            onSelectTheme={(idx) => {
              setThemeIndex(idx);
              soundEngine.playNoteIndex(idx * 2, 180);
            }}
            onOpenCodex={() => setActiveModule("codex")}
            records={harmonyRecords}
            onSaveRecord={handleSaveHarmonyRecord}
            onClearRecords={handleClearHarmonyRecords}
            activeScreen={circusScreen}
            onSelectScreen={setCircusScreen}
          />
        )}

        {activeModule === "codex" && (
          <CosmologyCodexView
            theme={activeTheme}
            telemetry={navigatorTelemetry}
            onJumpToCircusGate={(gate) => {
              setActiveModule("circus");
              setCircusScreen(gate);
              soundEngine.playGateWelcome();
            }}
            onJumpToMindSync={(sub) => {
              setActiveModule("mindsync");
              setMindSyncScreen(sub);
            }}
          />
        )}

        {activeModule === "mindsync" && (
          <MindSyncView
            entries={journalEntries}
            breathingSessions={breathingSessions}
            onAddEntry={handleAddJournalEntry}
            onDeleteEntry={handleDeleteJournalEntry}
            onSaveBreathingSession={handleSaveBreathingSession}
            activeSubScreen={mindSyncScreen}
            onChangeSubScreen={setMindSyncScreen}
          />
        )}

        {activeModule === "archives" && <ArchiveInspectorView />}
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-800/60 py-5 px-6 text-xs text-slate-400">
        <div className="max-w-[1240px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <span>
            Ось Странника: Астрал 4D (Surreal Circus) × Ментал Космонавта (MindSync) · Синхронизация:{" "}
            {navigatorTelemetry.coherenceIndex}%
          </span>
          <div className="flex items-center gap-4">
            <a
              href="/assets/aistudio/surreal-circus_67a2ed2c.zip"
              download="surreal-circus_67a2ed2c.zip"
              className="hover:text-white transition-colors"
            >
              Скачать surreal-circus.zip
            </a>
            <span aria-hidden="true">·</span>
            <a
              href="/assets/aistudio/mindsync_86ed3d0a.zip"
              download="mindsync_86ed3d0a.zip"
              className="hover:text-white transition-colors"
            >
              Скачать mindsync.zip
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
