package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emoji_avatars")
data class AvatarEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val baseEmoji: String,
    val accessoryEmoji: String,
    val flagEmoji: String,
    val backgroundStyle: String, // e.g. "Cosmic", "Neon", "Ocean", "Forest", "Gold"
    val characterRole: String, // e.g. "Knight", "Mage", "Cyber-Ninja", "Chef", "Astronaut"
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val timestamp: Long = System.currentTimeMillis()
)
