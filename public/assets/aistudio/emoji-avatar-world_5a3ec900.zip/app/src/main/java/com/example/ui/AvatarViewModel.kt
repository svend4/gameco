package com.example.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AvatarEntity
import com.example.data.AvatarRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

// Represents an action log in the combat mode
data class CombatLog(
    val message: String,
    val type: LogType // PLAYER, MONSTER, SYSTEM, HEAL, CRITICAL
)

enum class LogType {
    PLAYER, MONSTER, SYSTEM, HEAL, CRITICAL
}

class AvatarViewModel(private val repository: AvatarRepository) : ViewModel() {

    // List of saved avatars from Room
    val savedAvatars: StateFlow<List<AvatarEntity>> = repository.allAvatars
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current builder state variables
    var builderName by mutableStateOf("Герой Эмодзи")
    var builderBaseEmoji by mutableStateOf("🦊")
    var builderAccessoryEmoji by mutableStateOf("👑")
    var builderFlagEmoji by mutableStateOf("🏁")
    var builderBackgroundStyle by mutableStateOf("Cosmic") // Cosmic, Neon, Ocean, Forest, Gold
    var builderRole by mutableStateOf("Cyber-Ninja") // Knight, Mage, Cyber-Ninja, Chef, Astronaut

    // Dynamically calculated preview stats
    val previewHp: Int
        get() = when (builderRole) {
            "Knight" -> 140
            "Mage" -> 90
            "Cyber-Ninja" -> 110
            "Chef" -> 150
            "Astronaut" -> 120
            else -> 100
        } + (builderBaseEmoji.hashCode() % 15).coerceAtLeast(0)

    val previewAttack: Int
        get() = when (builderRole) {
            "Knight" -> 18
            "Mage" -> 35
            "Cyber-Ninja" -> 28
            "Chef" -> 14
            "Astronaut" -> 22
            else -> 20
        } + (builderAccessoryEmoji.hashCode() % 8).coerceAtLeast(0)

    val previewDefense: Int
        get() = when (builderRole) {
            "Knight" -> 30
            "Mage" -> 12
            "Cyber-Ninja" -> 18
            "Chef" -> 20
            "Astronaut" -> 25
            else -> 15
        } + (builderBackgroundStyle.hashCode() % 6).coerceAtLeast(0)

    fun applyRandomConfig() {
        val baseList = listOf("🦊", "🦁", "🐯", "🐼", "🐨", "🦄", "🤖", "👽", "👾", "🤠", "😎", "😈", "🦉", "🐧", "🐲", "🐙")
        val accessoryList = listOf("🕶️", "👑", "🎧", "🎩", "⚔️", "🛡️", "🎒", "🎈", "🍀", "🔥", "⚡", "❄️", "🎨", "🚀", "🎸", "💎")
        val flagList = listOf("🏁", "🏳️‍🌈", "🏳️‍⚧️", "🏴‍☠️", "🚩", "🎖️", "🌍", "🌌", "🔮", "✨", "❤️", "🔥", "🌈")
        val bgList = listOf("Cosmic", "Neon", "Ocean", "Forest", "Gold")
        val roleList = listOf("Knight", "Mage", "Cyber-Ninja", "Chef", "Astronaut")
        val namePrefixes = listOf("Ловкий", "Мудрый", "Кибер-", "Полярный", "Звездный", "Мега-", "Редкий", "Древний", "Безумный")
        val nameSuffixes = listOf("Барс", "Панда", "Енот", "Астронавт", "Магистр", "Шеф", "Самурай", "Страж", "Странник")

        builderBaseEmoji = baseList[Random.nextInt(baseList.size)]
        builderAccessoryEmoji = accessoryList[Random.nextInt(accessoryList.size)]
        builderFlagEmoji = flagList[Random.nextInt(flagList.size)]
        builderBackgroundStyle = bgList[Random.nextInt(bgList.size)]
        builderRole = roleList[Random.nextInt(roleList.size)]
        builderName = "${namePrefixes[Random.nextInt(namePrefixes.size)]} ${nameSuffixes[Random.nextInt(nameSuffixes.size)]}"
    }

    fun saveAvatar() {
        viewModelScope.launch {
            val entity = AvatarEntity(
                name = builderName,
                baseEmoji = builderBaseEmoji,
                accessoryEmoji = builderAccessoryEmoji,
                flagEmoji = builderFlagEmoji,
                backgroundStyle = builderBackgroundStyle,
                characterRole = builderRole,
                hp = previewHp,
                attack = previewAttack,
                defense = previewDefense
            )
            repository.insert(entity)
        }
    }

    fun deleteAvatar(avatar: AvatarEntity) {
        viewModelScope.launch {
            repository.delete(avatar)
            // If the deleted avatar is active in the game, reset selection
            if (activeFighter == avatar) {
                activeFighter = null
                endBattle()
            }
        }
    }

    // --- GAME / ARENA STATE ---
    var activeFighter by mutableStateOf<AvatarEntity?>(null)
    var isBattleActive by mutableStateOf(false)
    var isPlayerTurn by mutableStateOf(true)
    var pHP by mutableStateOf(100)
    var pMaxHP by mutableStateOf(100)
    var bHP by mutableStateOf(120)
    var bMaxHP by mutableStateOf(120)

    var currentBossName by mutableStateOf("👾 Инопланетный Слизень")
    var currentBossEmoji by mutableStateOf("👾")
    var currentBossMaxHP by mutableStateOf(120)
    var currentBossAttack by mutableStateOf(18)
    var currentBossDefense by mutableStateOf(10)

    val combatLogs = mutableListOf<CombatLog>()
    var battleResultText by mutableStateOf("") // "VICTORY", "DEFEAT", or ""

    fun selectFighter(avatar: AvatarEntity) {
        activeFighter = avatar
        pHP = avatar.hp
        pMaxHP = avatar.hp
        endBattle()
    }

    fun selectRandomBoss() {
        val bosses = listOf(
            Triple("🐉 Коррозийный Дракон", "🐉", 180 to 22),
            Triple("👾 Кибер-Захватчик", "👾", 130 to 26),
            Triple("👻 Древний Полтергейст", "👻", 110 to 30),
            Triple("🦁 Огненная Химера", "🦁", 150 to 24),
            Triple("🐙 Глубоководный Кракен", "🐙", 200 to 18)
        )
        val selected = bosses[Random.nextInt(bosses.size)]
        currentBossName = selected.first
        currentBossEmoji = selected.second
        currentBossMaxHP = selected.third.first
        bHP = selected.third.first
        bMaxHP = selected.third.first
        currentBossAttack = selected.third.second
        currentBossDefense = 10 + Random.nextInt(10)
    }

    fun startBattle() {
        val fighter = activeFighter ?: return
        pHP = fighter.hp
        pMaxHP = fighter.hp
        selectRandomBoss()
        combatLogs.clear()
        combatLogs.add(CombatLog("⚔️ Бой начался! Вашим бойцом выступает ${fighter.name} [${fighter.characterRole}]!", LogType.SYSTEM))
        combatLogs.add(CombatLog("👿 Вас атакует босс: $currentBossName $currentBossEmoji (HP: $bMaxHP, ATK: $currentBossAttack)!", LogType.SYSTEM))
        isBattleActive = true
        isPlayerTurn = true
        battleResultText = ""
    }

    fun endBattle() {
        isBattleActive = false
        battleResultText = ""
        combatLogs.clear()
    }

    fun playerAttack() {
        if (!isBattleActive || !isPlayerTurn) return
        val fighter = activeFighter ?: return

        // Calculate damage
        val isCrit = Random.nextInt(100) < 20 // 20% critical chance
        val baseDmg = (fighter.attack * 1.0 - currentBossDefense * 0.25).coerceAtLeast(8.0).toInt()
        val randomFactor = Random.nextInt(1, 8)
        var damage = baseDmg + randomFactor
        if (isCrit) damage = (damage * 1.5).toInt()

        bHP = (bHP - damage).coerceAtLeast(0)

        if (isCrit) {
            combatLogs.add(CombatLog("✨ КРИТИЧЕСКИЙ УДАР! ${fighter.baseEmoji} ${fighter.name} наносит $damage урона по $currentBossName ${currentBossEmoji}!", LogType.CRITICAL))
        } else {
            combatLogs.add(CombatLog("⚔️ ${fighter.baseEmoji} ${fighter.name} нанес $damage урона по $currentBossName ${currentBossEmoji}.", LogType.PLAYER))
        }

        if (bHP <= 0) {
            bHP = 0
            battleResultText = "VICTORY"
            isBattleActive = false
            combatLogs.add(CombatLog("🎉 ПОБЕДА! $currentBossName повержен! Вы заслужили звание Великого Мастера Эмодзи! 🏆", LogType.SYSTEM))
            return
        }

        isPlayerTurn = false
        triggerMonsterTurn()
    }

    fun playerHeal() {
        if (!isBattleActive || !isPlayerTurn) return
        val fighter = activeFighter ?: return

        val baseHeal = 25
        val randomFactor = Random.nextInt(5, 15)
        val finalHeal = baseHeal + randomFactor
        pHP = (pHP + finalHeal).coerceAtMost(pMaxHP)

        combatLogs.add(CombatLog("💖 ${fighter.baseEmoji} ${fighter.name} применил зелье лечения и восстановил +$finalHeal ОЗ! ❤️", LogType.HEAL))

        isPlayerTurn = false
        triggerMonsterTurn()
    }

    fun playerSpecialBlock() {
        if (!isBattleActive || !isPlayerTurn) return
        val fighter = activeFighter ?: return

        // Dynamic cosmic magic spell based on attributes
        val spellElement = when (fighter.backgroundStyle) {
            "Cosmic" -> "🌌 Вспышка Сверхновой"
            "Neon" -> "⚡ Лазерный Импульс"
            "Ocean" -> "🌊 Цунами Unicode"
            "Forest" -> "🍃 Дыхание Природы"
            else -> "✨ Золотой Метеорит"
        }

        // Deal special elemental damage
        val elementalDmg = fighter.attack + Random.nextInt(15, 30)
        bHP = (bHP - elementalDmg).coerceAtLeast(0)

        combatLogs.add(CombatLog("⚛️ ${fighter.baseEmoji} активирует заклинание [$spellElement] и разрывает пиксели! Нанесено $elementalDmg космического урона!", LogType.CRITICAL))

        if (bHP <= 0) {
            bHP = 0
            battleResultText = "VICTORY"
            isBattleActive = false
            combatLogs.add(CombatLog("🎉 ПОБЕДА! $currentBossName уничтожен древней магией! 🏆", LogType.SYSTEM))
            return
        }

        isPlayerTurn = false
        triggerMonsterTurn()
    }

    private fun triggerMonsterTurn() {
        viewModelScope.launch {
            kotlinx.coroutines.delay(1200) // Realistic delay for turn-based visual immersion
            if (!isBattleActive) return@launch

            val fighter = activeFighter ?: return@launch
            val monsterCrit = Random.nextInt(100) < 15
            val rawDamage = (currentBossAttack * 1.0 - fighter.defense * 0.25).coerceAtLeast(6.0).toInt()
            val variance = Random.nextInt(1, 6)
            var finalMonsterDmg = rawDamage + variance
            if (monsterCrit) finalMonsterDmg = (finalMonsterDmg * 1.5).toInt()

            pHP = (pHP - finalMonsterDmg).coerceAtLeast(0)

            if (monsterCrit) {
                combatLogs.add(CombatLog("💥 КРИТ О Т МОНСТРА! $currentBossName $currentBossEmoji яростно атакует ${fighter.baseEmoji} и наносит $finalMonsterDmg урона!", LogType.CRITICAL))
            } else {
                combatLogs.add(CombatLog("👿 $currentBossName $currentBossEmoji атакует вашего бойца на $finalMonsterDmg урона.", LogType.MONSTER))
            }

            if (pHP <= 0) {
                pHP = 0
                battleResultText = "DEFEAT"
                isBattleActive = false
                combatLogs.add(CombatLog("💀 Поражение... Ваши очки здоровья опустились до 0. Нажмите 'Реванш', чтобы попробовать снова!", LogType.SYSTEM))
                return@launch
            }

            isPlayerTurn = true
        }
    }
}

class ViewModelFactory(private val repository: AvatarRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AvatarViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AvatarViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
