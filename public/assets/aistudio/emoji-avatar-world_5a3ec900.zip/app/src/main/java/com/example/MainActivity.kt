package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.detectDragGestures
import kotlin.math.absoluteValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppDatabase
import com.example.data.AvatarEntity
import com.example.data.AvatarRepository
import com.example.ui.AvatarViewModel
import com.example.ui.LogType
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.ViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Room database
        val database = AppDatabase.getDatabase(this)
        val repository = AvatarRepository(database.avatarDao())

        setContent {
            MyApplicationTheme {
                // Initialize ViewModel with custom factory
                val viewModel: AvatarViewModel by viewModels { ViewModelFactory(repository) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    EmojiAvatarStudioApp(viewModel)
                }
            }
        }
    }
}

// Custom Premium Gradient Brushes
val GradientCosmic = Brush.linearGradient(listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121)))
val GradientNeon = Brush.linearGradient(listOf(Color(0xFFFA8BFF), Color(0xFF2BD2FF), Color(0xFF2BFF88)))
val GradientOcean = Brush.linearGradient(listOf(Color(0xFF00AAFF), Color(0xFF0044CC)))
val GradientForest = Brush.linearGradient(listOf(Color(0xFF11998E), Color(0xFF38EF7D)))
val GradientGold = Brush.linearGradient(listOf(Color(0xFFF2C94C), Color(0xFFF2994A)))
val GradientSlate = Brush.linearGradient(listOf(Color(0xFF232526), Color(0xFF414345)))

fun getGradient(style: String): Brush {
    return when (style) {
        "Cosmic" -> GradientCosmic
        "Neon" -> GradientNeon
        "Ocean" -> GradientOcean
        "Forest" -> GradientForest
        "Gold" -> GradientGold
        else -> GradientSlate
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmojiAvatarStudioApp(viewModel: AvatarViewModel) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(0) }
    val savedAvatars by viewModel.savedAvatars.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Создатель") },
                    label = { Text("Создатель", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tab_builder")
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = {
                        BadgedBox(badge = {
                            if (savedAvatars.isNotEmpty()) {
                                Badge { Text(savedAvatars.size.toString()) }
                            }
                        }) {
                            Icon(Icons.Default.Face, contentDescription = "Галерея")
                        }
                    },
                    label = { Text("Галерея", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tab_gallery")
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Арена") },
                    label = { Text("Арена", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tab_arena")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Elegant Studio App Bar Header
            EmojiStudioHeader()

            // Main Tab Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                    },
                    label = "TabTransition"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> BuilderTab(viewModel)
                        1 -> GalleryTab(viewModel, showBuilderTab = { currentTab = 0 })
                        2 -> ArenaTab(viewModel, showGalleryTab = { currentTab = 1 })
                    }
                }
            }
        }
    }
}

@Composable
fun EmojiStudioHeader() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "🦊👑🏆",
                    fontSize = 24.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Emoji Avatar Studio",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontSize = 20.sp
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Идеальное решение для создания цветных RPG аватаров из эмодзи!",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "💎 3D-ЭФФЕКТ: зажмите и потяните карту героя для вращения с бликами!",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

// Custom layered Avatar card component to handle asymmetric depth, 3D interactive tilt, and holographic parallax glossy shine overlays
@Composable
fun EmojiAvatarCard(
    base: String,
    accessory: String,
    flag: String,
    bgStyle: String,
    modifier: Modifier = Modifier,
    sizeDp: Int = 110,
    role: String = "Cyber-Ninja",
    hasGlow: Boolean = false
) {
    val coroutineScope = rememberCoroutineScope()

    // Dynamic size tracking for mapping touches and tilt calculations
    var cardWidth by remember { mutableStateOf(1f) }
    var cardHeight by remember { mutableStateOf(1f) }

    // Touch interactive tilt mechanics
    var isTouched by remember { mutableStateOf(false) }
    val rotX = remember { Animatable(0f) }
    val rotY = remember { Animatable(0f) }

    // Ambient floating 3D orbital wobble to display the depth parallax effect when untouched
    val infiniteTransition = rememberInfiniteTransition("AmbientWobble")
    val ambientX by infiniteTransition.animateFloat(
        initialValue = -7f,
        targetValue = 7f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AmbientX"
    )
    val ambientY by infiniteTransition.animateFloat(
        initialValue = -7f,
        targetValue = 7f,
        animationSpec = infiniteRepeatable(
            animation = tween(3300, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AmbientY"
    )

    // Blend interactive and automated gyro-simulate angles
    val totalRotX = (if (isTouched) rotX.value else rotX.value + ambientX)
    val totalRotY = (if (isTouched) rotY.value else rotY.value + ambientY)

    // Arena status pulsating scaling
    val animScale by rememberInfiniteTransition("Glow").animateFloat(
        initialValue = if (hasGlow) 0.94f else 1f,
        targetValue = if (hasGlow) 1.06f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScaleGlow"
    )

    Box(
        modifier = modifier
            .size(sizeDp.dp)
            .padding(6.dp)
            .scale(animScale)
            .onSizeChanged { size ->
                cardWidth = size.width.toFloat().coerceAtLeast(1f)
                cardHeight = size.height.toFloat().coerceAtLeast(1f)
            }
            .shadow(
                elevation = if (isTouched) 20.dp else 6.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Color.Black.copy(0.45f),
                spotColor = Color.Black.copy(0.45f)
            )
            .border(
                BorderStroke(2.5.dp, Color.White.copy(alpha = 0.85f)),
                shape = RoundedCornerShape(24.dp)
            )
            // Apply 3D Perspective rotation with professional cameraDistance to avoid distortion
            .graphicsLayer {
                rotationX = totalRotX
                rotationY = totalRotY
                cameraDistance = 14f * density
            }
            // Seamless drag and touch-to-tilt tracking
            .pointerInput(cardWidth, cardHeight) {
                detectDragGestures(
                    onDragStart = { offset ->
                        isTouched = true
                        val nX = ((offset.x - cardWidth / 2f) / (cardWidth / 2f)).coerceIn(-1f, 1f)
                        val nY = ((offset.y - cardHeight / 2f) / (cardHeight / 2f)).coerceIn(-1f, 1f)
                        coroutineScope.launch {
                            rotY.animateTo(nX * 28f, spring(stiffness = Spring.StiffnessMedium))
                            rotX.animateTo(-nY * 28f, spring(stiffness = Spring.StiffnessMedium))
                        }
                    },
                    onDrag = { change, _ ->
                        isTouched = true
                        val pos = change.position
                        val nX = ((pos.x - cardWidth / 2f) / (cardWidth / 2f)).coerceIn(-1f, 1f)
                        val nY = ((pos.y - cardHeight / 2f) / (cardHeight / 2f)).coerceIn(-1f, 1f)
                        coroutineScope.launch {
                            rotY.snapTo(nX * 28f)
                            rotX.snapTo(-nY * 28f)
                        }
                        change.consume()
                    },
                    onDragEnd = {
                        isTouched = false
                        coroutineScope.launch {
                            rotY.animateTo(0f, spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioMediumBouncy))
                            rotX.animateTo(0f, spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioMediumBouncy))
                        }
                    },
                    onDragCancel = {
                        isTouched = false
                        coroutineScope.launch {
                            rotY.animateTo(0f, spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioMediumBouncy))
                            rotX.animateTo(0f, spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioMediumBouncy))
                        }
                    }
                )
            }
            .clip(RoundedCornerShape(24.dp))
            .background(getGradient(bgStyle)),
        contentAlignment = Alignment.Center
    ) {
        // --- LAYER 1: Deep Background Elements (Contra-parallax styling) ---
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = -totalRotY * 1.6f
                    translationY = totalRotX * 1.6f
                }
        ) {
            val canvasSize = this.size
            val canvasCenter = this.center
            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = canvasSize.minDimension / 2.2f,
                center = canvasCenter
            )
            drawCircle(
                color = Color.Black.copy(alpha = 0.10f),
                radius = canvasSize.minDimension / 4f,
                center = canvasCenter
            )
            // Extra background galaxy dynamic clusters
            drawCircle(
                color = Color.White.copy(alpha = 0.08f),
                radius = canvasSize.minDimension / 10f,
                center = Offset(canvasSize.width * 0.25f, canvasSize.height * 0.25f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.08f),
                radius = canvasSize.minDimension / 12f,
                center = Offset(canvasSize.width * 0.75f, canvasSize.height * 0.75f)
            )
        }

        // --- LAYER 2: Base Hero Emoji Character (Visual popout parallax depth) ---
        Text(
            text = base.ifEmpty { "🦊" },
            fontSize = (sizeDp * 0.45).sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .offset(y = (-3).dp)
                .graphicsLayer {
                    translationX = totalRotY * 0.5f
                    translationY = -totalRotX * 0.5f
                }
        )

        // --- LAYER 3: Accessory Badge at top-right (Exaggerated volumetric outward pop!) ---
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .size((sizeDp * 0.28).dp)
                .graphicsLayer {
                    translationX = totalRotY * 1.5f
                    translationY = -totalRotX * 1.5f
                }
                .shadow(4.dp, CircleShape)
                .background(Color.White.copy(alpha = 0.92f), CircleShape)
                .border(1.2.dp, Color.Gray.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = accessory.ifEmpty { "🛡️" },
                fontSize = (sizeDp * 0.15).sp
            )
        }

        // --- LAYER 4: Flag/Emblem at bottom-left corner ---
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp)
                .size((sizeDp * 0.28).dp)
                .graphicsLayer {
                    translationX = totalRotY * 1.2f
                    translationY = -totalRotX * 1.2f
                }
                .shadow(4.dp, CircleShape)
                .background(Color.DarkGray.copy(alpha = 0.88f), CircleShape)
                .border(1.2.dp, Color.White.copy(0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = flag.ifEmpty { "🇺🇦" },
                fontSize = (sizeDp * 0.15).sp
            )
        }

        // --- LAYER 5: Character Role Title Badge overlay (Flat baseline) ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(vertical = 1.dp)
        ) {
            Text(
                text = translateRole(role),
                color = Color.White,
                fontSize = 8.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // --- LAYER 6: Holographic Foil Reflection Shine Overlay (reactive lightning) ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = -totalRotY * 2.5f
                    translationY = totalRotX * 2.5f
                }
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.0f),
                            Color.White.copy(alpha = ((totalRotX.absoluteValue + totalRotY.absoluteValue) / 50f).coerceIn(0f, 0.42f)),
                            Color.White.copy(alpha = 0.0f)
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(cardWidth, cardHeight)
                    )
                )
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BuilderTab(viewModel: AvatarViewModel) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val baseOptions = listOf("🦊", "🦁", "🐯", "🐼", "🐨", "🦄", "🤖", "👽", "👾", "🤠", "😎", "😈", "🦉", "🐧", "🐲", "🐙", "🧙", "🧛", "🧟", "🧜")
    val accessoryOptions = listOf("🕶️", "👑", "🎧", "🎩", "⚔️", "🛡️", "🎒", "🎈", "🍀", "🔥", "⚡", "❄️", "🚀", "🎸", "💎", "🔮")
    val flagOptions = listOf("🏁", "🏴‍☠️", "🎖️", "🌍", "🌌", "✨", "🏳️‍🌈", "❤️", "🎈", "👑", "🍕", "🎂", "🍟", "🇺🇸", "🇬🇧", "🚀")
    val bgOptions = listOf(
        Triple("Cosmic", "Космос", GradientCosmic),
        Triple("Neon", "Неон", GradientNeon),
        Triple("Ocean", "Океан", GradientOcean),
        Triple("Forest", "Лес", GradientForest),
        Triple("Gold", "Золото", GradientGold)
    )
    val roleOptions = listOf(
        Pair("Knight", "🛡️ Рыцарь"),
        Pair("Mage", "🔮 Волшебник"),
        Pair("Cyber-Ninja", "⚡ Кибер-Ниндзя"),
        Pair("Chef", "🍳 Шеф-Повар"),
        Pair("Astronaut", "🚀 Космонавт")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // TOP PREVIEW & CONTROLS BLOCK
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Custom-styled Avatar preview
                EmojiAvatarCard(
                    base = viewModel.builderBaseEmoji,
                    accessory = viewModel.builderAccessoryEmoji,
                    flag = viewModel.builderFlagEmoji,
                    bgStyle = viewModel.builderBackgroundStyle,
                    role = viewModel.builderRole,
                    modifier = Modifier.testTag("preview_avatar_card"),
                    sizeDp = 130
                )

                // Stats Dashboard for created avatar
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 12.dp)
                ) {
                    Text(
                        text = "Характеристики",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    StatProgressBar(label = "❤️ Здоровье (HP)", value = viewModel.previewHp, maxValue = 170, color = Color(0xFFEF5350))
                    StatProgressBar(label = "⚔️ Сила (ATK)", value = viewModel.previewAttack, maxValue = 45, color = Color(0xFFFF9800))
                    StatProgressBar(label = "🛡️ Защита (DEF)", value = viewModel.previewDefense, maxValue = 40, color = Color(0xFF4CAF50))
                }
            }
        }

        // INPUT FIELD & RANDOMIZER ROW
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = viewModel.builderName,
                    onValueChange = { if (it.length <= 18) viewModel.builderName = it },
                    label = { Text("Имя аватара") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("name_input"),
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = "Имя") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                )

                Button(
                    onClick = { viewModel.applyRandomConfig() },
                    modifier = Modifier
                        .height(56.dp)
                        .testTag("random_builder_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("🎲 Случ.", fontWeight = FontWeight.Bold)
                }
            }
        }

        // SELECT BASE EMOJI
        item {
            Text("1. Базовый смайлик аватара:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(baseOptions) { emoji ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .shadow(2.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (viewModel.builderBaseEmoji == emoji) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = if (viewModel.builderBaseEmoji == emoji) 2.dp else 1.dp,
                                color = if (viewModel.builderBaseEmoji == emoji) MaterialTheme.colorScheme.primary else Color.LightGray.copy(0.5f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                viewModel.builderBaseEmoji = emoji
                                keyboardController?.hide()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 24.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            // Field to input a custom keyboard emoji manually
            OutlinedTextField(
                value = viewModel.builderBaseEmoji,
                onValueChange = { if (it.isNotEmpty()) viewModel.builderBaseEmoji = it.take(2) },
                label = { Text("Свой смайлик с клавиатуры") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_base_emoji_input"),
                trailingIcon = { Text("⌨️", modifier = Modifier.padding(end = 8.dp)) }
            )
        }

        // SELECT ACCESSORY
        item {
            Text("2. Аксессуар (баф):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(accessoryOptions) { p_emoji ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .shadow(2.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (viewModel.builderAccessoryEmoji == p_emoji) MaterialTheme.colorScheme.secondaryContainer
                                else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = if (viewModel.builderAccessoryEmoji == p_emoji) 2.dp else 1.dp,
                                color = if (viewModel.builderAccessoryEmoji == p_emoji) MaterialTheme.colorScheme.secondary else Color.LightGray.copy(0.5f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                viewModel.builderAccessoryEmoji = p_emoji
                                keyboardController?.hide()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = p_emoji, fontSize = 24.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.builderAccessoryEmoji,
                onValueChange = { if (it.isNotEmpty()) viewModel.builderAccessoryEmoji = it.take(2) },
                label = { Text("Свой аксессуар") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Text("🎩") }
            )
        }

        // SELECT EMBLEM / FLAG
        item {
            Text("3. Герб флага или эмблема:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(flagOptions) { flag ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .shadow(2.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (viewModel.builderFlagEmoji == flag) MaterialTheme.colorScheme.tertiaryContainer
                                else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = if (viewModel.builderFlagEmoji == flag) 2.dp else 1.dp,
                                color = if (viewModel.builderFlagEmoji == flag) MaterialTheme.colorScheme.tertiary else Color.LightGray.copy(0.5f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                viewModel.builderFlagEmoji = flag
                                keyboardController?.hide()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = flag, fontSize = 24.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.builderFlagEmoji,
                onValueChange = { if (it.isNotEmpty()) viewModel.builderFlagEmoji = it.take(2) },
                label = { Text("Свой знак/флаг с клавиатуры") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Text("🏳️‍🌈") }
            )
        }

        // SELECT GRADIENT BACKGROUND
        item {
            Text("4. Оформление фона (Световой градиент):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                bgOptions.forEach { triple ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .shadow(2.dp, RoundedCornerShape(10.dp))
                            .clip(RoundedCornerShape(10.dp))
                            .background(triple.third)
                            .border(
                                width = if (viewModel.builderBackgroundStyle == triple.first) 3.dp else 0.dp,
                                color = if (viewModel.builderBackgroundStyle == triple.first) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.builderBackgroundStyle = triple.first },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = triple.second,
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // SELECT RPG ROLE
        item {
            Text("5. Класс персонажа (Влияет на здоровье и атаку):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                roleOptions.forEach { pair ->
                    FilterChip(
                        selected = viewModel.builderRole == pair.first,
                        onClick = { viewModel.builderRole = pair.first },
                        label = { Text(pair.second, fontWeight = FontWeight.Medium) },
                        modifier = Modifier.testTag("role_${pair.first}")
                    )
                }
            }
        }

        // SAVE BUTTON
        item {
            Button(
                onClick = {
                    if (viewModel.builderName.trim().isEmpty()) {
                        Toast.makeText(context, "Укажите имя для вашего героя!", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.saveAvatar()
                        Toast.makeText(context, "🦊 Герой ${viewModel.builderName} успешно создан и сохранен!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .padding(vertical = 4.dp)
                    .testTag("save_avatar_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Записать аватара в Студию", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

@Composable
fun StatProgressBar(label: String, value: Int, maxValue: Int, color: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            Text(text = "$value / $maxValue", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { (value.toFloat() / maxValue).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

@Composable
fun GalleryTab(viewModel: AvatarViewModel, showBuilderTab: () -> Unit) {
    val savedAvatars by viewModel.savedAvatars.collectAsStateWithLifecycle()

    if (savedAvatars.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "🛸✨🔮",
                fontSize = 58.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Студия пока пуста",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Вы пока не создали ни одного героя. Используйте вкладку 'Создатель', чтобы сотворить неповторимый цветной аватар из смайликов!",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = showBuilderTab,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Создать")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Перейти к Создателю")
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "Ваша коллекция аватаров (${savedAvatars.size})",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Кликните по аватару, чтобы выбрать его в качестве бойца для Арены!",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 16.dp, bottom = 12.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(savedAvatars) { avatar ->
                    val isSelected = viewModel.activeFighter?.id == avatar.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectFighter(avatar) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(0.7f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(0.4f)
                        ),
                        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            EmojiAvatarCard(
                                base = avatar.baseEmoji,
                                accessory = avatar.accessoryEmoji,
                                flag = avatar.flagEmoji,
                                bgStyle = avatar.backgroundStyle,
                                role = avatar.characterRole,
                                sizeDp = 86
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = avatar.name,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (isSelected) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("Активен ⚔️", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                }

                                Text(
                                    text = "Класс: ${translateRole(avatar.characterRole)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "❤️ ${avatar.hp} ОЗ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF5350))
                                    Text(text = "⚔️ ${avatar.attack} АТК", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9800))
                                    Text(text = "🛡️ ${avatar.defense} ЗАЩ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50))
                                }
                            }

                            IconButton(
                                onClick = { viewModel.deleteAvatar(avatar) },
                                modifier = Modifier.testTag("delete_${avatar.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить аватара", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArenaTab(viewModel: AvatarViewModel, showGalleryTab: () -> Unit) {
    val fighter = viewModel.activeFighter
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberLazyListState()

    // Trigger auto scroll to the end of the logs
    LaunchedEffect(viewModel.combatLogs.size) {
        if (viewModel.combatLogs.isNotEmpty()) {
            scrollState.animateScrollToItem(viewModel.combatLogs.size - 1)
        }
    }

    if (fighter == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "⚔️🏟️🐉",
                fontSize = 58.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Боец не выбран",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Для запуска симуляции аренного боя выберите одного из своих потрясающих героев во вкладке 'Галерея'!",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = showGalleryTab,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Face, contentDescription = "Выбрать бойца")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Перейти к списку бойцов")
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // MAIN COMBAT FIGHT SCREEN (Visual Duel Layout)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Player Avatar Side
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = fighter.name,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "[Ваш боец]", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        EmojiAvatarCard(
                            base = fighter.baseEmoji,
                            accessory = fighter.accessoryEmoji,
                            flag = fighter.flagEmoji,
                            bgStyle = fighter.backgroundStyle,
                            role = fighter.characterRole,
                            sizeDp = 90,
                            hasGlow = viewModel.isBattleActive && viewModel.isPlayerTurn
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        ArenaHpBar(hp = viewModel.pHP, maxHp = viewModel.pMaxHP)
                    }

                    // VS Emblem Badge
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .shadow(2.dp, CircleShape)
                            .background(MaterialTheme.colorScheme.error, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "VS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Right Boss Side
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = viewModel.currentBossName,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "[Босс Арены]", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(4.dp))

                        // Animated Boss Layout Frame (pulsating boss emoji)
                        val infiniteTransition = rememberInfiniteTransition("BossGlow")
                        val scaleBoss by infiniteTransition.animateFloat(
                            initialValue = 0.95f,
                            targetValue = 1.05f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1000, easing = EaseInOutBounce),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "ScaleBoss"
                        )
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .scale(scaleBoss)
                                .shadow(4.dp, RoundedCornerShape(20.dp))
                                .border(2.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                .background(Brush.radialGradient(listOf(Color(0xFF330000), Color(0xFF110000))), RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = viewModel.currentBossEmoji, fontSize = 50.sp)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        ArenaHpBar(hp = viewModel.bHP, maxHp = viewModel.bMaxHP)
                    }
                }
            }

            // TURNS OR WIN/LOSS STATE STATUS BANNER
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        when (viewModel.battleResultText) {
                            "VICTORY" -> Color(0xFF4CAF50).copy(0.15f)
                            "DEFEAT" -> Color(0xFFEF5350).copy(0.15f)
                            else -> if (viewModel.isPlayerTurn) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (viewModel.battleResultText) {
                    "VICTORY" -> Text("🏆 ПОБЕДА! Вы разбили врага в пыль! 🏆", fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50))
                    "DEFEAT" -> Text("💀 ПОРАЖЕНИЕ. Соберитесь с силами!", fontWeight = FontWeight.Bold, color = Color(0xFFEF5350))
                    else -> {
                        if (viewModel.isBattleActive) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val turnSign = if (viewModel.isPlayerTurn) "🪐 ВАШ ХОД (Действуйте!)" else "⏳ ВРАГ АТАКУЕТ..."
                                Text(
                                    text = turnSign,
                                    fontWeight = FontWeight.Bold,
                                    color = if (viewModel.isPlayerTurn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                )
                            }
                        } else {
                            Text("Инициализируйте новое боевое испытание!", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ACTION CONTROL BOARD (Turn-based Action Buttons)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!viewModel.isBattleActive) {
                    Button(
                        onClick = { viewModel.startBattle() },
                        modifier = Modifier.weight(1f).height(50.dp).testTag("start_battle"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Бой")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Начать испытание ⚔️", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = { viewModel.playerAttack() },
                        enabled = viewModel.isPlayerTurn,
                        modifier = Modifier.weight(1.0f).height(50.dp).testTag("action_attack"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Удар ⚔️", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    Button(
                        onClick = { viewModel.playerHeal() },
                        enabled = viewModel.isPlayerTurn,
                        modifier = Modifier.weight(0.9f).height(50.dp).testTag("action_heal"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Зелье 💖", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    Button(
                        onClick = { viewModel.playerSpecialBlock() },
                        enabled = viewModel.isPlayerTurn,
                        modifier = Modifier.weight(1.1f).height(50.dp).testTag("action_special"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Магия 🔮", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                }
            }

            // GAME TERMINAL / CONSOLE DIALOG (Combat Logs)
            Text(
                text = "Лог Сражения / Чат игры:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                border = BorderStroke(1.5.dp, Color(0xFF333333))
            ) {
                if (viewModel.combatLogs.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Консоль боя пуста.\nНажмите 'Начать испытание', чтобы войти на арену!",
                            color = Color(0xFF888888),
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyColumn(
                        state = scrollState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(viewModel.combatLogs) { log ->
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "› ",
                                    color = Color(0xFF00FF00),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = log.message,
                                    color = when (log.type) {
                                        LogType.PLAYER -> Color(0xFF22D3EE)
                                        LogType.MONSTER -> Color(0xFFF87171)
                                        LogType.HEAL -> Color(0xFF34D399)
                                        LogType.CRITICAL -> Color(0xFFFB923C)
                                        LogType.SYSTEM -> Color(0xFFE2E8F0)
                                    },
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (log.type == LogType.CRITICAL || log.type == LogType.SYSTEM) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArenaHpBar(hp: Int, maxHp: Int) {
    val hpPercent = if (maxHp > 0) hp.toFloat() / maxHp else 0f
    val barColor = when {
        hpPercent > 0.5f -> Color(0xFF4CAF50) // Green
        hpPercent > 0.2f -> Color(0xFFFF9800) // Orange
        else -> Color(0xFFEF5350) // Red
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "HP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Text(text = "$hp/$maxHp", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { hpPercent.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = barColor,
            trackColor = barColor.copy(alpha = 0.2f)
        )
    }
}

private fun translateRole(role: String): String {
    return when (role) {
        "Knight" -> "🛡️ Рыцарь"
        "Mage" -> "🔮 Волшебник"
        "Cyber-Ninja" -> "⚡ Кибер-Ниндзя"
        "Chef" -> "🍳 Шеф-Повар"
        "Astronaut" -> "🚀 Космонавт"
        else -> "👤 Странник"
    }
}

@Suppress("OPT_IN_WITHOUT_DECLARATION_OR_NEED")
@OptIn(ExperimentalLayoutApi::class)
private fun tint(color: Color): Modifier = Modifier // Fallback for simple color manipulation
