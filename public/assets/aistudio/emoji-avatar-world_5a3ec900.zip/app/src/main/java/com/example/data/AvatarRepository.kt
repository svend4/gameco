package com.example.data

import kotlinx.coroutines.flow.Flow

class AvatarRepository(private val avatarDao: AvatarDao) {
    val allAvatars: Flow<List<AvatarEntity>> = avatarDao.getAllAvatars()

    suspend fun insert(avatar: AvatarEntity) {
        avatarDao.insertAvatar(avatar)
    }

    suspend fun delete(avatar: AvatarEntity) {
        avatarDao.deleteAvatar(avatar)
    }

    suspend fun deleteById(id: Int) {
        avatarDao.deleteById(id)
    }
}
