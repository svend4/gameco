package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AvatarDao {
    @Query("SELECT * FROM emoji_avatars ORDER BY timestamp DESC")
    fun getAllAvatars(): Flow<List<AvatarEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAvatar(avatar: AvatarEntity)

    @Delete
    suspend fun deleteAvatar(avatar: AvatarEntity)

    @Query("DELETE FROM emoji_avatars WHERE id = :id")
    suspend fun deleteById(id: Int)
}
